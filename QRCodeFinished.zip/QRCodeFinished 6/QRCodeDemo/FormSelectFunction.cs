﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace QRCodeDemo
{
    public partial class FormSelectFunction : Form
    {
        public FormSelectFunction()
        {
            InitializeComponent();
        }

        private void FormSelectFunction_Load(object sender, EventArgs e)
        {

        }

        private void buttonLunchBreak_Click(object sender, EventArgs e)
        {
            Class.AttendanceSelection = "LunchBreak";
            this.Hide();
        }

        private void buttonAttendance_Click(object sender, EventArgs e)
        {
            Class.AttendanceSelection = "Attendance";
            this.Hide();
        }
    }
}
