﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace QRCodeDemo
{
    public partial class FormAttendanceEdit : Form
    {
        SqlConnection tublecon = new SqlConnection(Class.tublecon);

        public FormAttendanceEdit()
        {
            InitializeComponent();
        }

        private void FormAttendanceEdit_Load(object sender, EventArgs e)
        {
            GetData();
        }

        void GetData() 
        {

            SqlCommand cmd = new SqlCommand("SELECT * FROM tblWorkersAttendance INNER JOIN tblWorkersBioData ON tblWorkersAttendance.WorkersID = tblWorkersBioData.WorkersID WHERE tblWorkersBioData.WorkersID = @WorkersID AND tblWorkersAttendance.Date = @Date", tublecon);
            cmd.Parameters.AddWithValue("@WorkersID", Class.WorkersID);
            cmd.Parameters.AddWithValue("@Date", Convert.ToDateTime(Class.WorkersDate));
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            textBoxWorkersID.Text = Convert.ToString(dt.Rows[0][0]);
            textBoxFullName.Text = Convert.ToString(dt.Rows[0]["LName"] + ", " + dt.Rows[0]["FName"] + " " + dt.Rows[0]["MName"] + " " + dt.Rows[0]["Suffix"]);
            dateTimePickerSchedule.Text = Convert.ToString(dt.Rows[0]["Schedule"]);
            dateTimePickerCheckIn.Text = Convert.ToString(dt.Rows[0]["CheckIn"]);
            dateTimePickerCheckOut.Text = Convert.ToString(dt.Rows[0]["CheckOut"]);
            textBoxStatus.Text = Convert.ToString(dt.Rows[0]["Status"]);
            textBoxDay.Text = Convert.ToString(dt.Rows[0]["Day"]);
            dateTimePickerDate.Text = Convert.ToString(dt.Rows[0]["Date"]);

            //For PictureBox
            MemoryStream mem = new MemoryStream((Byte[])(dt.Rows[0]["Picture"]));
            pictureBox1.Image = Image.FromStream(mem);
        }

        private void buttonClose_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void buttonAddAttendance_Click(object sender, EventArgs e)
        {
            UpdateAttendance();
            EmployeeStatus();
            this.Hide();
        }

        void UpdateAttendance()
        {
            SqlCommand cmd = new SqlCommand(@"UPDATE tblWorkersAttendance 
                                              SET CheckOut = @CheckOut, Status = @Status 
                                              WHERE WorkersID = @WorkersID AND Date = @Date", tublecon);
            cmd.Parameters.AddWithValue("@CheckOut", dateTimePickerCheckOut.Text);
            cmd.Parameters.AddWithValue("@WorkersID", textBoxWorkersID.Text);
            cmd.Parameters.AddWithValue("@Date", Convert.ToDateTime(dateTimePickerDate.Text));
            cmd.Parameters.AddWithValue("@Status", textBoxStatus.Text);
            tublecon.Open();
            cmd.ExecuteNonQuery();
            tublecon.Close();
        }

        void EmployeeStatus()
        {
            SqlCommand cmd = new SqlCommand(@"INSERT INTO [dbo].[tblEmplyeeStatus]
                                                     ([EmployeeID],[Date],[Time],[TimeDayNight],[Type],WorkersID,[Description]) 
                                              VALUES (@EmployeeID, @Date ,@Time, @TimeDayNight, @Type, @WorkersID, @Description)", tublecon);
            cmd.Parameters.AddWithValue("@EmployeeID", Class.EmployeeID);
            cmd.Parameters.AddWithValue("@Date", Convert.ToDateTime(DateTime.Now.ToShortDateString()));
            cmd.Parameters.AddWithValue("@Time", Convert.ToDateTime(DateTime.Now.ToShortTimeString()));

            string converttime = DateTime.Now.ToShortTimeString();
            string[] convertsplittime = converttime.Split(' ');
            cmd.Parameters.AddWithValue("@TimeDayNight", convertsplittime[1]);
            cmd.Parameters.AddWithValue("@Type", "Edit Worker Attendance");
            cmd.Parameters.AddWithValue("@WorkersID", textBoxWorkersID.Text);

            string describe = "";
            if (checkBoxOverTime.Checked == true) { describe = "Half Day"; }
            else if (checkBoxOverTime.Checked == false) { describe = "CheckOut"; }
            cmd.Parameters.AddWithValue("@Description", describe);
            tublecon.Open();
            cmd.ExecuteNonQuery();
            tublecon.Close();
        }

        private void buttonClose_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void checkBoxOverTime_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxOverTime.Checked == true)
            {
                textBoxStatus.Text = "Over Time";
                checkBoxHalfDay.Checked = false;
            }
            else if (checkBoxOverTime.Checked == false)
            {
                SqlCommand cmd = new SqlCommand(@"SELECT * FROM tblWorkersAttendance 
                                                    INNER JOIN tblWorkersBioData 
                                                    ON tblWorkersAttendance.WorkersID = tblWorkersBioData.WorkersID 
                                                    WHERE tblWorkersBioData.WorkersID = @WorkersID AND tblWorkersAttendance.Date = @Date", tublecon);
                cmd.Parameters.AddWithValue("@WorkersID", Class.WorkersID);
                cmd.Parameters.AddWithValue("@Date", Convert.ToDateTime(Class.WorkersDate));
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                textBoxStatus.Text = Convert.ToString(dt.Rows[0]["Status"]);
            }
        }

        private void checkBoxHalfDay_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxHalfDay.Checked == true)
            {
                textBoxStatus.Text = "Half Day";
                checkBoxOverTime.Checked = false;
            }
            else if (checkBoxHalfDay.Checked == false)
            {
                SqlCommand cmd = new SqlCommand(@"SELECT * FROM tblWorkersAttendance 
                                                    INNER JOIN tblWorkersBioData 
                                                    ON tblWorkersAttendance.WorkersID = tblWorkersBioData.WorkersID 
                                                    WHERE tblWorkersBioData.WorkersID = @WorkersID AND tblWorkersAttendance.Date = @Date", tublecon);
                cmd.Parameters.AddWithValue("@WorkersID", Class.WorkersID);
                cmd.Parameters.AddWithValue("@Date", Convert.ToDateTime(Class.WorkersDate));
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                textBoxStatus.Text = Convert.ToString(dt.Rows[0]["Status"]);
            }
        }
    }
}
