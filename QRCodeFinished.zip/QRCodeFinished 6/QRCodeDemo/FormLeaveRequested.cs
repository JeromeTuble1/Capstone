﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace QRCodeDemo
{
    public partial class FormLeaveRequested : Form
    {
        SqlConnection tublecon = new SqlConnection(Class.tublecon);

        public FormLeaveRequested()
        {
            InitializeComponent();
        }

        private void FormLeaveRequested_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        void LoadData()
        {
            SqlCommand tublecmd = new SqlCommand("SELECT LR.WorkersID, WBD.LName +', '+ WBD.FName +' '+ WBD.MName + ' ' + WBD.Suffix AS [Name], LR.[From], CONVERT(VARCHAR(20), LR.FromTime) + ' ' + LR.FromDayNight AS FromTime, LR.[To], CONVERT(VARCHAR(20), LR.ToTime) + ' ' + LR.ToDayNight AS ToTime, LR.[Date] FROM tblLeaveRequested LR INNER JOIN tblWorkersBioData WBD ON LR.WorkersID = WBD.WorkersID WHERE LR.WorkersID = @WorkersID", tublecon);
            tublecmd.Parameters.AddWithValue("@WorkersID", Class.WorkersID);
            SqlDataAdapter tubleda = new SqlDataAdapter(tublecmd);
            DataTable tubledt = new DataTable();
            tubleda.Fill(tubledt);
            dataGridViewLeaveRequested.DataSource = tubledt;
        }

        private void dataGridViewLeaveRequested_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (Class.isLeaveRequested == true)
            {
                DialogResult dialogResult = MessageBox.Show("You Want to Remove this", "Remove Leave Requested", MessageBoxButtons.YesNo);

                if (dialogResult == DialogResult.Yes)
                {
                    RemoveLeaveRequest();
                    RemoveAttendanceLeave();
                    EmployeeStatus();
                }
                else if (dialogResult == DialogResult.No)
                {
                    //do something else
                }
            }
            else if (Class.isLeaveRequested == false)
            {
                Class.WorkersID = dataGridViewLeaveRequested.CurrentRow.Cells[0].Value.ToString();
                Class.WorkersDate = dataGridViewLeaveRequested.CurrentRow.Cells[6].Value.ToString();
                FormLeaveReceipt LR = new FormLeaveReceipt();
                LR.ShowDialog();
            }
        }

        void EmployeeStatus()
        {
            SqlCommand cmd = new SqlCommand("INSERT INTO [dbo].[tblEmplyeeStatus] ([EmployeeID],[Date],[Time],[TimeDayNight],[Type],WorkersID,[Description]) VALUES (@EmployeeID, @Date ,@Time, @TimeDayNight, @Type, @WorkersID, @Description)", tublecon);
            cmd.Parameters.AddWithValue("@EmployeeID", Class.EmployeeID);
            cmd.Parameters.AddWithValue("@Date", Convert.ToDateTime(DateTime.Now.ToShortDateString()));
            cmd.Parameters.AddWithValue("@Time", Convert.ToDateTime(DateTime.Now.ToShortTimeString()));

            string converttime = DateTime.Now.ToShortTimeString();
            string[] convertsplittime = converttime.Split(' ');
            cmd.Parameters.AddWithValue("@TimeDayNight", convertsplittime[1]);
            cmd.Parameters.AddWithValue("@Type", "Leave Requested");
            cmd.Parameters.AddWithValue("@WorkersID", Class.WorkersID);
            cmd.Parameters.AddWithValue("@Description", "Remove Leave Requested");
            tublecon.Open();
            cmd.ExecuteNonQuery();
            tublecon.Close();
        }

        void RemoveAttendanceLeave()
        {
            try
            {
                for (DateTime dtm = Convert.ToDateTime(dataGridViewLeaveRequested.CurrentRow.Cells[2].Value.ToString()); dtm <= Convert.ToDateTime(dataGridViewLeaveRequested.CurrentRow.Cells[4].Value.ToString()); dtm = dtm.AddDays(1))
                {
                    if (dtm >= Convert.ToDateTime(DateTime.Now.ToShortDateString()))
                    {
                        SqlCommand tublecmd = new SqlCommand("DELETE FROM tblWorkersAttendance WHERE [WorkersID] = @WorkersID AND [Date] = @Date", tublecon);
                        tublecmd.Parameters.AddWithValue("@WorkersID", dataGridViewLeaveRequested.CurrentRow.Cells[0].Value.ToString());
                        tublecmd.Parameters.AddWithValue("@Date", Convert.ToDateTime(dtm));
                        tublecon.Open();
                        tublecmd.ExecuteNonQuery();
                        tublecon.Close();
                    }
                }
            }
            catch
            {
                tublecon.Close();
            }
        }

        void RemoveLeaveRequest()
        {
            try
            {
                SqlCommand tublecmd = new SqlCommand("DELETE FROM tblLeaveRequested WHERE [WorkersID] = @WorkersID AND [Date] = @Date", tublecon);
                tublecmd.Parameters.AddWithValue("@WorkersID", dataGridViewLeaveRequested.CurrentRow.Cells[0].Value.ToString());
                tublecmd.Parameters.AddWithValue("@Date", Convert.ToDateTime(dataGridViewLeaveRequested.CurrentRow.Cells[6].Value.ToString()));
                tublecon.Open();
                tublecmd.ExecuteNonQuery();
                tublecon.Close();
            }
            catch
            {
                tublecon.Close();
            }
        }

        private void buttonClose_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
