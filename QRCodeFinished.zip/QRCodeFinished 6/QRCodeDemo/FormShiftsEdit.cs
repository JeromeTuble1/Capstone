﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace QRCodeDemo
{
    public partial class FormShiftsEdit : Form
    {
        SqlConnection con = new SqlConnection(Class.tublecon);
        string StackDescription;
        string[] Week = new string[7];

        public FormShiftsEdit()
        {
            InitializeComponent();
        }

        private void FormShiftsEdit_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        void LoadData()
        {
            SqlCommand cmd = new SqlCommand("SELECT WS.WorkersID,WBD.LName + ' ' + WBD.FName + ' ' + WBD.MName + ' ' + WBD.Suffix, CONVERT(VARCHAR(20), WS.MonSched) + ' ' + WS.MonDayNight AS Monday, CONVERT(VARCHAR(20), WS.TueSched) + ' ' + WS.TueDayNight AS Tuesday, CONVERT(VARCHAR(20), WS.WedSched) + ' ' + WS.WedDayNight AS Wednesday, CONVERT(VARCHAR(20), WS.ThuSched) + ' ' + WS.ThuDayNight AS Thursday, CONVERT(VARCHAR(20), WS.FriSched) + ' ' + WS.FriDayNight AS Friday, CONVERT(VARCHAR(20), WS.SatSched) + ' ' + WS.SatDayNight AS Saturday, CONVERT(VARCHAR(20), WS.SunSched) + ' ' + WS.SunDayNight AS Sunday, WBD.Picture FROM tblWorkersSchedule WS INNER JOIN tblWorkersBioData WBD ON WS.WorkersID = WBD.WorkersID WHERE WS.WorkersID=@WorkersID", con);
            cmd.Parameters.AddWithValue("@WorkersID", Class.WorkersID);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            labelWorkerID.Text = Convert.ToString(dt.Rows[0][0]);
            labelWorkerName.Text = Convert.ToString(dt.Rows[0][1]);
            MemoryStream mem = new MemoryStream((Byte[])(dt.Rows[0]["Picture"]));
            pictureBoxWorker.Image = Image.FromStream(mem);

            //Load Schedule

            dateTimePickerMonday.Text = Convert.ToString(dt.Rows[0]["Monday"]);
            dateTimePickerTuesday.Text = Convert.ToString(dt.Rows[0]["Tuesday"]);
            dateTimePickerWednesday.Text = Convert.ToString(dt.Rows[0]["Wednesday"]);
            dateTimePickerThursday.Text = Convert.ToString(dt.Rows[0]["Thursday"]);
            dateTimePickerFriday.Text = Convert.ToString(dt.Rows[0]["Friday"]);
            dateTimePickerSaturday.Text = Convert.ToString(dt.Rows[0]["Saturday"]);
            dateTimePickerSunday.Text = Convert.ToString(dt.Rows[0]["Sunday"]);

            Week[0] = Convert.ToString(dt.Rows[0]["Monday"]);
            Week[1] = Convert.ToString(dt.Rows[0]["Tuesday"]);
            Week[2] = Convert.ToString(dt.Rows[0]["Wednesday"]);
            Week[3] = Convert.ToString(dt.Rows[0]["Thursday"]);
            Week[4] = Convert.ToString(dt.Rows[0]["Friday"]);
            Week[5] = Convert.ToString(dt.Rows[0]["Saturday"]);
            Week[6] = Convert.ToString(dt.Rows[0]["Sunday"]);
        }

        void EditShift()
        {
            try
            {
                string[] Monday = new string[1];
                string[] Tuesday = new string[1];
                string[] Wednesday = new string[1];
                string[] Thursday = new string[1];
                string[] Fridday = new string[1];
                string[] Saturday = new string[1];
                string[] Sunday = new string[1];

                Monday = dateTimePickerMonday.Text.Split(' ');
                Tuesday = dateTimePickerTuesday.Text.Split(' ');
                Wednesday = dateTimePickerWednesday.Text.Split(' ');
                Thursday = dateTimePickerThursday.Text.Split(' ');
                Fridday = dateTimePickerFriday.Text.Split(' ');
                Saturday = dateTimePickerSaturday.Text.Split(' ');
                Sunday = dateTimePickerSunday.Text.Split(' ');

                con.Open();
                SqlCommand TubleWorkerSched = new SqlCommand("UPDATE tblWorkersSchedule SET SunSched=@Sunday, SunDayNight=@SunDayNight, MonSched=@Monday, MonDayNight=@MonDayNight, TueSched=@Tuesday, TueDayNight=@TueDayNight, WedSched=@Wednesday, WedDayNight=@WedDayNight, ThuSched=@Thursday, ThuDayNight=@ThuDayNight, FriSched=@Friday, FriDayNight=@FriDayNight, SatSched=@Saturday, SatDayNight=@SatDayNight WHERE WorkersID=@WorkersID", con);
                TubleWorkerSched.Parameters.AddWithValue("@WorkersID", labelWorkerID.Text);
                TubleWorkerSched.Parameters.AddWithValue("@Sunday", Sunday[0]);
                TubleWorkerSched.Parameters.AddWithValue("@SunDayNight", Sunday[1]);
                TubleWorkerSched.Parameters.AddWithValue("@Monday", Monday[0]);
                TubleWorkerSched.Parameters.AddWithValue("@MonDayNight", Monday[1]);
                TubleWorkerSched.Parameters.AddWithValue("@Tuesday", Tuesday[0]);
                TubleWorkerSched.Parameters.AddWithValue("@TueDayNight", Tuesday[1]);
                TubleWorkerSched.Parameters.AddWithValue("@Wednesday", Wednesday[0]);
                TubleWorkerSched.Parameters.AddWithValue("@WedDayNight", Wednesday[1]);
                TubleWorkerSched.Parameters.AddWithValue("@Thursday", Thursday[0]);
                TubleWorkerSched.Parameters.AddWithValue("@ThuDayNight", Thursday[1]);
                TubleWorkerSched.Parameters.AddWithValue("@Friday", Fridday[0]);
                TubleWorkerSched.Parameters.AddWithValue("@FriDayNight", Fridday[1]);
                TubleWorkerSched.Parameters.AddWithValue("@Saturday", Saturday[0]);
                TubleWorkerSched.Parameters.AddWithValue("@SatDayNight", Saturday[1]);
                TubleWorkerSched.ExecuteNonQuery();
                con.Close();
                this.Close();
            }
            catch
            {
                con.Close();
                throw;
            }
            finally
            {
                con.Close();
            }
        }

        void EmployeeStatus()
        {
            SqlCommand cmd = new SqlCommand("INSERT INTO [dbo].[tblEmplyeeStatus] ([EmployeeID],[Date],[Time],[TimeDayNight],[Type],WorkersID,[Description]) VALUES (@EmployeeID, @Date ,@Time, @TimeDayNight, @Type, @WorkersID, @Description)", con);
            cmd.Parameters.AddWithValue("@EmployeeID", Class.EmployeeID);
            cmd.Parameters.AddWithValue("@Date", Convert.ToDateTime(DateTime.Now.ToShortDateString()));
            cmd.Parameters.AddWithValue("@Time", Convert.ToDateTime(DateTime.Now.ToShortTimeString()));

            string converttime = DateTime.Now.ToShortTimeString();
            string[] convertsplittime = converttime.Split(' ');
            cmd.Parameters.AddWithValue("@TimeDayNight", convertsplittime[1]);
            cmd.Parameters.AddWithValue("@Type", "Edit Worker Shift");
            cmd.Parameters.AddWithValue("@WorkersID", labelWorkerID.Text);
            cmd.Parameters.AddWithValue("@Description", StackDescription);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }

        void CheckShift()
        {
            StackDescription = "";

            if (dateTimePickerMonday.Text != Week[0]) { StackDescription += "Monday "; }
            if (dateTimePickerTuesday.Text != Week[1]) { StackDescription += "Tuesday "; }
            if (dateTimePickerWednesday.Text != Week[2]) { StackDescription += "Wednesday "; }
            if (dateTimePickerThursday.Text != Week[3]) { StackDescription += " Thursday "; }
            if (dateTimePickerFriday.Text != Week[4]) { StackDescription += " Friday "; }
            if (dateTimePickerSaturday.Text != Week[5]) { StackDescription += "Saturday "; }
            if (dateTimePickerSunday.Text != Week[6]) { StackDescription += "Sunday "; }
        }

        private void buttonEditShift_Click(object sender, EventArgs e)
        {
            CheckShift();
            EmployeeStatus();
            EditShift();
        }

        private void buttonClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
