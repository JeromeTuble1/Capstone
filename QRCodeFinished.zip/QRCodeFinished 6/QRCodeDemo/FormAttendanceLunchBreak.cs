﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace QRCodeDemo
{
    public partial class FormAttendanceLunchBreak : Form
    {
        SqlConnection tublecon = new SqlConnection(Class.tublecon);

        public FormAttendanceLunchBreak()
        {
            InitializeComponent();
        }

        private void dataGridViewAttendance_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        void LoadData()
        {
            SqlCommand cmd = new SqlCommand(@"
            SELECT WorkersID, Schedule, CheckIn, CheckOut, 
            SUBSTRING(CONVERT(varchar,(CONVERT(time,CONVERT(datetime,CheckIn) - CONVERT(datetime,CheckOut)))), 1,8) AS [Total Hours],
            [Status], [Day], [Date], AbsentCause FROM tblWorkersAttendance
            WHERE Date = @Date AND [Status] = @Status
            ORDER BY WorkersID ASC", tublecon);
            cmd.Parameters.AddWithValue("@Date", Convert.ToDateTime(DateTime.Now.ToShortDateString()));
            cmd.Parameters.AddWithValue("@Status", "Lunch Break");
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridViewAttendance.DataSource = dt;
        }

        void Search()
        {
            bool accept = false;
            string category = Convert.ToString(comboBoxSelectCategory.SelectedItem);
            if (category.Equals("WorkersID") && textBoxSearch.Text != "") { category = @"
            SELECT WorkersID, Schedule, CheckIn, CheckOut, 
            SUBSTRING(CONVERT(varchar,(CONVERT(time,CONVERT(datetime,CheckIn) - CONVERT(datetime,CheckOut)))), 1,8) AS [Total Hours],
            [Status], [Day], [Date], AbsentCause FROM tblWorkersAttendance
            WHERE WorkersID ="; accept = true; }
            else if (category.Equals("Schedule") && textBoxSearch.Text != "") { category = @"
            SELECT WorkersID, Schedule, CheckIn, CheckOut, 
            SUBSTRING(CONVERT(varchar,(CONVERT(time,CONVERT(datetime,CheckIn) - CONVERT(datetime,CheckOut)))), 1,8) AS [Total Hours],
            [Status], [Day], [Date], AbsentCause FROM tblWorkersAttendance
            WHERE Schedule ="; accept = true; }
            else if (category.Equals("Status") && textBoxSearch.Text != "") { category = @"
            SELECT WorkersID, Schedule, CheckIn, CheckOut, 
            SUBSTRING(CONVERT(varchar,(CONVERT(time,CONVERT(datetime,CheckIn) - CONVERT(datetime,CheckOut)))), 1,8) AS [Total Hours],
            [Status], [Day], [Date], AbsentCause FROM tblWorkersAttendance
            WHERE Status ="; accept = true; }
            else if (category.Equals("Day") && textBoxSearch.Text != "") { category = @"
            SELECT WorkersID, Schedule, CheckIn, CheckOut, 
            SUBSTRING(CONVERT(varchar,(CONVERT(time,CONVERT(datetime,CheckIn) - CONVERT(datetime,CheckOut)))), 1,8) AS [Total Hours],
            [Status], [Day], [Date], AbsentCause FROM tblWorkersAttendance
            WHERE Day ="; accept = true; }
            else if (category.Equals("AbsentCause") && textBoxSearch.Text != "") { category = @"
            SELECT WorkersID, Schedule, CheckIn, CheckOut, 
            SUBSTRING(CONVERT(varchar,(CONVERT(time,CONVERT(datetime,CheckIn) - CONVERT(datetime,CheckOut)))), 1,8) AS [Total Hours],
            [Status], [Day], [Date], AbsentCause FROM tblWorkersAttendance
            WHERE AbsentCause ="; accept = true; }
            else if (category.Equals("")) { accept = false; }

            if (accept.Equals(true))
            {
                SqlCommand cmd = new SqlCommand(category + "@Search AND Date = @Date AND [Status] = @Status ORDER BY WorkersID ASC", tublecon);
                cmd.Parameters.AddWithValue("@Search", textBoxSearch.Text);
                cmd.Parameters.AddWithValue("@Date", Convert.ToDateTime(DateTime.Now.ToShortDateString()));
                cmd.Parameters.AddWithValue("@Status", "Lunch Break");
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridViewAttendance.DataSource = dt;
                accept = false;
            }
            else if (accept.Equals(false))
            {
                LoadData();
            }
        }

        private void textBoxSearch_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                Search();

            }
        }

        private void jbtPanelGIF2_Click(object sender, EventArgs e)
        {

        }

        private void FormAttendanceLunchBreak_Load(object sender, EventArgs e)
        {
            LoadData();
        }
    }
}
