﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace QRCodeDemo
{
    public partial class FormEmployeeForgotPassword : Form
    {
        SqlConnection tublecon = new SqlConnection(Class.tublecon);

        public FormEmployeeForgotPassword()
        {
            InitializeComponent();
        }

        private void buttonFindPassword_Click(object sender, EventArgs e)
        {
            FindAccount();
        }

        void FindAccount()
        {
            SqlCommand tublecmd = new SqlCommand("SELECT Password,Picture FROM tblLogin WHERE EmployeeID=@EmployeeID AND Birthdate=@Birthdate", tublecon);
            tublecmd.Parameters.AddWithValue("@EmployeeID",textBoxEmployID.Text);
            tublecmd.Parameters.AddWithValue("@Birthdate",Convert.ToDateTime(dateTimePickerbirthdate.Text));
            SqlDataAdapter tubleda = new SqlDataAdapter(tublecmd);
            DataTable tubledt = new DataTable();
            tubleda.Fill(tubledt);
            if (tubledt.Rows.Count != 0)
            {
                textBoxYourPassword.Text = Convert.ToString(tubledt.Rows[0][0]);
                MemoryStream mem = new MemoryStream((Byte[])(tubledt.Rows[0]["Picture"]));
                pictureBox1.Image = Image.FromStream(mem);
            }
            else
            {
                textBoxYourPassword.Text = "";
            }
        }

        private void FormEmployeeForgotPassword_Load(object sender, EventArgs e)
        {
            textBoxEmployID.BorderStyle = BorderStyle.None;
            textBoxYourPassword.BorderStyle = BorderStyle.None;
        }
    }
}
