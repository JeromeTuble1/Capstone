﻿namespace QRCodeDemo
{
    partial class FormWorkersAdd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonAddWorkers = new System.Windows.Forms.Button();
            this.numericUpDownNumofChil = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxLName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.comboBoxMartialStatus = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxAddress = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.textBoxWorkerID = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.dateTimePickerbirthdate = new System.Windows.Forms.DateTimePicker();
            this.label11 = new System.Windows.Forms.Label();
            this.textBoxFName = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.textBoxMName = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.panelBioData = new System.Windows.Forms.Panel();
            this.label53 = new System.Windows.Forms.Label();
            this.textBoxSuffix = new System.Windows.Forms.TextBox();
            this.textBoxMotherLName = new System.Windows.Forms.TextBox();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.textBoxMotherMName = new System.Windows.Forms.TextBox();
            this.label45 = new System.Windows.Forms.Label();
            this.textBoxMotherFName = new System.Windows.Forms.TextBox();
            this.textBoxFatherLName = new System.Windows.Forms.TextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.textBoxFatherMName = new System.Windows.Forms.TextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.textBoxFatherFName = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.comboBoxReligion = new System.Windows.Forms.ComboBox();
            this.maskedTextBoxEmergencyContact = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBoxContactNum = new System.Windows.Forms.MaskedTextBox();
            this.textBoxHireDate = new System.Windows.Forms.TextBox();
            this.comboBoxYearHire = new System.Windows.Forms.ComboBox();
            this.label17 = new System.Windows.Forms.Label();
            this.textBoxReference = new System.Windows.Forms.TextBox();
            this.textBoxNameOfCompany = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.textBoxPosition = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.buttonFileUpload = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.panelEducationalQualification = new System.Windows.Forms.Panel();
            this.label35 = new System.Windows.Forms.Label();
            this.comboBoxMasterYearPassed = new System.Windows.Forms.ComboBox();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.numericUpDownMasterGrade = new System.Windows.Forms.NumericUpDown();
            this.textBoxMasterName = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.comboBoxGraduationYearPassed = new System.Windows.Forms.ComboBox();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.numericUpDownGraduationGrade = new System.Windows.Forms.NumericUpDown();
            this.textBoxGraduationName = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.comboBoxIntermediateYearPassed = new System.Windows.Forms.ComboBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.numericUpDownIntermediateGrade = new System.Windows.Forms.NumericUpDown();
            this.textBoxIntermediateName = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.comboBoxMatricYearPassed = new System.Windows.Forms.ComboBox();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.numericUpDownMatricGrade = new System.Windows.Forms.NumericUpDown();
            this.label24 = new System.Windows.Forms.Label();
            this.textBoxMatricName = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.panelImage = new System.Windows.Forms.Panel();
            this.flowLayoutPanel2 = new System.Windows.Forms.FlowLayoutPanel();
            this.panelWorkingExperience = new System.Windows.Forms.Panel();
            this.panelWorkerSchedule = new System.Windows.Forms.Panel();
            this.dateTimePickerSunday = new System.Windows.Forms.DateTimePicker();
            this.dateTimePickerSaturday = new System.Windows.Forms.DateTimePicker();
            this.dateTimePickerFriday = new System.Windows.Forms.DateTimePicker();
            this.dateTimePickerThursday = new System.Windows.Forms.DateTimePicker();
            this.dateTimePickerWednesday = new System.Windows.Forms.DateTimePicker();
            this.dateTimePickerTuesday = new System.Windows.Forms.DateTimePicker();
            this.dateTimePickerMonday = new System.Windows.Forms.DateTimePicker();
            this.label51 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.buttonAddWorker = new System.Windows.Forms.Button();
            this.panel6 = new System.Windows.Forms.Panel();
            this.flowLayoutPanel3 = new System.Windows.Forms.FlowLayoutPanel();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownNumofChil)).BeginInit();
            this.panelBioData.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel3.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.panelEducationalQualification.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownMasterGrade)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownGraduationGrade)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownIntermediateGrade)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownMatricGrade)).BeginInit();
            this.panelImage.SuspendLayout();
            this.flowLayoutPanel2.SuspendLayout();
            this.panelWorkingExperience.SuspendLayout();
            this.panelWorkerSchedule.SuspendLayout();
            this.panel6.SuspendLayout();
            this.flowLayoutPanel3.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // buttonAddWorkers
            // 
            this.buttonAddWorkers.BackColor = System.Drawing.Color.LightBlue;
            this.buttonAddWorkers.FlatAppearance.BorderSize = 0;
            this.buttonAddWorkers.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAddWorkers.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAddWorkers.Location = new System.Drawing.Point(1669, 817);
            this.buttonAddWorkers.Margin = new System.Windows.Forms.Padding(4);
            this.buttonAddWorkers.Name = "buttonAddWorkers";
            this.buttonAddWorkers.Size = new System.Drawing.Size(264, 68);
            this.buttonAddWorkers.TabIndex = 13;
            this.buttonAddWorkers.Text = "Add";
            this.buttonAddWorkers.UseVisualStyleBackColor = false;
            this.buttonAddWorkers.Click += new System.EventHandler(this.buttonAddWorkers_Click);
            // 
            // numericUpDownNumofChil
            // 
            this.numericUpDownNumofChil.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.numericUpDownNumofChil.Enabled = false;
            this.numericUpDownNumofChil.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numericUpDownNumofChil.Location = new System.Drawing.Point(331, 447);
            this.numericUpDownNumofChil.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDownNumofChil.Name = "numericUpDownNumofChil";
            this.numericUpDownNumofChil.Size = new System.Drawing.Size(129, 26);
            this.numericUpDownNumofChil.TabIndex = 30;
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(7, 449);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(254, 20);
            this.label6.TabIndex = 29;
            this.label6.Text = "Number of Children/Dependents:";
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(538, 488);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(87, 20);
            this.label5.TabIndex = 28;
            this.label5.Text = "Hire Date:";
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(386, 123);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 17);
            this.label4.TabIndex = 24;
            this.label4.Text = "LName";
            // 
            // textBoxLName
            // 
            this.textBoxLName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBoxLName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxLName.Location = new System.Drawing.Point(331, 88);
            this.textBoxLName.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxLName.Name = "textBoxLName";
            this.textBoxLName.Size = new System.Drawing.Size(168, 26);
            this.textBoxLName.TabIndex = 22;
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(163, 198);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(118, 20);
            this.label2.TabIndex = 35;
            this.label2.Text = "Martial Status:";
            // 
            // comboBoxMartialStatus
            // 
            this.comboBoxMartialStatus.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBoxMartialStatus.AutoCompleteCustomSource.AddRange(new string[] {
            "Single",
            "Married",
            "Separated",
            "Divorced",
            "Windowed"});
            this.comboBoxMartialStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxMartialStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxMartialStatus.FormattingEnabled = true;
            this.comboBoxMartialStatus.Items.AddRange(new object[] {
            "Single",
            "Married",
            "Widowed",
            "Divorced",
            "Separated"});
            this.comboBoxMartialStatus.Location = new System.Drawing.Point(331, 194);
            this.comboBoxMartialStatus.Margin = new System.Windows.Forms.Padding(4);
            this.comboBoxMartialStatus.Name = "comboBoxMartialStatus";
            this.comboBoxMartialStatus.Size = new System.Drawing.Size(168, 28);
            this.comboBoxMartialStatus.TabIndex = 36;
            this.comboBoxMartialStatus.SelectedIndexChanged += new System.EventHandler(this.comboBoxMartialStatus_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(508, 198);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 20);
            this.label3.TabIndex = 37;
            this.label3.Text = "Religion:";
            // 
            // textBoxAddress
            // 
            this.textBoxAddress.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBoxAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxAddress.Location = new System.Drawing.Point(331, 379);
            this.textBoxAddress.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxAddress.Multiline = true;
            this.textBoxAddress.Name = "textBoxAddress";
            this.textBoxAddress.Size = new System.Drawing.Size(523, 56);
            this.textBoxAddress.TabIndex = 40;
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(208, 383);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(76, 20);
            this.label8.TabIndex = 39;
            this.label8.Text = "Address:";
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(194, 52);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(90, 20);
            this.label9.TabIndex = 42;
            this.label9.Text = "Worker ID:";
            // 
            // textBoxWorkerID
            // 
            this.textBoxWorkerID.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBoxWorkerID.Enabled = false;
            this.textBoxWorkerID.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxWorkerID.Location = new System.Drawing.Point(331, 48);
            this.textBoxWorkerID.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxWorkerID.Name = "textBoxWorkerID";
            this.textBoxWorkerID.ReadOnly = true;
            this.textBoxWorkerID.Size = new System.Drawing.Size(293, 26);
            this.textBoxWorkerID.TabIndex = 41;
            // 
            // label10
            // 
            this.label10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(483, 450);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(136, 20);
            this.label10.TabIndex = 43;
            this.label10.Text = "Contact Number:";
            // 
            // dateTimePickerbirthdate
            // 
            this.dateTimePickerbirthdate.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dateTimePickerbirthdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePickerbirthdate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePickerbirthdate.Location = new System.Drawing.Point(331, 152);
            this.dateTimePickerbirthdate.Margin = new System.Windows.Forms.Padding(4);
            this.dateTimePickerbirthdate.Name = "dateTimePickerbirthdate";
            this.dateTimePickerbirthdate.Size = new System.Drawing.Size(293, 26);
            this.dateTimePickerbirthdate.TabIndex = 46;
            // 
            // label11
            // 
            this.label11.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(560, 123);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(53, 17);
            this.label11.TabIndex = 48;
            this.label11.Text = "FName";
            // 
            // textBoxFName
            // 
            this.textBoxFName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBoxFName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxFName.Location = new System.Drawing.Point(508, 88);
            this.textBoxFName.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxFName.Name = "textBoxFName";
            this.textBoxFName.Size = new System.Drawing.Size(168, 26);
            this.textBoxFName.TabIndex = 47;
            // 
            // label12
            // 
            this.label12.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(711, 123);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(56, 17);
            this.label12.TabIndex = 50;
            this.label12.Text = "MName";
            // 
            // textBoxMName
            // 
            this.textBoxMName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBoxMName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxMName.Location = new System.Drawing.Point(686, 88);
            this.textBoxMName.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxMName.Name = "textBoxMName";
            this.textBoxMName.Size = new System.Drawing.Size(107, 26);
            this.textBoxMName.TabIndex = 49;
            // 
            // label13
            // 
            this.label13.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(194, 159);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(91, 20);
            this.label13.TabIndex = 51;
            this.label13.Text = "Birth Date:";
            // 
            // label14
            // 
            this.label14.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(162, 92);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(117, 20);
            this.label14.TabIndex = 52;
            this.label14.Text = "Worker Name:";
            // 
            // label15
            // 
            this.label15.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(114, 488);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(161, 20);
            this.label15.TabIndex = 53;
            this.label15.Text = "Emergency Contact:";
            // 
            // panelBioData
            // 
            this.panelBioData.Controls.Add(this.groupBox1);
            this.panelBioData.Location = new System.Drawing.Point(4, 4);
            this.panelBioData.Margin = new System.Windows.Forms.Padding(4);
            this.panelBioData.Name = "panelBioData";
            this.panelBioData.Size = new System.Drawing.Size(901, 545);
            this.panelBioData.TabIndex = 0;
            // 
            // label53
            // 
            this.label53.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label53.AutoSize = true;
            this.label53.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label53.Location = new System.Drawing.Point(823, 123);
            this.label53.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(42, 17);
            this.label53.TabIndex = 79;
            this.label53.Text = "Suffix";
            // 
            // textBoxSuffix
            // 
            this.textBoxSuffix.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBoxSuffix.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxSuffix.Location = new System.Drawing.Point(802, 88);
            this.textBoxSuffix.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSuffix.Name = "textBoxSuffix";
            this.textBoxSuffix.Size = new System.Drawing.Size(81, 26);
            this.textBoxSuffix.TabIndex = 78;
            // 
            // textBoxMotherLName
            // 
            this.textBoxMotherLName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBoxMotherLName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxMotherLName.Location = new System.Drawing.Point(331, 310);
            this.textBoxMotherLName.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxMotherLName.Name = "textBoxMotherLName";
            this.textBoxMotherLName.Size = new System.Drawing.Size(168, 26);
            this.textBoxMotherLName.TabIndex = 72;
            // 
            // label43
            // 
            this.label43.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(386, 344);
            this.label43.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(53, 17);
            this.label43.TabIndex = 73;
            this.label43.Text = "LName";
            // 
            // label44
            // 
            this.label44.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.Location = new System.Drawing.Point(735, 344);
            this.label44.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(56, 17);
            this.label44.TabIndex = 77;
            this.label44.Text = "MName";
            // 
            // textBoxMotherMName
            // 
            this.textBoxMotherMName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBoxMotherMName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxMotherMName.Location = new System.Drawing.Point(686, 310);
            this.textBoxMotherMName.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxMotherMName.Name = "textBoxMotherMName";
            this.textBoxMotherMName.Size = new System.Drawing.Size(168, 26);
            this.textBoxMotherMName.TabIndex = 76;
            // 
            // label45
            // 
            this.label45.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.Location = new System.Drawing.Point(560, 344);
            this.label45.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(53, 17);
            this.label45.TabIndex = 75;
            this.label45.Text = "FName";
            // 
            // textBoxMotherFName
            // 
            this.textBoxMotherFName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBoxMotherFName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxMotherFName.Location = new System.Drawing.Point(508, 310);
            this.textBoxMotherFName.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxMotherFName.Name = "textBoxMotherFName";
            this.textBoxMotherFName.Size = new System.Drawing.Size(168, 26);
            this.textBoxMotherFName.TabIndex = 74;
            // 
            // textBoxFatherLName
            // 
            this.textBoxFatherLName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBoxFatherLName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxFatherLName.Location = new System.Drawing.Point(331, 237);
            this.textBoxFatherLName.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxFatherLName.Name = "textBoxFatherLName";
            this.textBoxFatherLName.Size = new System.Drawing.Size(168, 26);
            this.textBoxFatherLName.TabIndex = 66;
            // 
            // label40
            // 
            this.label40.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(386, 272);
            this.label40.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(53, 17);
            this.label40.TabIndex = 67;
            this.label40.Text = "LName";
            // 
            // label41
            // 
            this.label41.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(735, 272);
            this.label41.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(56, 17);
            this.label41.TabIndex = 71;
            this.label41.Text = "MName";
            // 
            // textBoxFatherMName
            // 
            this.textBoxFatherMName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBoxFatherMName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxFatherMName.Location = new System.Drawing.Point(686, 237);
            this.textBoxFatherMName.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxFatherMName.Name = "textBoxFatherMName";
            this.textBoxFatherMName.Size = new System.Drawing.Size(168, 26);
            this.textBoxFatherMName.TabIndex = 70;
            // 
            // label42
            // 
            this.label42.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.Location = new System.Drawing.Point(560, 272);
            this.label42.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(53, 17);
            this.label42.TabIndex = 69;
            this.label42.Text = "FName";
            // 
            // textBoxFatherFName
            // 
            this.textBoxFatherFName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBoxFatherFName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxFatherFName.Location = new System.Drawing.Point(508, 237);
            this.textBoxFatherFName.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxFatherFName.Name = "textBoxFatherFName";
            this.textBoxFatherFName.Size = new System.Drawing.Size(168, 26);
            this.textBoxFatherFName.TabIndex = 68;
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(164, 314);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(115, 20);
            this.label7.TabIndex = 65;
            this.label7.Text = "Mother Name:";
            // 
            // label39
            // 
            this.label39.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(168, 241);
            this.label39.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(111, 20);
            this.label39.TabIndex = 64;
            this.label39.Text = "Father Name:";
            // 
            // comboBoxReligion
            // 
            this.comboBoxReligion.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBoxReligion.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxReligion.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxReligion.FormattingEnabled = true;
            this.comboBoxReligion.Items.AddRange(new object[] {
            "Christianity",
            "Islam",
            "Bathalism",
            "Baháʼí Faith"});
            this.comboBoxReligion.Location = new System.Drawing.Point(600, 194);
            this.comboBoxReligion.Margin = new System.Windows.Forms.Padding(4);
            this.comboBoxReligion.Name = "comboBoxReligion";
            this.comboBoxReligion.Size = new System.Drawing.Size(168, 28);
            this.comboBoxReligion.TabIndex = 62;
            this.comboBoxReligion.SelectedIndexChanged += new System.EventHandler(this.comboBoxReligion_SelectedIndexChanged);
            // 
            // maskedTextBoxEmergencyContact
            // 
            this.maskedTextBoxEmergencyContact.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.maskedTextBoxEmergencyContact.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maskedTextBoxEmergencyContact.Location = new System.Drawing.Point(331, 485);
            this.maskedTextBoxEmergencyContact.Margin = new System.Windows.Forms.Padding(4);
            this.maskedTextBoxEmergencyContact.Mask = "(999) 000-0000";
            this.maskedTextBoxEmergencyContact.Name = "maskedTextBoxEmergencyContact";
            this.maskedTextBoxEmergencyContact.Size = new System.Drawing.Size(128, 26);
            this.maskedTextBoxEmergencyContact.TabIndex = 59;
            // 
            // maskedTextBoxContactNum
            // 
            this.maskedTextBoxContactNum.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.maskedTextBoxContactNum.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maskedTextBoxContactNum.Location = new System.Drawing.Point(686, 447);
            this.maskedTextBoxContactNum.Margin = new System.Windows.Forms.Padding(4);
            this.maskedTextBoxContactNum.Mask = "(999) 000-0000";
            this.maskedTextBoxContactNum.Name = "maskedTextBoxContactNum";
            this.maskedTextBoxContactNum.Size = new System.Drawing.Size(128, 26);
            this.maskedTextBoxContactNum.TabIndex = 58;
            // 
            // textBoxHireDate
            // 
            this.textBoxHireDate.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBoxHireDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxHireDate.Location = new System.Drawing.Point(684, 485);
            this.textBoxHireDate.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxHireDate.Name = "textBoxHireDate";
            this.textBoxHireDate.ReadOnly = true;
            this.textBoxHireDate.Size = new System.Drawing.Size(128, 26);
            this.textBoxHireDate.TabIndex = 55;
            // 
            // comboBoxYearHire
            // 
            this.comboBoxYearHire.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxYearHire.FormattingEnabled = true;
            this.comboBoxYearHire.Location = new System.Drawing.Point(344, 159);
            this.comboBoxYearHire.Margin = new System.Windows.Forms.Padding(4);
            this.comboBoxYearHire.Name = "comboBoxYearHire";
            this.comboBoxYearHire.Size = new System.Drawing.Size(293, 24);
            this.comboBoxYearHire.TabIndex = 78;
            // 
            // label17
            // 
            this.label17.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(143, 85);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(152, 20);
            this.label17.TabIndex = 54;
            this.label17.Text = "Name of Company:";
            // 
            // textBoxReference
            // 
            this.textBoxReference.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBoxReference.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxReference.Location = new System.Drawing.Point(344, 191);
            this.textBoxReference.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxReference.Multiline = true;
            this.textBoxReference.Name = "textBoxReference";
            this.textBoxReference.Size = new System.Drawing.Size(293, 73);
            this.textBoxReference.TabIndex = 59;
            // 
            // textBoxNameOfCompany
            // 
            this.textBoxNameOfCompany.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBoxNameOfCompany.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxNameOfCompany.Location = new System.Drawing.Point(342, 82);
            this.textBoxNameOfCompany.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxNameOfCompany.Name = "textBoxNameOfCompany";
            this.textBoxNameOfCompany.Size = new System.Drawing.Size(292, 26);
            this.textBoxNameOfCompany.TabIndex = 53;
            // 
            // label20
            // 
            this.label20.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(204, 191);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(91, 20);
            this.label20.TabIndex = 60;
            this.label20.Text = "Reference:";
            // 
            // label18
            // 
            this.label18.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(224, 126);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(74, 20);
            this.label18.TabIndex = 56;
            this.label18.Text = "Position:";
            // 
            // textBoxPosition
            // 
            this.textBoxPosition.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBoxPosition.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxPosition.Location = new System.Drawing.Point(344, 122);
            this.textBoxPosition.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxPosition.Name = "textBoxPosition";
            this.textBoxPosition.Size = new System.Drawing.Size(293, 26);
            this.textBoxPosition.TabIndex = 55;
            // 
            // label19
            // 
            this.label19.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(210, 156);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(85, 20);
            this.label19.TabIndex = 58;
            this.label19.Text = "Year Hire:";
            // 
            // buttonFileUpload
            // 
            this.buttonFileUpload.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonFileUpload.BackColor = System.Drawing.Color.LightBlue;
            this.buttonFileUpload.FlatAppearance.BorderSize = 0;
            this.buttonFileUpload.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonFileUpload.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonFileUpload.ForeColor = System.Drawing.Color.Black;
            this.buttonFileUpload.Location = new System.Drawing.Point(223, 165);
            this.buttonFileUpload.Margin = new System.Windows.Forms.Padding(4);
            this.buttonFileUpload.Name = "buttonFileUpload";
            this.buttonFileUpload.Size = new System.Drawing.Size(93, 38);
            this.buttonFileUpload.TabIndex = 57;
            this.buttonFileUpload.Text = "Upload";
            this.buttonFileUpload.UseVisualStyleBackColor = false;
            this.buttonFileUpload.Click += new System.EventHandler(this.buttonFileUpload_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox1.Location = new System.Drawing.Point(196, 22);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(147, 135);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 56;
            this.pictureBox1.TabStop = false;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Blue;
            this.panel3.Controls.Add(this.label1);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Margin = new System.Windows.Forms.Padding(4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1469, 64);
            this.panel3.TabIndex = 57;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(29, 11);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(196, 39);
            this.label1.TabIndex = 43;
            this.label1.Text = "Add Worker";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.AutoScroll = true;
            this.flowLayoutPanel1.Controls.Add(this.panelEducationalQualification);
            this.flowLayoutPanel1.Location = new System.Drawing.Point(4, 227);
            this.flowLayoutPanel1.Margin = new System.Windows.Forms.Padding(4);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(521, 479);
            this.flowLayoutPanel1.TabIndex = 63;
            // 
            // panelEducationalQualification
            // 
            this.panelEducationalQualification.Controls.Add(this.label35);
            this.panelEducationalQualification.Controls.Add(this.comboBoxMasterYearPassed);
            this.panelEducationalQualification.Controls.Add(this.label36);
            this.panelEducationalQualification.Controls.Add(this.label37);
            this.panelEducationalQualification.Controls.Add(this.numericUpDownMasterGrade);
            this.panelEducationalQualification.Controls.Add(this.textBoxMasterName);
            this.panelEducationalQualification.Controls.Add(this.label38);
            this.panelEducationalQualification.Controls.Add(this.label31);
            this.panelEducationalQualification.Controls.Add(this.comboBoxGraduationYearPassed);
            this.panelEducationalQualification.Controls.Add(this.label32);
            this.panelEducationalQualification.Controls.Add(this.label33);
            this.panelEducationalQualification.Controls.Add(this.numericUpDownGraduationGrade);
            this.panelEducationalQualification.Controls.Add(this.textBoxGraduationName);
            this.panelEducationalQualification.Controls.Add(this.label34);
            this.panelEducationalQualification.Controls.Add(this.label30);
            this.panelEducationalQualification.Controls.Add(this.comboBoxIntermediateYearPassed);
            this.panelEducationalQualification.Controls.Add(this.label27);
            this.panelEducationalQualification.Controls.Add(this.label28);
            this.panelEducationalQualification.Controls.Add(this.numericUpDownIntermediateGrade);
            this.panelEducationalQualification.Controls.Add(this.textBoxIntermediateName);
            this.panelEducationalQualification.Controls.Add(this.label29);
            this.panelEducationalQualification.Controls.Add(this.comboBoxMatricYearPassed);
            this.panelEducationalQualification.Controls.Add(this.label26);
            this.panelEducationalQualification.Controls.Add(this.label25);
            this.panelEducationalQualification.Controls.Add(this.numericUpDownMatricGrade);
            this.panelEducationalQualification.Controls.Add(this.label24);
            this.panelEducationalQualification.Controls.Add(this.textBoxMatricName);
            this.panelEducationalQualification.Controls.Add(this.label22);
            this.panelEducationalQualification.Controls.Add(this.groupBox4);
            this.panelEducationalQualification.Location = new System.Drawing.Point(4, 4);
            this.panelEducationalQualification.Margin = new System.Windows.Forms.Padding(4);
            this.panelEducationalQualification.Name = "panelEducationalQualification";
            this.panelEducationalQualification.Size = new System.Drawing.Size(489, 603);
            this.panelEducationalQualification.TabIndex = 62;
            // 
            // label35
            // 
            this.label35.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(67, 466);
            this.label35.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(61, 20);
            this.label35.TabIndex = 92;
            this.label35.Text = "Master";
            // 
            // comboBoxMasterYearPassed
            // 
            this.comboBoxMasterYearPassed.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxMasterYearPassed.FormattingEnabled = true;
            this.comboBoxMasterYearPassed.Location = new System.Drawing.Point(383, 537);
            this.comboBoxMasterYearPassed.Margin = new System.Windows.Forms.Padding(4);
            this.comboBoxMasterYearPassed.Name = "comboBoxMasterYearPassed";
            this.comboBoxMasterYearPassed.Size = new System.Drawing.Size(72, 24);
            this.comboBoxMasterYearPassed.TabIndex = 91;
            // 
            // label36
            // 
            this.label36.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(84, 539);
            this.label36.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(60, 20);
            this.label36.TabIndex = 90;
            this.label36.Text = "Grade:";
            // 
            // label37
            // 
            this.label37.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(251, 539);
            this.label37.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(109, 20);
            this.label37.TabIndex = 89;
            this.label37.Text = "Year Passed:";
            // 
            // numericUpDownMasterGrade
            // 
            this.numericUpDownMasterGrade.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numericUpDownMasterGrade.Location = new System.Drawing.Point(161, 535);
            this.numericUpDownMasterGrade.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDownMasterGrade.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownMasterGrade.Name = "numericUpDownMasterGrade";
            this.numericUpDownMasterGrade.Size = new System.Drawing.Size(65, 26);
            this.numericUpDownMasterGrade.TabIndex = 88;
            this.numericUpDownMasterGrade.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // textBoxMasterName
            // 
            this.textBoxMasterName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBoxMasterName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxMasterName.Location = new System.Drawing.Point(161, 501);
            this.textBoxMasterName.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxMasterName.Name = "textBoxMasterName";
            this.textBoxMasterName.Size = new System.Drawing.Size(293, 26);
            this.textBoxMasterName.TabIndex = 86;
            // 
            // label38
            // 
            this.label38.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(88, 505);
            this.label38.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(58, 20);
            this.label38.TabIndex = 87;
            this.label38.Text = "Name:";
            // 
            // label31
            // 
            this.label31.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(67, 337);
            this.label31.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(91, 20);
            this.label31.TabIndex = 85;
            this.label31.Text = "Graduation";
            // 
            // comboBoxGraduationYearPassed
            // 
            this.comboBoxGraduationYearPassed.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxGraduationYearPassed.FormattingEnabled = true;
            this.comboBoxGraduationYearPassed.Location = new System.Drawing.Point(383, 407);
            this.comboBoxGraduationYearPassed.Margin = new System.Windows.Forms.Padding(4);
            this.comboBoxGraduationYearPassed.Name = "comboBoxGraduationYearPassed";
            this.comboBoxGraduationYearPassed.Size = new System.Drawing.Size(72, 24);
            this.comboBoxGraduationYearPassed.TabIndex = 84;
            // 
            // label32
            // 
            this.label32.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(84, 410);
            this.label32.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(60, 20);
            this.label32.TabIndex = 83;
            this.label32.Text = "Grade:";
            // 
            // label33
            // 
            this.label33.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(251, 410);
            this.label33.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(109, 20);
            this.label33.TabIndex = 82;
            this.label33.Text = "Year Passed:";
            // 
            // numericUpDownGraduationGrade
            // 
            this.numericUpDownGraduationGrade.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numericUpDownGraduationGrade.Location = new System.Drawing.Point(161, 406);
            this.numericUpDownGraduationGrade.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDownGraduationGrade.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownGraduationGrade.Name = "numericUpDownGraduationGrade";
            this.numericUpDownGraduationGrade.Size = new System.Drawing.Size(65, 26);
            this.numericUpDownGraduationGrade.TabIndex = 81;
            this.numericUpDownGraduationGrade.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // textBoxGraduationName
            // 
            this.textBoxGraduationName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBoxGraduationName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxGraduationName.Location = new System.Drawing.Point(161, 372);
            this.textBoxGraduationName.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxGraduationName.Name = "textBoxGraduationName";
            this.textBoxGraduationName.Size = new System.Drawing.Size(293, 26);
            this.textBoxGraduationName.TabIndex = 79;
            // 
            // label34
            // 
            this.label34.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(88, 375);
            this.label34.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(58, 20);
            this.label34.TabIndex = 80;
            this.label34.Text = "Name:";
            // 
            // label30
            // 
            this.label30.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(67, 214);
            this.label30.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(101, 20);
            this.label30.TabIndex = 78;
            this.label30.Text = "Intermediate";
            // 
            // comboBoxIntermediateYearPassed
            // 
            this.comboBoxIntermediateYearPassed.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxIntermediateYearPassed.FormattingEnabled = true;
            this.comboBoxIntermediateYearPassed.Location = new System.Drawing.Point(383, 284);
            this.comboBoxIntermediateYearPassed.Margin = new System.Windows.Forms.Padding(4);
            this.comboBoxIntermediateYearPassed.Name = "comboBoxIntermediateYearPassed";
            this.comboBoxIntermediateYearPassed.Size = new System.Drawing.Size(72, 24);
            this.comboBoxIntermediateYearPassed.TabIndex = 77;
            // 
            // label27
            // 
            this.label27.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(84, 287);
            this.label27.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(60, 20);
            this.label27.TabIndex = 76;
            this.label27.Text = "Grade:";
            // 
            // label28
            // 
            this.label28.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(251, 287);
            this.label28.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(109, 20);
            this.label28.TabIndex = 75;
            this.label28.Text = "Year Passed:";
            // 
            // numericUpDownIntermediateGrade
            // 
            this.numericUpDownIntermediateGrade.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numericUpDownIntermediateGrade.Location = new System.Drawing.Point(161, 283);
            this.numericUpDownIntermediateGrade.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDownIntermediateGrade.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownIntermediateGrade.Name = "numericUpDownIntermediateGrade";
            this.numericUpDownIntermediateGrade.Size = new System.Drawing.Size(65, 26);
            this.numericUpDownIntermediateGrade.TabIndex = 74;
            this.numericUpDownIntermediateGrade.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // textBoxIntermediateName
            // 
            this.textBoxIntermediateName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBoxIntermediateName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxIntermediateName.Location = new System.Drawing.Point(161, 249);
            this.textBoxIntermediateName.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxIntermediateName.Name = "textBoxIntermediateName";
            this.textBoxIntermediateName.Size = new System.Drawing.Size(293, 26);
            this.textBoxIntermediateName.TabIndex = 72;
            // 
            // label29
            // 
            this.label29.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(88, 252);
            this.label29.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(58, 20);
            this.label29.TabIndex = 73;
            this.label29.Text = "Name:";
            // 
            // comboBoxMatricYearPassed
            // 
            this.comboBoxMatricYearPassed.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxMatricYearPassed.FormattingEnabled = true;
            this.comboBoxMatricYearPassed.Location = new System.Drawing.Point(383, 166);
            this.comboBoxMatricYearPassed.Margin = new System.Windows.Forms.Padding(4);
            this.comboBoxMatricYearPassed.Name = "comboBoxMatricYearPassed";
            this.comboBoxMatricYearPassed.Size = new System.Drawing.Size(72, 24);
            this.comboBoxMatricYearPassed.TabIndex = 71;
            // 
            // label26
            // 
            this.label26.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(84, 169);
            this.label26.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(60, 20);
            this.label26.TabIndex = 70;
            this.label26.Text = "Grade:";
            // 
            // label25
            // 
            this.label25.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(251, 169);
            this.label25.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(109, 20);
            this.label25.TabIndex = 69;
            this.label25.Text = "Year Passed:";
            // 
            // numericUpDownMatricGrade
            // 
            this.numericUpDownMatricGrade.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numericUpDownMatricGrade.Location = new System.Drawing.Point(161, 165);
            this.numericUpDownMatricGrade.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDownMatricGrade.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownMatricGrade.Name = "numericUpDownMatricGrade";
            this.numericUpDownMatricGrade.Size = new System.Drawing.Size(65, 26);
            this.numericUpDownMatricGrade.TabIndex = 68;
            this.numericUpDownMatricGrade.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label24
            // 
            this.label24.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(67, 91);
            this.label24.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(56, 20);
            this.label24.TabIndex = 67;
            this.label24.Text = "Matric";
            // 
            // textBoxMatricName
            // 
            this.textBoxMatricName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBoxMatricName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxMatricName.Location = new System.Drawing.Point(161, 130);
            this.textBoxMatricName.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxMatricName.Name = "textBoxMatricName";
            this.textBoxMatricName.Size = new System.Drawing.Size(293, 26);
            this.textBoxMatricName.TabIndex = 64;
            // 
            // label22
            // 
            this.label22.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(88, 134);
            this.label22.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(58, 20);
            this.label22.TabIndex = 65;
            this.label22.Text = "Name:";
            // 
            // panelImage
            // 
            this.panelImage.Controls.Add(this.pictureBox1);
            this.panelImage.Controls.Add(this.buttonFileUpload);
            this.panelImage.Location = new System.Drawing.Point(4, 4);
            this.panelImage.Margin = new System.Windows.Forms.Padding(4);
            this.panelImage.Name = "panelImage";
            this.panelImage.Size = new System.Drawing.Size(521, 215);
            this.panelImage.TabIndex = 61;
            // 
            // flowLayoutPanel2
            // 
            this.flowLayoutPanel2.AutoScroll = true;
            this.flowLayoutPanel2.Controls.Add(this.panelBioData);
            this.flowLayoutPanel2.Controls.Add(this.panelWorkingExperience);
            this.flowLayoutPanel2.Controls.Add(this.panelWorkerSchedule);
            this.flowLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.flowLayoutPanel2.Location = new System.Drawing.Point(0, 64);
            this.flowLayoutPanel2.Margin = new System.Windows.Forms.Padding(4);
            this.flowLayoutPanel2.Name = "flowLayoutPanel2";
            this.flowLayoutPanel2.Size = new System.Drawing.Size(932, 794);
            this.flowLayoutPanel2.TabIndex = 60;
            // 
            // panelWorkingExperience
            // 
            this.panelWorkingExperience.Controls.Add(this.comboBoxYearHire);
            this.panelWorkingExperience.Controls.Add(this.textBoxPosition);
            this.panelWorkingExperience.Controls.Add(this.label18);
            this.panelWorkingExperience.Controls.Add(this.textBoxReference);
            this.panelWorkingExperience.Controls.Add(this.groupBox2);
            this.panelWorkingExperience.Location = new System.Drawing.Point(4, 557);
            this.panelWorkingExperience.Margin = new System.Windows.Forms.Padding(4);
            this.panelWorkingExperience.Name = "panelWorkingExperience";
            this.panelWorkingExperience.Size = new System.Drawing.Size(901, 297);
            this.panelWorkingExperience.TabIndex = 79;
            // 
            // panelWorkerSchedule
            // 
            this.panelWorkerSchedule.Controls.Add(this.groupBox3);
            this.panelWorkerSchedule.Location = new System.Drawing.Point(4, 862);
            this.panelWorkerSchedule.Margin = new System.Windows.Forms.Padding(4);
            this.panelWorkerSchedule.Name = "panelWorkerSchedule";
            this.panelWorkerSchedule.Size = new System.Drawing.Size(901, 383);
            this.panelWorkerSchedule.TabIndex = 80;
            this.panelWorkerSchedule.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // dateTimePickerSunday
            // 
            this.dateTimePickerSunday.CustomFormat = "hh:mm tt";
            this.dateTimePickerSunday.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePickerSunday.Location = new System.Drawing.Point(341, 321);
            this.dateTimePickerSunday.Margin = new System.Windows.Forms.Padding(4);
            this.dateTimePickerSunday.Name = "dateTimePickerSunday";
            this.dateTimePickerSunday.Size = new System.Drawing.Size(184, 30);
            this.dateTimePickerSunday.TabIndex = 74;
            // 
            // dateTimePickerSaturday
            // 
            this.dateTimePickerSaturday.CustomFormat = "hh:mm tt";
            this.dateTimePickerSaturday.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePickerSaturday.Location = new System.Drawing.Point(341, 283);
            this.dateTimePickerSaturday.Margin = new System.Windows.Forms.Padding(4);
            this.dateTimePickerSaturday.Name = "dateTimePickerSaturday";
            this.dateTimePickerSaturday.Size = new System.Drawing.Size(184, 30);
            this.dateTimePickerSaturday.TabIndex = 73;
            // 
            // dateTimePickerFriday
            // 
            this.dateTimePickerFriday.CustomFormat = "hh:mm tt";
            this.dateTimePickerFriday.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePickerFriday.Location = new System.Drawing.Point(341, 245);
            this.dateTimePickerFriday.Margin = new System.Windows.Forms.Padding(4);
            this.dateTimePickerFriday.Name = "dateTimePickerFriday";
            this.dateTimePickerFriday.Size = new System.Drawing.Size(184, 30);
            this.dateTimePickerFriday.TabIndex = 72;
            // 
            // dateTimePickerThursday
            // 
            this.dateTimePickerThursday.CustomFormat = "hh:mm tt";
            this.dateTimePickerThursday.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePickerThursday.Location = new System.Drawing.Point(342, 207);
            this.dateTimePickerThursday.Margin = new System.Windows.Forms.Padding(4);
            this.dateTimePickerThursday.Name = "dateTimePickerThursday";
            this.dateTimePickerThursday.Size = new System.Drawing.Size(184, 30);
            this.dateTimePickerThursday.TabIndex = 71;
            // 
            // dateTimePickerWednesday
            // 
            this.dateTimePickerWednesday.CustomFormat = "hh:mm tt";
            this.dateTimePickerWednesday.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePickerWednesday.Location = new System.Drawing.Point(342, 169);
            this.dateTimePickerWednesday.Margin = new System.Windows.Forms.Padding(4);
            this.dateTimePickerWednesday.Name = "dateTimePickerWednesday";
            this.dateTimePickerWednesday.Size = new System.Drawing.Size(184, 30);
            this.dateTimePickerWednesday.TabIndex = 70;
            // 
            // dateTimePickerTuesday
            // 
            this.dateTimePickerTuesday.CustomFormat = "hh:mm tt";
            this.dateTimePickerTuesday.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePickerTuesday.Location = new System.Drawing.Point(342, 131);
            this.dateTimePickerTuesday.Margin = new System.Windows.Forms.Padding(4);
            this.dateTimePickerTuesday.Name = "dateTimePickerTuesday";
            this.dateTimePickerTuesday.Size = new System.Drawing.Size(184, 30);
            this.dateTimePickerTuesday.TabIndex = 69;
            // 
            // dateTimePickerMonday
            // 
            this.dateTimePickerMonday.CustomFormat = "hh:mm tt";
            this.dateTimePickerMonday.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePickerMonday.Location = new System.Drawing.Point(342, 93);
            this.dateTimePickerMonday.Margin = new System.Windows.Forms.Padding(4);
            this.dateTimePickerMonday.Name = "dateTimePickerMonday";
            this.dateTimePickerMonday.Size = new System.Drawing.Size(184, 30);
            this.dateTimePickerMonday.TabIndex = 68;
            // 
            // label51
            // 
            this.label51.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label51.Location = new System.Drawing.Point(219, 330);
            this.label51.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(69, 20);
            this.label51.TabIndex = 67;
            this.label51.Text = "Sunday:";
            // 
            // label52
            // 
            this.label52.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label52.Location = new System.Drawing.Point(211, 292);
            this.label52.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(80, 20);
            this.label52.TabIndex = 66;
            this.label52.Text = "Saturday:";
            // 
            // label54
            // 
            this.label54.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label54.AutoSize = true;
            this.label54.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label54.Location = new System.Drawing.Point(231, 254);
            this.label54.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(60, 20);
            this.label54.TabIndex = 65;
            this.label54.Text = "Friday:";
            // 
            // label47
            // 
            this.label47.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.Location = new System.Drawing.Point(191, 178);
            this.label47.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(101, 20);
            this.label47.TabIndex = 63;
            this.label47.Text = "Wednesday:";
            // 
            // label48
            // 
            this.label48.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label48.Location = new System.Drawing.Point(216, 140);
            this.label48.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(77, 20);
            this.label48.TabIndex = 62;
            this.label48.Text = "Tuesday:";
            // 
            // label49
            // 
            this.label49.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label49.Location = new System.Drawing.Point(209, 216);
            this.label49.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(83, 20);
            this.label49.TabIndex = 64;
            this.label49.Text = "Thursday:";
            // 
            // label50
            // 
            this.label50.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label50.Location = new System.Drawing.Point(221, 98);
            this.label50.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(72, 20);
            this.label50.TabIndex = 61;
            this.label50.Text = "Monday:";
            // 
            // buttonAddWorker
            // 
            this.buttonAddWorker.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonAddWorker.BackColor = System.Drawing.Color.LightBlue;
            this.buttonAddWorker.FlatAppearance.BorderSize = 0;
            this.buttonAddWorker.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAddWorker.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAddWorker.Location = new System.Drawing.Point(164, 15);
            this.buttonAddWorker.Margin = new System.Windows.Forms.Padding(4);
            this.buttonAddWorker.Name = "buttonAddWorker";
            this.buttonAddWorker.Size = new System.Drawing.Size(324, 54);
            this.buttonAddWorker.TabIndex = 58;
            this.buttonAddWorker.Text = "Add Worker";
            this.buttonAddWorker.UseVisualStyleBackColor = false;
            this.buttonAddWorker.Click += new System.EventHandler(this.buttonAddWorker_Click);
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.buttonAddWorker);
            this.panel6.Location = new System.Drawing.Point(4, 714);
            this.panel6.Margin = new System.Windows.Forms.Padding(4);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(521, 78);
            this.panel6.TabIndex = 62;
            // 
            // flowLayoutPanel3
            // 
            this.flowLayoutPanel3.Controls.Add(this.panelImage);
            this.flowLayoutPanel3.Controls.Add(this.flowLayoutPanel1);
            this.flowLayoutPanel3.Controls.Add(this.panel6);
            this.flowLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Right;
            this.flowLayoutPanel3.Location = new System.Drawing.Point(940, 64);
            this.flowLayoutPanel3.Margin = new System.Windows.Forms.Padding(4);
            this.flowLayoutPanel3.Name = "flowLayoutPanel3";
            this.flowLayoutPanel3.Size = new System.Drawing.Size(529, 794);
            this.flowLayoutPanel3.TabIndex = 61;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label53);
            this.groupBox1.Controls.Add(this.textBoxWorkerID);
            this.groupBox1.Controls.Add(this.textBoxSuffix);
            this.groupBox1.Controls.Add(this.textBoxAddress);
            this.groupBox1.Controls.Add(this.textBoxMotherLName);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label43);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label44);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.textBoxMotherMName);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label45);
            this.groupBox1.Controls.Add(this.comboBoxMartialStatus);
            this.groupBox1.Controls.Add(this.textBoxMotherFName);
            this.groupBox1.Controls.Add(this.dateTimePickerbirthdate);
            this.groupBox1.Controls.Add(this.textBoxFatherLName);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label40);
            this.groupBox1.Controls.Add(this.textBoxFName);
            this.groupBox1.Controls.Add(this.label41);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.textBoxFatherMName);
            this.groupBox1.Controls.Add(this.textBoxMName);
            this.groupBox1.Controls.Add(this.label42);
            this.groupBox1.Controls.Add(this.numericUpDownNumofChil);
            this.groupBox1.Controls.Add(this.textBoxFatherFName);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label39);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.comboBoxReligion);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.maskedTextBoxEmergencyContact);
            this.groupBox1.Controls.Add(this.textBoxLName);
            this.groupBox1.Controls.Add(this.maskedTextBoxContactNum);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.textBoxHireDate);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(6, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(890, 533);
            this.groupBox1.TabIndex = 80;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Worker Biodata";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.label19);
            this.groupBox2.Controls.Add(this.textBoxNameOfCompany);
            this.groupBox2.Controls.Add(this.label20);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(3, 3);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(895, 291);
            this.groupBox2.TabIndex = 79;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Working Experience";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label51);
            this.groupBox3.Controls.Add(this.dateTimePickerFriday);
            this.groupBox3.Controls.Add(this.label52);
            this.groupBox3.Controls.Add(this.dateTimePickerSaturday);
            this.groupBox3.Controls.Add(this.label54);
            this.groupBox3.Controls.Add(this.dateTimePickerThursday);
            this.groupBox3.Controls.Add(this.label49);
            this.groupBox3.Controls.Add(this.label47);
            this.groupBox3.Controls.Add(this.dateTimePickerSunday);
            this.groupBox3.Controls.Add(this.label48);
            this.groupBox3.Controls.Add(this.dateTimePickerWednesday);
            this.groupBox3.Controls.Add(this.dateTimePickerMonday);
            this.groupBox3.Controls.Add(this.label50);
            this.groupBox3.Controls.Add(this.dateTimePickerTuesday);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(3, 3);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(895, 377);
            this.groupBox3.TabIndex = 75;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Worker Schedule";
            // 
            // groupBox4
            // 
            this.groupBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(3, 3);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(481, 597);
            this.groupBox4.TabIndex = 93;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Educational Qualification";
            // 
            // FormWorkersAdd
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1469, 858);
            this.Controls.Add(this.flowLayoutPanel3);
            this.Controls.Add(this.flowLayoutPanel2);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.buttonAddWorkers);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormWorkersAdd";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.FormAddWorkers_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownNumofChil)).EndInit();
            this.panelBioData.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.flowLayoutPanel1.ResumeLayout(false);
            this.panelEducationalQualification.ResumeLayout(false);
            this.panelEducationalQualification.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownMasterGrade)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownGraduationGrade)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownIntermediateGrade)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownMatricGrade)).EndInit();
            this.panelImage.ResumeLayout(false);
            this.flowLayoutPanel2.ResumeLayout(false);
            this.panelWorkingExperience.ResumeLayout(false);
            this.panelWorkingExperience.PerformLayout();
            this.panelWorkerSchedule.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.flowLayoutPanel3.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button buttonAddWorkers;
        private System.Windows.Forms.NumericUpDown numericUpDownNumofChil;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxLName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox comboBoxMartialStatus;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxAddress;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBoxWorkerID;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.DateTimePicker dateTimePickerbirthdate;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBoxFName;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBoxMName;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Panel panelBioData;
        private System.Windows.Forms.TextBox textBoxHireDate;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button buttonFileUpload;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.MaskedTextBox maskedTextBoxContactNum;
        private System.Windows.Forms.MaskedTextBox maskedTextBoxEmergencyContact;
        private System.Windows.Forms.Panel panelImage;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox textBoxReference;
        private System.Windows.Forms.TextBox textBoxNameOfCompany;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox textBoxPosition;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Panel panelEducationalQualification;
        private System.Windows.Forms.ComboBox comboBoxReligion;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.ComboBox comboBoxMasterYearPassed;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.NumericUpDown numericUpDownMasterGrade;
        private System.Windows.Forms.TextBox textBoxMasterName;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.ComboBox comboBoxGraduationYearPassed;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.NumericUpDown numericUpDownGraduationGrade;
        private System.Windows.Forms.TextBox textBoxGraduationName;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.ComboBox comboBoxIntermediateYearPassed;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.NumericUpDown numericUpDownIntermediateGrade;
        private System.Windows.Forms.TextBox textBoxIntermediateName;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.ComboBox comboBoxMatricYearPassed;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.NumericUpDown numericUpDownMatricGrade;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox textBoxMatricName;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBoxFatherLName;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TextBox textBoxFatherMName;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.TextBox textBoxFatherFName;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel2;
        private System.Windows.Forms.Button buttonAddWorker;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel3;
        private System.Windows.Forms.TextBox textBoxMotherLName;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.TextBox textBoxMotherMName;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.TextBox textBoxMotherFName;
        private System.Windows.Forms.ComboBox comboBoxYearHire;
        private System.Windows.Forms.Panel panelWorkingExperience;
        private System.Windows.Forms.Panel panelWorkerSchedule;
        private System.Windows.Forms.DateTimePicker dateTimePickerSunday;
        private System.Windows.Forms.DateTimePicker dateTimePickerSaturday;
        private System.Windows.Forms.DateTimePicker dateTimePickerFriday;
        private System.Windows.Forms.DateTimePicker dateTimePickerThursday;
        private System.Windows.Forms.DateTimePicker dateTimePickerWednesday;
        private System.Windows.Forms.DateTimePicker dateTimePickerTuesday;
        private System.Windows.Forms.DateTimePicker dateTimePickerMonday;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.TextBox textBoxSuffix;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
    }
}