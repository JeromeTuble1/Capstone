﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace QRCodeDemo
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            //Application.Run(new FormRegister());
            Application.Run(new FormLogin());
            //Application.Run(new FormWorkersAdd());
            //Application.Run(new FormAttendanceAdd());
            //Application.Run(new FormAttendance());
            //Application.Run(new FormWorkersAdd());
            //Application.Run(new FormAttendanceEdit());
            //Application.Run(new FormMain());
            //Application.Run(new FormAttendanceEmployeeReport());
            //Application.Run(new FormHoliday());
            //Application.Run(new FormScannerQRCode());
            //Application.Run(new FormGenerateQRCode());
            //Application.Run(new FormWorker());
            //Application.Run(new FormShifts());
            //Application.Run(new FormDashboard());
            //Application.Run(new FormScannerQRCode());

        }
    }
}
