﻿namespace QRCodeDemo
{
    partial class FormReportSelection
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonAttendanceReport = new System.Windows.Forms.Button();
            this.buttonLeaveRequestReport = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // buttonAttendanceReport
            // 
            this.buttonAttendanceReport.Location = new System.Drawing.Point(50, 12);
            this.buttonAttendanceReport.Name = "buttonAttendanceReport";
            this.buttonAttendanceReport.Size = new System.Drawing.Size(133, 23);
            this.buttonAttendanceReport.TabIndex = 0;
            this.buttonAttendanceReport.Text = "Attendance Report";
            this.buttonAttendanceReport.UseVisualStyleBackColor = true;
            this.buttonAttendanceReport.Click += new System.EventHandler(this.buttonAttendanceReport_Click);
            // 
            // buttonLeaveRequestReport
            // 
            this.buttonLeaveRequestReport.Location = new System.Drawing.Point(50, 41);
            this.buttonLeaveRequestReport.Name = "buttonLeaveRequestReport";
            this.buttonLeaveRequestReport.Size = new System.Drawing.Size(133, 23);
            this.buttonLeaveRequestReport.TabIndex = 1;
            this.buttonLeaveRequestReport.Text = "Leave Request Report";
            this.buttonLeaveRequestReport.UseVisualStyleBackColor = true;
            this.buttonLeaveRequestReport.Click += new System.EventHandler(this.buttonLeaveRequestReport_Click);
            // 
            // FormReportSelection
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(233, 76);
            this.Controls.Add(this.buttonLeaveRequestReport);
            this.Controls.Add(this.buttonAttendanceReport);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormReportSelection";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Select Report";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button buttonAttendanceReport;
        private System.Windows.Forms.Button buttonLeaveRequestReport;
    }
}