﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Linq;
using System.Media;
using System.Text;
using System.Windows.Forms;

namespace QRCodeDemo
{
    public partial class FormMain : Form
    {
        SqlConnection tublecon = new SqlConnection(Class.tublecon);
        Timer t;
        public static int numworkers = 0, countnotleave = 0;
        public static string[] WorkersIDCont = new string[9999];
        public static string[] Leave0 = new string[9999];
        public static string[] CheckAbsent = new string[9999];

        private Form activeForm;

        public FormMain()
        {
            InitializeComponent();

            t = new Timer();
            t.Tick += T_Tick;
            t.Interval = 1;
        }

        private void T_Tick(object sender, EventArgs e)
        {
            LoadDateTime();
        }

        private void FormDashboard_Load(object sender, EventArgs e)
        {
            NotAdmin();
            t.Start();
            labelTitle.Text = "";
            GetIDWorkers();
            InsertAbsent();
            LoadDataUser();
        }

        void NotAdmin()
        {
            if (Class.IsAdmin.Equals(false))
            {
                buttonAddAttendance.Visible = false;
                buttonDashboard.Visible = false;
                buttonAttendance.Visible = false;
                buttonWorkers.Visible = false;
                buttonShifts.Visible = false;
                buttonLeave.Visible = false;
                buttonRegister.Visible = false;
                buttonReport.Location = new Point(24, 302);
                labelMode.Text = "Foreman";
            }
            else
            {
                labelMode.Text = "Admin";
            }
        }

        void InsertLunchBreak()
        {
            string[] tubs = new string[5];
            tubs[0] = DateTime.Today.Date.ToLongDateString();
            tubs[1] = DateTime.Now.ToLongTimeString();
            labelDateTimeShow.Text = tubs[0] + " " + tubs[1];

            if (Convert.ToDateTime("12:00 PM") <= Convert.ToDateTime(DateTime.Now.ToShortTimeString()) &&
                Convert.ToDateTime("12:59 PM") >= Convert.ToDateTime(DateTime.Now.ToShortTimeString()))
            {
                SqlCommand cmd1 = new SqlCommand("SELECT * FROM tblWorkersBioData", tublecon);
                SqlDataAdapter da = new SqlDataAdapter(cmd1);
                DataTable dt = new DataTable();
                da.Fill(dt);

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    SqlCommand cmd2 = new SqlCommand(@"SELECT * FROM tblWorkersAttendance WHERE WorkersID = @WorkersID AND [Date] = @Date AND [Status] = @OnTime OR WorkersID = @WorkersID AND [Date] = @Date AND [Status] = @Late ", tublecon);
                    cmd2.Parameters.AddWithValue("@Date", Convert.ToDateTime(DateTime.Now.ToShortDateString()));
                    cmd2.Parameters.AddWithValue("@OnTime", "OnTime");
                    cmd2.Parameters.AddWithValue("@Late", "Late");
                    cmd2.Parameters.AddWithValue("@WorkersID", dt.Rows[i][0].ToString());
                    SqlDataAdapter da1 = new SqlDataAdapter(cmd2);
                    DataTable dt1 = new DataTable();
                    da1.Fill(dt1);

                    if (dt1.Rows.Count.Equals(1))
                    {
                        SqlCommand cmd3 = new SqlCommand(@"SELECT * FROM tblWorkersAttendance WHERE WorkersID = @WorkersID AND [Date] = @Date AND [Status] = @Status", tublecon);
                        cmd3.Parameters.AddWithValue("@WorkersID", dt.Rows[i][0].ToString());
                        cmd3.Parameters.AddWithValue("@Date", Convert.ToDateTime(DateTime.Now.ToShortDateString()));
                        cmd3.Parameters.AddWithValue("@Status", "Lunch Break");
                        SqlDataAdapter da2 = new SqlDataAdapter(cmd3);
                        DataTable dt2 = new DataTable();
                        da2.Fill(dt2);

                        if (dt2.Rows.Count.Equals(0))
                        {
                            SqlCommand cmd = new SqlCommand("INSERT INTO tblWorkersAttendance (WorkersID,Status,Date,Schedule,Day,CheckOut) VALUES (@WorkersID,@Status,@Date,@Schedule,@Day,@CheckOut)", tublecon);
                            cmd.Parameters.AddWithValue("@WorkersID", dt.Rows[i][0].ToString());
                            cmd.Parameters.AddWithValue("@Date", Convert.ToDateTime(DateTime.Now.ToShortDateString()));
                            cmd.Parameters.AddWithValue("@Status", "Lunch Break");
                            cmd.Parameters.AddWithValue("@Schedule", Convert.ToDateTime("12:00 PM"));
                            cmd.Parameters.AddWithValue("@Day", Convert.ToString(DateTime.Now.DayOfWeek));
                            cmd.Parameters.AddWithValue("@CheckOut", Convert.ToDateTime("12:00 PM"));
                            tublecon.Open();
                            cmd.ExecuteNonQuery();
                            tublecon.Close();
                        }
                    }
                }
            }
        }

        void GetIDWorkers()
        {
            SqlCommand cmd = new SqlCommand("SELECT WorkersID FROM tblWorkersBioData", tublecon);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            numworkers = dt.Rows.Count;

            for (int i = 0; i < numworkers; i++)
            {
                WorkersIDCont[i] = dt.Rows[i][0].ToString();
            }
        }



        void InsertAbsent()
        {
            for (int i = 0; i < numworkers; i++)
            {
                SqlCommand cmd0 = new SqlCommand("SELECT * FROM tblWorkersAttendance WHERE WorkersID=@WorkersID AND Date=@Date", tublecon);
                cmd0.Parameters.AddWithValue("@WorkersID", WorkersIDCont[i]);
                cmd0.Parameters.AddWithValue("@Date", Convert.ToDateTime(DateTime.Now.ToShortDateString()));
                SqlDataAdapter da0 = new SqlDataAdapter(cmd0);
                DataTable dt0 = new DataTable();
                da0.Fill(dt0);

                if (dt0.Rows.Count.Equals(0))
                {
                    string Date = "", ColDate = "", DateDayNight = "";
                    switch (Convert.ToString(DateTime.Now.DayOfWeek))
                    {
                        case "Monday":    Date = "Monday";    ColDate = "MonSched"; DateDayNight = "MonDayNight"; break;
                        case "Tuesday":   Date = "Tuesday";   ColDate = "TueSched"; DateDayNight = "TueDayNight"; break;
                        case "Wednesday": Date = "Wednesday"; ColDate = "WedSched"; DateDayNight = "WedDayNight"; break;
                        case "Thursday":  Date = "Thursday";  ColDate = "ThuSched"; DateDayNight = "ThuDayNight"; break;
                        case "Friday":    Date = "Friday";    ColDate = "FriSched"; DateDayNight = "FriDayNight"; break;
                        case "Saturday":  Date = "Saturday";  ColDate = "SatSched"; DateDayNight = "SatDayNight"; break;
                        case "Sunday":    Date = "Sunday";    ColDate = "SunSched"; DateDayNight = "SunDayNight"; break;
                    }
                    SqlCommand cmd = new SqlCommand("SELECT * FROM tblWorkersSchedule WHERE WorkersID = @WorkersID AND NOT " + ColDate + " = '' ", tublecon);
                    cmd.Parameters.AddWithValue("@WorkersID", WorkersIDCont[i]);
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    if (dt.Rows.Count.Equals(1))
                    {
                        SqlCommand cmd1 = new SqlCommand("INSERT INTO tblWorkersAttendance (WorkersID, Schedule, Status, Day, [Date]) VALUES (@WorkersID, @Schedule, @Status, @Day, @Date)", tublecon);
                        cmd1.Parameters.AddWithValue("@WorkersID", WorkersIDCont[i]);
                        cmd1.Parameters.AddWithValue("@Schedule", Convert.ToDateTime(dt.Rows[0][ColDate] + " " + dt.Rows[0][DateDayNight]));
                        cmd1.Parameters.AddWithValue("@Status", "Absent");
                        cmd1.Parameters.AddWithValue("@Day", DateTime.Today.DayOfWeek.ToString());
                        cmd1.Parameters.AddWithValue("@Date", Convert.ToDateTime(DateTime.Now.ToShortDateString()));
                        tublecon.Open();
                        cmd1.ExecuteNonQuery();
                        tublecon.Close();
                    }
                }
            }
        }

        void LoadDateTime()
        {
            string []tubs = new string[5];
            tubs[0] = DateTime.Today.Date.ToLongDateString();
            tubs[1] = DateTime.Now.ToLongTimeString();

            labelDateTimeShow.Text = tubs[0] + " " + tubs[1];
        }

        private void OpenChildForm(Form childForm, object btnSender) 
        {
            if (activeForm != null)
            {
                activeForm.Close();
            }
            activeForm = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            this.panelDesktopPanel.Controls.Add(childForm);
            this.panelDesktopPanel.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();
        }

        void LoadDataUser()
        {
            SqlCommand cmd = new SqlCommand("SELECT Picture, UserName, ID FROM tblLogin WHERE ID = @ID AND Password = @Password", tublecon);
            cmd.Parameters.AddWithValue("@ID", Class.EmployeeID);
            cmd.Parameters.AddWithValue("@Password", Class.EmployeePassword);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            MemoryStream mem = new MemoryStream((Byte[])(ds.Tables[0].Rows[0][0]));
            pictureBox1.Image = Image.FromStream(mem);
            GraphicsPath gp = new GraphicsPath();
            gp.AddEllipse(0, 0, pictureBox1.Width - 10, pictureBox1.Height - 10);
            Region rg = new Region(gp);
            pictureBox1.Region = rg;
            labelUsername.Text = ds.Tables[0].Rows[0][1].ToString();
            labelUserID.Text = ds.Tables[0].Rows[0][2].ToString();
        }

        void Logout()
        {
            DialogResult dialogResult = MessageBox.Show("Are you sure?", "Logout", MessageBoxButtons.YesNo);

            if (dialogResult == DialogResult.Yes)
            {
                SqlCommand cmd = new SqlCommand("UPDATE tblEmpAdTemp SET LoggedOutDate = @LoggedOutDate,LoggedOutTime = @LoggedOutTime WHERE ID = @ID", tublecon);
                cmd.Parameters.AddWithValue("@ID", Class.EmployeeID);
                cmd.Parameters.AddWithValue("@LoggedOutDate", Convert.ToDateTime(DateTime.Now.ToShortDateString()));
                cmd.Parameters.AddWithValue("@LoggedOutTime", Convert.ToDateTime(DateTime.Now.ToLongTimeString()));
                tublecon.Open();
                cmd.ExecuteNonQuery();
                tublecon.Close();

                if (Class.IsAdmin.Equals(true))
                {
                    FormLogin FL = new FormLogin();
                    this.Hide();
                    FL.ShowDialog();
                }
                else
                {
                    FormLogin LF = new FormLogin();
                    this.Hide();
                    LF.ShowDialog();
                }
            }
        }

        private void buttonLogout_Click(object sender, EventArgs e)
        {
            Logout();
            LogoutHover();
        }

        void SoundHover() {
            SoundPlayer sp = new SoundPlayer();
            sp.SoundLocation = "../../Sound/338229__fachii__button-hover.wav";
            sp.Play();
        }

        private void buttonDashboard_Click(object sender, EventArgs e)
        {
            SoundHover();
            GetIDWorkers();
            InsertAbsent();
            DashBoard();
            InsertLunchBreak();
            OpenChildForm(new FormDashboard(), sender);
            labelTitle.Text = "Dashboard";
        }

        private void buttonAttendance_Click(object sender, EventArgs e)
        {
            SoundHover();
            GetIDWorkers();
            InsertAbsent();
            Attendance();
            InsertLunchBreak();

            OpenChildForm(new FormAttendance(), sender); 
            Class.AttendanceSelection = ""; 
            labelTitle.Text = "Attendance";
        }

        private void buttonReport_Click(object sender, EventArgs e)
        {
            SoundHover();
            GetIDWorkers();
            InsertAbsent();
            Reports();
            InsertLunchBreak();
            FormReportSelection RS = new FormReportSelection();
            RS.ShowDialog();
            try
            {
                if (Class.ReportSelection.Equals("AttendanceReport"))
                {
                    OpenChildForm(new FormAttendanceReport(), sender);
                    labelTitle.Text = "Workers Attendance Reports";
                    Class.ReportSelection = "";
                }
                else if (Class.ReportSelection.Equals("LeaveRequestReport"))
                {
                    OpenChildForm(new FormLeaveReport(), sender);
                    labelTitle.Text = "Leave Request Reports";
                    Class.ReportSelection = "";
                }
                else if (Class.ReportSelection.Equals("EmployeeReport"))
                {
                    OpenChildForm(new FormAttendanceForeAdReport(), sender);
                    labelTitle.Text = "Attendance Report";
                    Class.ReportSelection = "";
                }
                else if (Class.ReportSelection.Equals("WorkersAttendanceReport"))
                {
                    Class.OverallWorkerAttendance = true;
                    FormFromTo FT = new FormFromTo();
                    FT.ShowDialog();
                    Class.ReportSelection = "";
                }
            }
            catch { }
        }

        private void buttonWorkers_Click(object sender, EventArgs e)
        {
            SoundHover();
            Workers();
            InsertLunchBreak();
            OpenChildForm(new FormWorker(), sender);
            labelTitle.Text = "Workers";
        }

        private void buttonShifts_Click(object sender, EventArgs e)
        {
            SoundHover();
            Shift();
            InsertLunchBreak();
            OpenChildForm(new FormShifts(), sender);
            labelTitle.Text = "Shifts";
        }

        private void buttonHoliday_Click(object sender, EventArgs e)
        {
            SoundHover();
            GetIDWorkers();
            InsertAbsent();
            Leave();
            InsertLunchBreak();
            OpenChildForm(new FormLeave(), sender);
            labelTitle.Text = "Leave";
        }

        void DashBoard()
        { 
            buttonDashboard.BackColor = Color.Blue;
            buttonAttendance.BackColor = Color.FromArgb(51, 51, 76);
            buttonWorkers.BackColor = Color.FromArgb(51, 51, 76);
            buttonShifts.BackColor = Color.FromArgb(51, 51, 76);
            buttonLeave.BackColor = Color.FromArgb(51, 51, 76);
            buttonReport.BackColor = Color.FromArgb(51, 51, 76);
            buttonLogout.BackColor = Color.FromArgb(51, 51, 76);
        }
        void Attendance()
        {
            buttonDashboard.BackColor = Color.FromArgb(51, 51, 76);
            buttonAttendance.BackColor = Color.Blue;
            buttonWorkers.BackColor = Color.FromArgb(51, 51, 76);
            buttonShifts.BackColor = Color.FromArgb(51, 51, 76);
            buttonLeave.BackColor = Color.FromArgb(51, 51, 76);
            buttonReport.BackColor = Color.FromArgb(51, 51, 76);
            buttonLogout.BackColor = Color.FromArgb(51, 51, 76);
        }
        void Workers()
        {
            buttonDashboard.BackColor = Color.FromArgb(51, 51, 76);
            buttonAttendance.BackColor = Color.FromArgb(51, 51, 76);
            buttonWorkers.BackColor = Color.Blue;
            buttonShifts.BackColor = Color.FromArgb(51, 51, 76);
            buttonLeave.BackColor = Color.FromArgb(51, 51, 76);
            buttonReport.BackColor = Color.FromArgb(51, 51, 76);
            buttonLogout.BackColor = Color.FromArgb(51, 51, 76);
        }
        void Shift()
        {
            buttonDashboard.BackColor = Color.FromArgb(51, 51, 76);
            buttonAttendance.BackColor = Color.FromArgb(51, 51, 76);
            buttonWorkers.BackColor = Color.FromArgb(51, 51, 76);
            buttonShifts.BackColor = Color.Blue;
            buttonLeave.BackColor = Color.FromArgb(51, 51, 76);
            buttonReport.BackColor = Color.FromArgb(51, 51, 76);
            buttonLogout.BackColor = Color.FromArgb(51, 51, 76);
        }
        void Leave()
        {
            buttonDashboard.BackColor = Color.FromArgb(51, 51, 76);
            buttonAttendance.BackColor = Color.FromArgb(51, 51, 76);
            buttonWorkers.BackColor = Color.FromArgb(51, 51, 76);
            buttonShifts.BackColor = Color.FromArgb(51, 51, 76);
            buttonLeave.BackColor = Color.Blue;
            buttonReport.BackColor = Color.FromArgb(51, 51, 76);
            buttonLogout.BackColor = Color.FromArgb(51, 51, 76);
        }
        void Reports()
        {
            buttonDashboard.BackColor = Color.FromArgb(51, 51, 76);
            buttonAttendance.BackColor = Color.FromArgb(51, 51, 76);
            buttonWorkers.BackColor = Color.FromArgb(51, 51, 76);
            buttonShifts.BackColor = Color.FromArgb(51, 51, 76);
            buttonLeave.BackColor = Color.FromArgb(51, 51, 76);
            buttonReport.BackColor = Color.Blue;
            buttonLogout.BackColor = Color.FromArgb(51, 51, 76);
        }
        void LogoutHover()
        {
            buttonDashboard.BackColor = Color.FromArgb(51, 51, 76);
            buttonAttendance.BackColor = Color.FromArgb(51, 51, 76);
            buttonWorkers.BackColor = Color.FromArgb(51, 51, 76);
            buttonShifts.BackColor = Color.FromArgb(51, 51, 76);
            buttonLeave.BackColor = Color.FromArgb(51, 51, 76);
            buttonReport.BackColor = Color.FromArgb(51, 51, 76);
            buttonLogout.BackColor = Color.Blue;
        }

        private void buttonAddAttendance_Click(object sender, EventArgs e)
        {
            FormAttendanceAdd FAA = new FormAttendanceAdd();
            FAA.ShowDialog();
        }

        private void buttonRegister_Click(object sender, EventArgs e)
        {
            FormRegister FR = new FormRegister();
            FR.ShowDialog();
        }
    }
}
