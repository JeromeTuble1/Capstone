﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace QRCodeDemo
{
    public partial class FormRegister : Form
    {
        SqlConnection tublecon = new SqlConnection(Class.tublecon);
        MemoryStream ms;

        public FormRegister()
        {
            InitializeComponent();
        }

        void CreateNewEmployeeID() {
            SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM tblLogin WHERE ID LIKE @ThisYear AND ID LIKE @Foreman", tublecon);
            cmd.Parameters.AddWithValue("@ThisYear", "%" + DateTime.Now.Year + "%");
            cmd.Parameters.AddWithValue("@Foreman", "%FOREMAN%");
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            if (Convert.ToInt16(dt.Rows[0][0]).Equals(0))
            {
                Class.EmployeeID = "1";
            }
            else
            {
                Class.EmployeeID = (Convert.ToInt16(dt.Rows[0][0]) + 1).ToString();
            }
            if (Convert.ToInt16(Class.EmployeeID) < 10)
            {
                Class.EmployeeID = "000" + Class.EmployeeID;
            }
            else if (Convert.ToInt16(Class.EmployeeID) < 100)
            {
                Class.EmployeeID = "00" + Class.EmployeeID;
            }
            else if (Convert.ToInt16(Class.EmployeeID) < 1000)
            {
                Class.EmployeeID = "0" + Class.EmployeeID;
            }
            textBoxEmployeeID.Text = DateTime.Now.Year + "-" + Class.EmployeeID + "-FOREMAN-DJAAS";
        }

        void CreateNewAdminID()
        {
            SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM tblLogin WHERE ID LIKE @AdminID AND ID LIKE @IsAdmin", tublecon);
            cmd.Parameters.AddWithValue("@AdminID", "%" + DateTime.Now.Year + "%");
            cmd.Parameters.AddWithValue("@IsAdmin", "%ADMIN%");
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            if (Convert.ToInt16(dt.Rows[0][0]).Equals(0))
            {
                Class.EmployeeID = "1";
            }
            else
            {
                Class.EmployeeID = (Convert.ToInt16(dt.Rows[0][0]) + 1).ToString();
            }
            if (Convert.ToInt16(Class.EmployeeID) < 10)
            {
                Class.EmployeeID = "000" + Class.EmployeeID;
            }
            else if (Convert.ToInt16(Class.EmployeeID) < 100)
            {
                Class.EmployeeID = "00" + Class.EmployeeID;
            }
            else if (Convert.ToInt16(Class.EmployeeID) < 1000)
            {
                Class.EmployeeID = "0" + Class.EmployeeID;
            }
            textBoxEmployeeID.Text = DateTime.Now.Year + "-" + Class.EmployeeID + "-ADMIN-DJAAS";
        }

        void UserNameSearchPair()
        {
            SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM tblLogin WHERE UserName = @UserName", tublecon);
            cmd.Parameters.AddWithValue("@UserName", textBoxUserName.Text);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            Class.UserSearchPair = dt.Rows[0][0].ToString();
        }

        void FullNameSearchPair() {
            SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM tblLogin WHERE FName = @FName AND LName = @LName AND MName = @MName", tublecon);
            cmd.Parameters.AddWithValue("@LName", textBoxLName.Text);
            cmd.Parameters.AddWithValue("@MName", textBoxMName.Text);
            cmd.Parameters.AddWithValue("@FName", textBoxFName.Text);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            Class.FullNameSearchPair = dt.Rows[0][0].ToString();
        }

        void PasswordSearchPair() {
            SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM tblLogin WHERE Password = @Password", tublecon);
            cmd.Parameters.AddWithValue("@Password", textBoxPassword.Text);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            Class.PasswordSearchPair = dt.Rows[0][0].ToString();
        }

        void Register()
        {
            int stackerror = 0;
            if (radioButtonMale.Checked.Equals(false) && 
                radioButtonFemale.Checked.Equals(false))
            {
                MessageBox.Show("Please select one in Group Gender");
                stackerror++;
            }
            if (textBoxConfirmPassword.Text == "")
            {
                MessageBox.Show("Please enter confirm password ");
                stackerror++;
            }
            if (textBoxPassword.Text == "")
            {
                MessageBox.Show("Please enter password ");
                stackerror++;
            }
            if (textBoxPassword.Text != textBoxConfirmPassword.Text)
            {
                MessageBox.Show("Password and Confirm Password are not same");
                stackerror++;
            }
            if (Convert.ToInt16(Class.PasswordSearchPair) > 0)
            {
                MessageBox.Show("Password Already exist please try another ");
                stackerror++;
            }
            if (Convert.ToInt16(Class.UserSearchPair) > 0)
            {
                MessageBox.Show("UserName Already exist please try another ");
                stackerror++;
            }
            if (Convert.ToInt16(Class.FullNameSearchPair) > 0)
            {
                MessageBox.Show("FullName Already exist please try another ");
                stackerror++;
            }
            if (maskedTextBoxContactNum.Text.Length < 14)
            {
                MessageBox.Show("Fill the Contact Number");
                stackerror++;
            }
            if (maskedTextBoxEmergencyContact.Text.Length < 14)
            {
                MessageBox.Show("Fill the Emergency Contact");
                stackerror++;
            }
            if (pictureBox1.Image == null)
            {
                MessageBox.Show("Upload your Photo");
                stackerror++;
            }
            string[] consplitdate = dateTimePickerBirthDate.Value.ToString().Split('/');
            string[] getYear = consplitdate[2].Split(' ');
            int age = Convert.ToInt16(DateTime.Now.Year.ToString()) - Convert.ToInt16(getYear[0]);
            if (age < 18) { MessageBox.Show("Can't accept your age below 17"); stackerror++; }
            if (textBoxAddress.Text == "") { MessageBox.Show("Fill the address"); stackerror++; }

            if (stackerror.Equals(0))
            {
                SqlCommand cmd1 = new SqlCommand("INSERT INTO tblLogin (ID, UserName, FName, LName, MName, Password, Gender, Birthdate, Address, DateCreated, ContactNumber, EmergencyContact, Picture) VALUES (@ID, @UserName, @FName, @LName, @MName, @Password, @Gender, @Birthdate, @Address, @DateCreated, @ContactNumber, @EmergencyContact, @Picture)", tublecon);
                cmd1.Parameters.AddWithValue("@ID", textBoxEmployeeID.Text);
                cmd1.Parameters.AddWithValue("@UserName", textBoxUserName.Text);
                cmd1.Parameters.AddWithValue("@LName", textBoxLName.Text);
                cmd1.Parameters.AddWithValue("@FName", textBoxFName.Text);
                cmd1.Parameters.AddWithValue("@MName", textBoxMName.Text);
                cmd1.Parameters.AddWithValue("@Password", textBoxPassword.Text);
                cmd1.Parameters.AddWithValue("@Gender", Class.Gender);
                cmd1.Parameters.AddWithValue("@Birthdate", Convert.ToDateTime(dateTimePickerBirthDate.Text));
                cmd1.Parameters.AddWithValue("@Address", textBoxAddress.Text);
                cmd1.Parameters.AddWithValue("@DateCreated", Convert.ToDateTime(DateTime.Today.Date.ToShortDateString()));
                cmd1.Parameters.AddWithValue("@ContactNumber", Class.contfirstandfirsttuble[0] + Class.contsecondthirdtuble[0] + Class.contsecondthirdtuble[1]);
                cmd1.Parameters.AddWithValue("@EmergencyContact", Class.emerfirstandfirsttuble[0] + Class.emersecondthirdtuble[0] + Class.emersecondthirdtuble[1]);
                ms = new MemoryStream();
                pictureBox1.Image.Save(ms, ImageFormat.Jpeg);
                byte[] photo_array = new byte[ms.Length];
                ms.Position = 0;
                ms.Read(photo_array, 0, photo_array.Length);
                cmd1.Parameters.AddWithValue("@Picture", photo_array);
                tublecon.Open();
                cmd1.ExecuteNonQuery();
                tublecon.Close();
                MessageBox.Show("New Account is created");
                this.Hide();
            }
        }
        public static byte[] GetPhoto(string filePath)
        {
            FileStream stream = new FileStream(filePath, FileMode.Open, FileAccess.Read);
            BinaryReader reader = new BinaryReader(stream);

            byte[] photo = reader.ReadBytes((int)stream.Length);

            reader.Close();
            stream.Close();

            return photo;
        }

        void FileUpload() 
        {
            openFileDialog1.InitialDirectory = "C://Desktop";
            openFileDialog1.Title = "Select image to be upload.";
            openFileDialog1.Filter = "Image Only(*.jpg; *.jpeg; *.gif; *.bmp; *.png)|*.jpg; *.jpeg; *.gif; *.bmp; *.png";
            openFileDialog1.FilterIndex = 1;
            try
            {
                if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    if (openFileDialog1.CheckFileExists)
                    {
                        string path = Path.GetFullPath(openFileDialog1.FileName);
                        Class.Picture = GetPhoto(path);
                        pictureBox1.Image = new Bitmap(openFileDialog1.FileName);
                        pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
                    }
                }
                else
                {
                    MessageBox.Show("Please Upload image.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        void ThisClose()
        {
            DialogResult dialogResult = MessageBox.Show("Are you sure?", "Close", MessageBoxButtons.YesNo);

            if (dialogResult == DialogResult.Yes)
            {
                this.Close();
            }
        }

        void SplitContacts()
        {
            Class.contsplitspace = maskedTextBoxContactNum.Text;
            Class.contspittuble = Class.contsplitspace.Split(' ');
            Class.contfirsttuble = Class.contspittuble[0].Split('(');
            Class.contsecondthirdtuble = Class.contspittuble[1].Split('-');
            Class.contfirstandfirsttuble = Class.contfirsttuble[1].Split(')');
            Class.emersplitspace = maskedTextBoxEmergencyContact.Text;
            Class.emerspittuble = Class.emersplitspace.Split(' ');
            Class.emerfirsttuble = Class.emerspittuble[0].Split('(');
            Class.emersecondthirdtuble = Class.emerspittuble[1].Split('-');
            Class.emerfirstandfirsttuble = Class.emerfirsttuble[1].Split(')');
        }

        private void buttonClose_Click(object sender, EventArgs e)
        {
            ThisClose();
        }

        private void buttonFileUpload_Click(object sender, EventArgs e)
        {
            FileUpload();
        }

        private void radioButtonMale_CheckedChanged(object sender, EventArgs e)
        {
            Class.Gender = "MALE";
        }

        private void radioButtonFemale_CheckedChanged(object sender, EventArgs e)
        {
            Class.Gender = "FEMALE";
        }

        private void checkBoxShowPassword_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxShowPassword.Checked.Equals(true))
            {
                textBoxPassword.PasswordChar = '\0';
            }
            else if (checkBoxShowPassword.Checked.Equals(false))
            {
                textBoxPassword.PasswordChar = '*';
            }
        }

        private void checkBoxShowConfirmPassword_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxShowConfirmPassword.Checked.Equals(true))
            {
                textBoxConfirmPassword.PasswordChar = '\0';
            }
            else if (checkBoxShowConfirmPassword.Checked.Equals(false))
            {
                textBoxConfirmPassword.PasswordChar = '*';
            }
        }

        private void jbtButtonRegister_Click(object sender, EventArgs e)
        {
            SplitContacts();
            UserNameSearchPair();
            FullNameSearchPair();
            PasswordSearchPair();
            Register();
        }

        private void radioButtonEmployee_CheckedChanged(object sender, EventArgs e)
        {
            CreateNewEmployeeID();
        }

        private void radioButtonAdmin_CheckedChanged(object sender, EventArgs e)
        {
            CreateNewAdminID();
        }

        private void buttonUpload_Click(object sender, EventArgs e)
        {
            FormCamera SQRC = new FormCamera();
            SQRC.ShowDialog();
            if (Class.PictureCapture != null)
            {
                MemoryStream mem = new MemoryStream((Byte[])(Class.PictureCapture));
                pictureBox1.Image = Image.FromStream(mem);
                Class.PictureCapture = null;
            }
        }
    }
}
