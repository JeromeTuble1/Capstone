﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace QRCodeDemo
{
    public partial class FormLoginAdmin : Form
    {
        SqlConnection con = new SqlConnection(Class.tublecon);

        public FormLoginAdmin()
        {
            InitializeComponent();
        }

        private void FormLogin_Load(object sender, EventArgs e)
        {

        }

        private void buttonLogin_Click(object sender, EventArgs e)
        {
            Login();
        }

        void SuccessLogIn(string EmployeeID)
        {
            SqlCommand cmd = new SqlCommand("INSERT INTO tblEmpAdTemp (ID,LoggedInDate,LoggedInTime) VALUES (@ID,@LoggedInDate,@LoggedInTime)", con);
            cmd.Parameters.AddWithValue("@ID", EmployeeID);
            cmd.Parameters.AddWithValue("@LoggedInDate", Convert.ToDateTime(DateTime.Today.Date.ToShortDateString()));
            cmd.Parameters.AddWithValue("@LoggedInTime", Convert.ToDateTime(DateTime.Now.ToLongTimeString()));
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }

        private static string FindEmployeeID(string username, string password, SqlConnection con)
        {
            SqlCommand cmd = new SqlCommand("SELECT ID FROM tblLogin WHERE UserName = @Username AND Password = @Password", con);
            cmd.Parameters.AddWithValue("@Username", username);
            cmd.Parameters.AddWithValue("@Password", password);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            return dt.Rows[0][0].ToString();
        }

        private static string FindEmployeePassword(string username, string password, SqlConnection con)
        {
            SqlCommand cmd = new SqlCommand("SELECT Password FROM tblLogin WHERE UserName = @Username AND Password = @Password", con);
            cmd.Parameters.AddWithValue("@Username", username);
            cmd.Parameters.AddWithValue("@Password", password);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            return dt.Rows[0][0].ToString();
        }

        void Login()
        {
            SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM tblLogin WHERE UserName = @Username AND Password = @Password AND [ID] LIKE '%ADMIN%'", con);
            cmd.Parameters.AddWithValue("@Username", textBoxUserName.Text);
            cmd.Parameters.AddWithValue("@Password", textBoxPassword.Text);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (Convert.ToInt16(dt.Rows[0][0].ToString()) > 0)
            {
                SuccessLogIn(FindEmployeeID(textBoxUserName.Text, textBoxPassword.Text, con));
                Class.EmployeeID = FindEmployeeID(textBoxUserName.Text, textBoxPassword.Text, con);
                Class.EmployeePassword = FindEmployeePassword(textBoxUserName.Text, textBoxPassword.Text, con);
                Class.IsAdmin = true;
                this.Hide();
                FormMain db = new FormMain();
                db.ShowDialog();
            }
            else
            {
                MessageBox.Show("Invalid username or password");
            }
        }

        private void checkBoxShowPassword_CheckedChanged(object sender, EventArgs e)
        {
            
            if (checkBoxShowPassword.Checked.Equals(true))
            {
                textBoxPassword.PasswordChar = '\0';
            }
            else if (checkBoxShowPassword.Checked.Equals(false))
            {
                textBoxPassword.PasswordChar = '*';
            }
        }

        private void buttonClose_Click(object sender, EventArgs e)
        {
            ThisClose();
        }

        void ThisClose()
        {
            DialogResult dialogResult = MessageBox.Show("Are you sure?", "Close", MessageBoxButtons.YesNo);

            if (dialogResult == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void linkLabelForgotPassword_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            FormForeAdForgotPassword EFP = new FormForeAdForgotPassword();
            EFP.ShowDialog();
        }

        private void jbtButtonLogin_Click(object sender, EventArgs e)
        {
            Login();
        }

        private void jbtButtonRegister_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormRegister FR = new FormRegister();
            FR.ShowDialog();
        }
    }
}
