﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/////////////////////////////////////////////////
using System.Security.Cryptography;
using WinFormCharpWebCam;
using AForge;
using AForge.Video;
using AForge.Video.DirectShow;
using System.IO;
using System.Drawing.Imaging;

namespace QRCodeDemo
{
    public partial class FormCamera : Form
    {
        WebCam webcam;
        MemoryStream ms;
        public FormCamera()
        {
            InitializeComponent();
        }

        private FilterInfoCollection CaptureDevices;
        private VideoCaptureDevice videoSource;

        private void FormCamera_Load(object sender, EventArgs e)
        {
            CaptureDevices = new FilterInfoCollection(FilterCategory.VideoInputDevice);

            foreach (FilterInfo Device in CaptureDevices)
            {
                comboBox1.Items.Add(Device.Name);
            }

            comboBox1.SelectedIndex = 0;
            videoSource = new VideoCaptureDevice();
        }

        private void bntStart_Click(object sender, EventArgs e)
        {
            videoSource = new VideoCaptureDevice(CaptureDevices[comboBox1.SelectedIndex].MonikerString);
            videoSource.NewFrame += new NewFrameEventHandler(videoSource_NewFrame);
            videoSource.Start();
        }

        void videoSource_NewFrame(object sender, NewFrameEventArgs eventArgs)
        {
            PictureBoxVideo.Image = (Bitmap)eventArgs.Frame.Clone();
        }

        private void bntReset_Click(object sender, EventArgs e)
        {
            videoSource.Stop();
            PictureBoxCapture.Image = null;
            PictureBoxCapture.Invalidate();
            PictureBoxVideo.Image = null;
            PictureBoxVideo.Invalidate();
        }

        private void bntPause_Click(object sender, EventArgs e)
        {
            videoSource.Stop();
        }

        private void bntCapture_Click(object sender, EventArgs e)
        {
            if (PictureBoxVideo.Image != null)
            {
                PictureBoxCapture.Image = (Bitmap)PictureBoxVideo.Image.Clone();
            }

        }

        private void ButtonExit_Click(object sender, EventArgs e)
        {
            if (videoSource.IsRunning.Equals(true))
            {
                videoSource.Stop();
            }
            this.Close();
        }

        private void buttonUpload_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Are you sure?", "Upload Image", MessageBoxButtons.YesNo);

            if (dialogResult == DialogResult.Yes)
            {
                videoSource.Stop();
                ms = new MemoryStream();
                PictureBoxCapture.Image.Save(ms, ImageFormat.Jpeg);
                byte[] photo_array = new byte[ms.Length];
                ms.Position = 0;
                ms.Read(photo_array, 0, photo_array.Length);
                Class.PictureCapture = photo_array;
                this.Close();
            }
        }

        private void buttonClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
