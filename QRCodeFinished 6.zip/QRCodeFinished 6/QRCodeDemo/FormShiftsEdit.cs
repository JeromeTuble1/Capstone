﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace QRCodeDemo
{
    public partial class FormShiftsEdit : Form
    {
        SqlConnection con = new SqlConnection(Class.tublecon);
        string StackDescription;
        string[] Week = new string[7];

        public FormShiftsEdit()
        {
            InitializeComponent();
        }

        private void FormShiftsEdit_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        void LoadData()
        {
            checkBoxMon.Checked = false;
            checkBoxTue.Checked = false;
            checkBoxWed.Checked = false;
            checkBoxThurs.Checked = false;
            checkBoxFri.Checked = false;
            checkBoxSat.Checked = false;
            checkBoxSun.Checked = false;

            SqlCommand cmd = new SqlCommand("SELECT WS.WorkersID,WBD.LName + ' ' + WBD.FName + ' ' + WBD.MName + ' ' + WBD.Suffix, CONVERT(VARCHAR(20), WS.MonSched) + ' ' + WS.MonDayNight AS Monday, CONVERT(VARCHAR(20), WS.TueSched) + ' ' + WS.TueDayNight AS Tuesday, CONVERT(VARCHAR(20), WS.WedSched) + ' ' + WS.WedDayNight AS Wednesday, CONVERT(VARCHAR(20), WS.ThuSched) + ' ' + WS.ThuDayNight AS Thursday, CONVERT(VARCHAR(20), WS.FriSched) + ' ' + WS.FriDayNight AS Friday, CONVERT(VARCHAR(20), WS.SatSched) + ' ' + WS.SatDayNight AS Saturday, CONVERT(VARCHAR(20), WS.SunSched) + ' ' + WS.SunDayNight AS Sunday, WBD.Picture FROM tblWorkersSchedule WS INNER JOIN tblWorkersBioData WBD ON WS.WorkersID = WBD.WorkersID WHERE WS.WorkersID=@WorkersID", con);
            cmd.Parameters.AddWithValue("@WorkersID", Class.WorkersID);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            labelWorkerID.Text = Convert.ToString(dt.Rows[0][0]);
            labelWorkerName.Text = Convert.ToString(dt.Rows[0][1]);
            MemoryStream mem = new MemoryStream((Byte[])(dt.Rows[0]["Picture"]));
            pictureBoxWorker.Image = Image.FromStream(mem);

            //Load Schedule
            if (Convert.ToString(dt.Rows[0]["Monday"]).Equals(""))
            { checkBoxMon.Checked = true; dateTimePickerMonday.Enabled = false; }
            if (Convert.ToString(dt.Rows[0]["Tuesday"]).Equals(""))
            { checkBoxTue.Checked = true; dateTimePickerTuesday.Enabled = false; }
            if (Convert.ToString(dt.Rows[0]["Wednesday"]).Equals(""))
            { checkBoxWed.Checked = true; dateTimePickerWednesday.Enabled = false; }
            if (Convert.ToString(dt.Rows[0]["Thursday"]).Equals(""))
            { checkBoxThurs.Checked = true; dateTimePickerThursday.Enabled = false; }
            if (Convert.ToString(dt.Rows[0]["Friday"]).Equals(""))
            { checkBoxFri.Checked = true; dateTimePickerFriday.Enabled = false; }
            if (Convert.ToString(dt.Rows[0]["Saturday"]).Equals(""))
            { checkBoxSat.Checked = true; dateTimePickerSaturday.Enabled = false; }
            if (Convert.ToString(dt.Rows[0]["Sunday"]).Equals(""))
            { checkBoxSun.Checked = true; dateTimePickerSunday.Enabled = false; }

            dateTimePickerMonday.Text = Convert.ToString(dt.Rows[0]["Monday"]);
            dateTimePickerTuesday.Text = Convert.ToString(dt.Rows[0]["Tuesday"]);
            dateTimePickerWednesday.Text = Convert.ToString(dt.Rows[0]["Wednesday"]);
            dateTimePickerThursday.Text = Convert.ToString(dt.Rows[0]["Thursday"]);
            dateTimePickerFriday.Text = Convert.ToString(dt.Rows[0]["Friday"]);
            dateTimePickerSaturday.Text = Convert.ToString(dt.Rows[0]["Saturday"]);
            dateTimePickerSunday.Text = Convert.ToString(dt.Rows[0]["Sunday"]);

            Week[0] = Convert.ToString(dt.Rows[0]["Monday"]);
            Week[1] = Convert.ToString(dt.Rows[0]["Tuesday"]);
            Week[2] = Convert.ToString(dt.Rows[0]["Wednesday"]);
            Week[3] = Convert.ToString(dt.Rows[0]["Thursday"]);
            Week[4] = Convert.ToString(dt.Rows[0]["Friday"]);
            Week[5] = Convert.ToString(dt.Rows[0]["Saturday"]);
            Week[6] = Convert.ToString(dt.Rows[0]["Sunday"]);
        }

        void EditShift()
        {
            string[] Monday = new string[1];
            string[] Tuesday = new string[1];
            string[] Wednesday = new string[1];
            string[] Thursday = new string[1];
            string[] Fridday = new string[1];
            string[] Saturday = new string[1];
            string[] Sunday = new string[1];

            Monday = dateTimePickerMonday.Text.Split(' ');
            Tuesday = dateTimePickerTuesday.Text.Split(' ');
            Wednesday = dateTimePickerWednesday.Text.Split(' ');
            Thursday = dateTimePickerThursday.Text.Split(' ');
            Fridday = dateTimePickerFriday.Text.Split(' ');
            Saturday = dateTimePickerSaturday.Text.Split(' ');
            Sunday = dateTimePickerSunday.Text.Split(' ');

            if (checkBoxMon.Checked.Equals(true))
            { Monday[0] = "NULL"; Monday[1] = ""; }
            else { Monday[0] = "'" + Monday[0] + "'"; }

            if (checkBoxTue.Checked.Equals(true))
            { Tuesday[0] = "NULL"; Tuesday[1] = ""; }
            else { Tuesday[0] = "'" + Tuesday[0] + "'"; }

            if (checkBoxWed.Checked.Equals(true))
            { Wednesday[0] = "NULL"; Wednesday[1] = ""; }
            else { Wednesday[0] = "'" + Wednesday[0] + "'"; }

            if (checkBoxThurs.Checked.Equals(true))
            { Thursday[0] = "NULL"; Thursday[1] = ""; }
            else { Thursday[0] = "'" + Thursday[0] + "'"; }

            if (checkBoxFri.Checked.Equals(true))
            { Fridday[0] = "NULL"; Fridday[1] = ""; }
            else { Fridday[0] = "'" + Fridday[0] + "'"; }

            if (checkBoxSat.Checked.Equals(true))
            { Saturday[0] = "NULL"; Saturday[1] = ""; }
            else { Saturday[0] = "'" + Saturday[0] + "'"; }

            if (checkBoxSun.Checked.Equals(true))
            { Sunday[0] = "NULL"; Sunday[1] = ""; }
            else { Sunday[0] = "'" + Sunday[0] + "'"; }

            Class.intaccept = 0;
            if (Convert.ToDateTime(dateTimePickerMonday.Text) > Convert.ToDateTime("8:00 AM") && dateTimePickerMonday.Enabled.Equals(true))
            { Class.intaccept++; }
            if (Convert.ToDateTime(dateTimePickerTuesday.Text) > Convert.ToDateTime("8:00 AM") && dateTimePickerTuesday.Enabled.Equals(true))
            { Class.intaccept++; }
            if (Convert.ToDateTime(dateTimePickerWednesday.Text) > Convert.ToDateTime("8:00 AM") && dateTimePickerWednesday.Enabled.Equals(true))
            { Class.intaccept++; }
            if (Convert.ToDateTime(dateTimePickerThursday.Text) > Convert.ToDateTime("8:00 AM") && dateTimePickerThursday.Enabled.Equals(true))
            { Class.intaccept++; }
            if (Convert.ToDateTime(dateTimePickerFriday.Text) > Convert.ToDateTime("8:00 AM") && dateTimePickerFriday.Enabled.Equals(true))
            { Class.intaccept++; }
            if (Convert.ToDateTime(dateTimePickerSaturday.Text) > Convert.ToDateTime("8:00 AM") && dateTimePickerSaturday.Enabled.Equals(true))
            { Class.intaccept++; }
            if (Convert.ToDateTime(dateTimePickerSunday.Text) > Convert.ToDateTime("8:00 AM") && dateTimePickerSunday.Enabled.Equals(true))
            { Class.intaccept++; }

            if (Class.intaccept.Equals(0))
            {
                SqlCommand TubleWorkerSched = new SqlCommand("UPDATE tblWorkersSchedule SET " +
                "SunSched=" + Sunday[0] + ", SunDayNight=@SunDayNight," +
                "MonSched=" + Monday[0] + ", MonDayNight=@MonDayNight," +
                "TueSched=" + Tuesday[0] + ",TueDayNight=@TueDayNight, " +
                "WedSched=" + Wednesday[0] + ", WedDayNight=@WedDayNight, " +
                "ThuSched=" + Thursday[0] + ", ThuDayNight=@ThuDayNight, " +
                "FriSched=" + Fridday[0] + ", FriDayNight=@FriDayNight, " +
                "SatSched=" + Saturday[0] + ", SatDayNight=@SatDayNight " +
                "WHERE WorkersID=@WorkersID", con);
                TubleWorkerSched.Parameters.AddWithValue("@WorkersID", labelWorkerID.Text);
                TubleWorkerSched.Parameters.AddWithValue("@SunDayNight", Sunday[1]);
                TubleWorkerSched.Parameters.AddWithValue("@MonDayNight", Monday[1]);
                TubleWorkerSched.Parameters.AddWithValue("@TueDayNight", Tuesday[1]);
                TubleWorkerSched.Parameters.AddWithValue("@WedDayNight", Wednesday[1]);
                TubleWorkerSched.Parameters.AddWithValue("@ThuDayNight", Thursday[1]);
                TubleWorkerSched.Parameters.AddWithValue("@FriDayNight", Fridday[1]);
                TubleWorkerSched.Parameters.AddWithValue("@SatDayNight", Saturday[1]);
                con.Open();
                TubleWorkerSched.ExecuteNonQuery();
                con.Close();
                EmployeeStatus();
                this.Close();
            }
            else
            { MessageBox.Show("Can't accept set schedule"); }
        }

        void EmployeeStatus()
        {
            SqlCommand cmd = new SqlCommand("INSERT INTO [dbo].[tblAdminStatus] ([ID],[Date],[Time],[TimeDayNight],[Type],WorkersID,[Description]) VALUES (@ID, @Date ,@Time, @TimeDayNight, @Type, @WorkersID, @Description)", con);
            cmd.Parameters.AddWithValue("@ID", Class.EmployeeID);
            cmd.Parameters.AddWithValue("@Date", Convert.ToDateTime(DateTime.Now.ToShortDateString()));
            cmd.Parameters.AddWithValue("@Time", Convert.ToDateTime(DateTime.Now.ToShortTimeString()));

            string converttime = DateTime.Now.ToShortTimeString();
            string[] convertsplittime = converttime.Split(' ');
            cmd.Parameters.AddWithValue("@TimeDayNight", convertsplittime[1]);
            cmd.Parameters.AddWithValue("@Type", "Edit Worker Shift");
            cmd.Parameters.AddWithValue("@WorkersID", labelWorkerID.Text);
            cmd.Parameters.AddWithValue("@Description", StackDescription);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }

        void CheckShift()
        {
            StackDescription = "";

            if (dateTimePickerMonday.Text != Week[0]) { StackDescription += "Monday "; }
            if (dateTimePickerTuesday.Text != Week[1]) { StackDescription += "Tuesday "; }
            if (dateTimePickerWednesday.Text != Week[2]) { StackDescription += "Wednesday "; }
            if (dateTimePickerThursday.Text != Week[3]) { StackDescription += " Thursday "; }
            if (dateTimePickerFriday.Text != Week[4]) { StackDescription += " Friday "; }
            if (dateTimePickerSaturday.Text != Week[5]) { StackDescription += "Saturday "; }
            if (dateTimePickerSunday.Text != Week[6]) { StackDescription += "Sunday "; }
        }

        private void buttonEditShift_Click(object sender, EventArgs e)
        {
            CheckShift();
            EditShift();
        }

        private void buttonClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void checkBoxMon_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxMon.Checked.Equals(true))
            { dateTimePickerMonday.Enabled = false; }
            else { dateTimePickerMonday.Enabled = true; }
        }

        private void checkBoxTue_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxTue.Checked.Equals(true))
            { dateTimePickerTuesday.Enabled = false; }
            else { dateTimePickerTuesday.Enabled = true; }
        }

        private void checkBoxWed_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxWed.Checked.Equals(true))
            { dateTimePickerWednesday.Enabled = false; }
            else { dateTimePickerWednesday.Enabled = true; }
        }

        private void checkBoxThurs_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxThurs.Checked.Equals(true))
            { dateTimePickerThursday.Enabled = false; }
            else { dateTimePickerThursday.Enabled = true; }
        }

        private void checkBoxFri_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxFri.Checked.Equals(true))
            { dateTimePickerFriday.Enabled = false; }
            else { dateTimePickerFriday.Enabled = true; }
        }

        private void checkBoxSat_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxSat.Checked.Equals(true))
            { dateTimePickerSaturday.Enabled = false; }
            else { dateTimePickerSaturday.Enabled = true; }
        }

        private void checkBoxSun_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxSun.Checked.Equals(true))
            { dateTimePickerSunday.Enabled = false; }
            else { dateTimePickerSunday.Enabled = true; }
        }
    }
}
