﻿using Microsoft.Reporting.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace QRCodeDemo
{
    public partial class FormWorkerID : Form
    {
        SqlConnection con = new SqlConnection(Class.tublecon);

        public FormWorkerID()
        {
            InitializeComponent();
        }

        private void FormWorkerID_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'DBdjaasDataSetBioData.tblWorkersBioData' table. You can move, or remove it, as needed.
            
            // TODO: This line of code loads data into the 'DBdjaasDataSetBioData.tblWorkersBioData' table. You can move, or remove it, as needed.
            IndividualGetDataName();
        }
        void IndividualGetDataName()
        {

            SqlCommand tublecmd = new SqlCommand(@"SELECT LName +', '+ FName + ' ' + MName + ' ' + Suffix, Picture, ContactNumber, QRPicture , EmergencyContactNumberPerson, EmergencyContactPerson
            FROM tblWorkersBioData WHERE WorkersID = @WorkersID", con);
            tublecmd.Parameters.AddWithValue("@WorkersID", Class.WorkersID);
            SqlDataAdapter da = new SqlDataAdapter(tublecmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            ReportParameter[] para = new ReportParameter[] { 
                new ReportParameter("pName", dt.Rows[0][0].ToString()),
                new ReportParameter("pContact", dt.Rows[0][2].ToString()), 
                new ReportParameter("pMode", Class.MODE)
            };
            this.reportViewer1.LocalReport.SetParameters(para);
            this.tblWorkersBioDataBindingSource.DataSource = dt;
            ReportDataSource rds = new ReportDataSource("DataSetBioData", dt);
            this.reportViewer1.ProcessingMode = ProcessingMode.Local;
            this.reportViewer1.LocalReport.DataSources.Add(rds);
            this.tblWorkersBioDataTableAdapter.Fill(this.DBdjaasDataSetBioData.tblWorkersBioData);
            this.reportViewer1.RefreshReport();
        }
    }
}
