﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace QRCodeDemo
{
    public partial class FormSelectFunction : Form
    {
        public FormSelectFunction()
        {
            InitializeComponent();
        }

        private void buttonCheckout_Click(object sender, EventArgs e)
        {
            FormAttendanceEdit AE = new FormAttendanceEdit();
            this.Hide();
            AE.ShowDialog();
        }

        private void buttonLunchBreak_Click(object sender, EventArgs e)
        {
            if (Convert.ToDateTime("12:00 PM") <= Convert.ToDateTime(DateTime.Now.ToShortDateString()) && 
                Convert.ToDateTime("12:59 PM") >= Convert.ToDateTime(DateTime.Now.ToShortDateString()))
            {
                FormWorkerLunchBreak WLB = new FormWorkerLunchBreak();
                this.Hide();
                WLB.ShowDialog();
            }
            else if (Convert.ToDateTime("11:59 AM") >= Convert.ToDateTime(DateTime.Now.ToShortDateString()))
            { MessageBox.Show("The Schedule of Lunch Break is not started"); }
            else if (Convert.ToDateTime("01:00 AM") <= Convert.ToDateTime(DateTime.Now.ToShortDateString()))
            { MessageBox.Show("The Schedule of Lunch Break is already finished"); }
        }

        private void FormSelectFunction_Load(object sender, EventArgs e)
        {

        }
    }
}
