﻿namespace QRCodeDemo
{
    partial class FormLeaveSelection
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonViewLeave = new System.Windows.Forms.Button();
            this.buttonAddLeave = new System.Windows.Forms.Button();
            this.jbtPanelGIF1 = new QRCodeDemo.JBTControls.JBTPanelGIF();
            this.SuspendLayout();
            // 
            // buttonViewLeave
            // 
            this.buttonViewLeave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.buttonViewLeave.FlatAppearance.BorderSize = 0;
            this.buttonViewLeave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonViewLeave.Font = new System.Drawing.Font("Segoe UI Symbol", 12F, System.Drawing.FontStyle.Bold);
            this.buttonViewLeave.ForeColor = System.Drawing.Color.White;
            this.buttonViewLeave.Location = new System.Drawing.Point(25, 91);
            this.buttonViewLeave.Margin = new System.Windows.Forms.Padding(4);
            this.buttonViewLeave.Name = "buttonViewLeave";
            this.buttonViewLeave.Size = new System.Drawing.Size(283, 52);
            this.buttonViewLeave.TabIndex = 3;
            this.buttonViewLeave.Text = "View Leave";
            this.buttonViewLeave.UseVisualStyleBackColor = false;
            this.buttonViewLeave.Click += new System.EventHandler(this.buttonViewLeave_Click);
            // 
            // buttonAddLeave
            // 
            this.buttonAddLeave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.buttonAddLeave.FlatAppearance.BorderSize = 0;
            this.buttonAddLeave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAddLeave.Font = new System.Drawing.Font("Segoe UI Symbol", 12F, System.Drawing.FontStyle.Bold);
            this.buttonAddLeave.ForeColor = System.Drawing.Color.White;
            this.buttonAddLeave.Location = new System.Drawing.Point(25, 27);
            this.buttonAddLeave.Margin = new System.Windows.Forms.Padding(4);
            this.buttonAddLeave.Name = "buttonAddLeave";
            this.buttonAddLeave.Size = new System.Drawing.Size(283, 52);
            this.buttonAddLeave.TabIndex = 2;
            this.buttonAddLeave.Text = "Add Leave";
            this.buttonAddLeave.UseVisualStyleBackColor = false;
            this.buttonAddLeave.Click += new System.EventHandler(this.buttonAddLeave_Click);
            // 
            // jbtPanelGIF1
            // 
            this.jbtPanelGIF1.Angle = 57F;
            this.jbtPanelGIF1.BorderRadius = 1;
            this.jbtPanelGIF1.Color0 = System.Drawing.Color.Blue;
            this.jbtPanelGIF1.Color1 = System.Drawing.Color.Pink;
            this.jbtPanelGIF1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.jbtPanelGIF1.ForeColor = System.Drawing.Color.White;
            this.jbtPanelGIF1.Location = new System.Drawing.Point(0, 0);
            this.jbtPanelGIF1.Name = "jbtPanelGIF1";
            this.jbtPanelGIF1.Size = new System.Drawing.Size(333, 166);
            this.jbtPanelGIF1.TabIndex = 4;
            // 
            // FormLeaveSelection
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(333, 166);
            this.Controls.Add(this.buttonViewLeave);
            this.Controls.Add(this.buttonAddLeave);
            this.Controls.Add(this.jbtPanelGIF1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormLeaveSelection";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Leave Selection";
            this.Load += new System.EventHandler(this.FormLeaveSelection_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button buttonViewLeave;
        private System.Windows.Forms.Button buttonAddLeave;
        private JBTControls.JBTPanelGIF jbtPanelGIF1;
    }
}