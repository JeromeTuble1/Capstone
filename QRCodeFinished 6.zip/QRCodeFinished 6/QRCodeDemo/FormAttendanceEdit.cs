﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace QRCodeDemo
{
    public partial class FormAttendanceEdit : Form
    {
        SqlConnection tublecon = new SqlConnection(Class.tublecon);

        public FormAttendanceEdit()
        {
            InitializeComponent();
        }

        private void FormAttendanceEdit_Load(object sender, EventArgs e)
        {
            GetData();
        }

        private void buttonClose_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        void GetData()
        {

            SqlCommand cmd = new SqlCommand("SELECT WBD.WorkersID ,WBD.LName+', '+WBD.MName+' '+WBD.FName+' '+WBD.Suffix AS 'Name',WA.Schedule,WA.CheckIn,WA.CheckOut,WA.[Status],WA.[Day],WA.[Date],WBD.Picture FROM tblWorkersAttendance WA INNER JOIN tblWorkersBioData WBD ON WA.WorkersID = WBD.WorkersID WHERE WBD.WorkersID = @WorkersID AND WA.Date = @Date", tublecon);
            cmd.Parameters.AddWithValue("@WorkersID", Class.WorkersID);
            cmd.Parameters.AddWithValue("@Date", Convert.ToDateTime(Class.WorkersDate));
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            labelWorkerID.Text = Convert.ToString(dt.Rows[0]["WorkersID"]);
            labelFullName.Text = Convert.ToString(dt.Rows[0]["Name"]);
            labelSchedule.Text = Convert.ToString(dt.Rows[0]["Schedule"]);
            labelCheckIn.Text = Convert.ToString(dt.Rows[0]["CheckIn"]);
            dateTimePickerCheckOut.Text = Convert.ToString(dt.Rows[0]["CheckOut"]);
            labelStatus.Text = Convert.ToString(dt.Rows[0]["Status"]);
            labelDay.Text = Convert.ToString(dt.Rows[0]["Day"]);
            string[] getDate = Convert.ToString(dt.Rows[0]["Date"]).Split(' ');
            labelDate.Text = getDate[0];
            MemoryStream mem = new MemoryStream((Byte[])(dt.Rows[0]["Picture"]));
            pictureBox1.Image = Image.FromStream(mem);
        }

        void UpdateAttendance()
        {
            SqlCommand cmd = new SqlCommand(@"UPDATE tblWorkersAttendance SET CheckOut = @CheckOut, Status = @Status WHERE WorkersID = @WorkersID AND Date = @Date", tublecon);
            cmd.Parameters.AddWithValue("@CheckOut", dateTimePickerCheckOut.Text);
            cmd.Parameters.AddWithValue("@WorkersID", labelWorkerID.Text);
            cmd.Parameters.AddWithValue("@Date", Convert.ToDateTime(labelDate.Text));
            cmd.Parameters.AddWithValue("@Status", labelStatus.Text);
            tublecon.Open();
            cmd.ExecuteNonQuery();
            tublecon.Close();
        }

        void EmployeeStatus()
        {
            SqlCommand cmd = new SqlCommand(@"INSERT INTO [dbo].[tblEmplyeeStatus] ([ID],[Date],[Time],[TimeDayNight],[Type],WorkersID,[Description]) VALUES (@ID, @Date ,@Time, @TimeDayNight, @Type, @WorkersID, @Description)", tublecon);
            cmd.Parameters.AddWithValue("@ID", Class.EmployeeID);
            cmd.Parameters.AddWithValue("@Date", Convert.ToDateTime(DateTime.Now.ToShortDateString()));
            cmd.Parameters.AddWithValue("@Time", Convert.ToDateTime(DateTime.Now.ToShortTimeString()));

            string[] convertsplittime = DateTime.Now.ToShortTimeString().Split(' ');
            cmd.Parameters.AddWithValue("@TimeDayNight", convertsplittime[1]);
            cmd.Parameters.AddWithValue("@Type", "Edit Worker Attendance");
            cmd.Parameters.AddWithValue("@WorkersID", labelWorkerID.Text);
            cmd.Parameters.AddWithValue("@Description", labelStatus.Text);
            tublecon.Open();
            cmd.ExecuteNonQuery();
            tublecon.Close();
        }

        private void buttonClose_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void checkBoxOverTime_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxOverTime.Checked == true)
            {
                labelStatus.Text = "Over Time";
                checkBoxHalfDay.Checked = false;
            }
            else if (checkBoxOverTime.Checked == false)
            {
                Unckecked();
            }
        }

        private void checkBoxHalfDay_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxHalfDay.Checked == true)
            {
                labelStatus.Text = "Half Day";
                checkBoxOverTime.Checked = false;
            }
            else if (checkBoxHalfDay.Checked == false)
            {
                Unckecked();
            }
        }

        void Unckecked()
        {
            SqlCommand cmd = new SqlCommand(@"SELECT * FROM tblWorkersAttendance INNER JOIN tblWorkersBioData ON tblWorkersAttendance.WorkersID = tblWorkersBioData.WorkersID WHERE tblWorkersBioData.WorkersID = @WorkersID AND tblWorkersAttendance.Date = @Date", tublecon);
            cmd.Parameters.AddWithValue("@WorkersID", Class.WorkersID);
            cmd.Parameters.AddWithValue("@Date", Convert.ToDateTime(Class.WorkersDate));
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            labelStatus.Text = Convert.ToString(dt.Rows[0]["Status"]);
        }

        private void buttonEditAttendance_Click(object sender, EventArgs e)
        {
            UpdateAttendance();
            EmployeeStatus();
            this.Hide();
        }
    }
}
