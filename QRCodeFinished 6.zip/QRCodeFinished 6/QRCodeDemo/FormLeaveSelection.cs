﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace QRCodeDemo
{
    public partial class FormLeaveSelection : Form
    {
        public FormLeaveSelection()
        {
            InitializeComponent();
        }

        private void buttonAddLeave_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormLeaveAdd HA = new FormLeaveAdd();
            HA.ShowDialog();
        }

        private void buttonViewLeave_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormLeaveRequested LR = new FormLeaveRequested();
            LR.ShowDialog();
        }

        private void FormLeaveSelection_Load(object sender, EventArgs e)
        {

        }
    }
}
