﻿namespace QRCodeDemo
{
    partial class FormShiftsEdit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dateTimePickerSunday = new System.Windows.Forms.DateTimePicker();
            this.dateTimePickerSaturday = new System.Windows.Forms.DateTimePicker();
            this.dateTimePickerFriday = new System.Windows.Forms.DateTimePicker();
            this.dateTimePickerThursday = new System.Windows.Forms.DateTimePicker();
            this.dateTimePickerWednesday = new System.Windows.Forms.DateTimePicker();
            this.dateTimePickerTuesday = new System.Windows.Forms.DateTimePicker();
            this.dateTimePickerMonday = new System.Windows.Forms.DateTimePicker();
            this.label51 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.pictureBoxWorker = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.labelWorkerID = new System.Windows.Forms.Label();
            this.labelWorkerName = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.buttonClose = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.buttonEditShift = new System.Windows.Forms.Button();
            this.checkBoxMon = new System.Windows.Forms.CheckBox();
            this.checkBoxTue = new System.Windows.Forms.CheckBox();
            this.checkBoxWed = new System.Windows.Forms.CheckBox();
            this.checkBoxThurs = new System.Windows.Forms.CheckBox();
            this.checkBoxFri = new System.Windows.Forms.CheckBox();
            this.checkBoxSat = new System.Windows.Forms.CheckBox();
            this.checkBoxSun = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxWorker)).BeginInit();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // dateTimePickerSunday
            // 
            this.dateTimePickerSunday.CustomFormat = "hh:mm:ss tt";
            this.dateTimePickerSunday.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePickerSunday.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePickerSunday.Location = new System.Drawing.Point(260, 523);
            this.dateTimePickerSunday.Margin = new System.Windows.Forms.Padding(4);
            this.dateTimePickerSunday.Name = "dateTimePickerSunday";
            this.dateTimePickerSunday.Size = new System.Drawing.Size(184, 30);
            this.dateTimePickerSunday.TabIndex = 89;
            // 
            // dateTimePickerSaturday
            // 
            this.dateTimePickerSaturday.CustomFormat = "hh:mm:ss tt";
            this.dateTimePickerSaturday.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePickerSaturday.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePickerSaturday.Location = new System.Drawing.Point(260, 484);
            this.dateTimePickerSaturday.Margin = new System.Windows.Forms.Padding(4);
            this.dateTimePickerSaturday.Name = "dateTimePickerSaturday";
            this.dateTimePickerSaturday.Size = new System.Drawing.Size(184, 30);
            this.dateTimePickerSaturday.TabIndex = 88;
            // 
            // dateTimePickerFriday
            // 
            this.dateTimePickerFriday.CustomFormat = "hh:mm:ss tt";
            this.dateTimePickerFriday.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePickerFriday.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePickerFriday.Location = new System.Drawing.Point(260, 444);
            this.dateTimePickerFriday.Margin = new System.Windows.Forms.Padding(4);
            this.dateTimePickerFriday.Name = "dateTimePickerFriday";
            this.dateTimePickerFriday.Size = new System.Drawing.Size(184, 30);
            this.dateTimePickerFriday.TabIndex = 87;
            // 
            // dateTimePickerThursday
            // 
            this.dateTimePickerThursday.CustomFormat = "hh:mm:ss tt";
            this.dateTimePickerThursday.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePickerThursday.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePickerThursday.Location = new System.Drawing.Point(260, 405);
            this.dateTimePickerThursday.Margin = new System.Windows.Forms.Padding(4);
            this.dateTimePickerThursday.Name = "dateTimePickerThursday";
            this.dateTimePickerThursday.Size = new System.Drawing.Size(184, 30);
            this.dateTimePickerThursday.TabIndex = 86;
            // 
            // dateTimePickerWednesday
            // 
            this.dateTimePickerWednesday.CustomFormat = "hh:mm:ss tt";
            this.dateTimePickerWednesday.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePickerWednesday.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePickerWednesday.Location = new System.Drawing.Point(260, 366);
            this.dateTimePickerWednesday.Margin = new System.Windows.Forms.Padding(4);
            this.dateTimePickerWednesday.Name = "dateTimePickerWednesday";
            this.dateTimePickerWednesday.Size = new System.Drawing.Size(184, 30);
            this.dateTimePickerWednesday.TabIndex = 85;
            // 
            // dateTimePickerTuesday
            // 
            this.dateTimePickerTuesday.CustomFormat = "hh:mm:ss tt";
            this.dateTimePickerTuesday.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePickerTuesday.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePickerTuesday.Location = new System.Drawing.Point(260, 326);
            this.dateTimePickerTuesday.Margin = new System.Windows.Forms.Padding(4);
            this.dateTimePickerTuesday.Name = "dateTimePickerTuesday";
            this.dateTimePickerTuesday.Size = new System.Drawing.Size(184, 30);
            this.dateTimePickerTuesday.TabIndex = 84;
            // 
            // dateTimePickerMonday
            // 
            this.dateTimePickerMonday.CustomFormat = "hh:mm:ss tt";
            this.dateTimePickerMonday.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePickerMonday.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePickerMonday.Location = new System.Drawing.Point(260, 287);
            this.dateTimePickerMonday.Margin = new System.Windows.Forms.Padding(4);
            this.dateTimePickerMonday.Name = "dateTimePickerMonday";
            this.dateTimePickerMonday.Size = new System.Drawing.Size(184, 30);
            this.dateTimePickerMonday.TabIndex = 83;
            this.dateTimePickerMonday.Value = new System.DateTime(2022, 10, 8, 23, 35, 0, 0);
            // 
            // label51
            // 
            this.label51.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label51.Location = new System.Drawing.Point(128, 529);
            this.label51.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(86, 25);
            this.label51.TabIndex = 82;
            this.label51.Text = "Sunday:";
            // 
            // label52
            // 
            this.label52.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label52.Location = new System.Drawing.Point(115, 490);
            this.label52.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(97, 25);
            this.label52.TabIndex = 81;
            this.label52.Text = "Saturday:";
            // 
            // label54
            // 
            this.label54.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label54.AutoSize = true;
            this.label54.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label54.Location = new System.Drawing.Point(143, 450);
            this.label54.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(72, 25);
            this.label54.TabIndex = 80;
            this.label54.Text = "Friday:";
            // 
            // label47
            // 
            this.label47.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.Location = new System.Drawing.Point(88, 372);
            this.label47.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(124, 25);
            this.label47.TabIndex = 78;
            this.label47.Text = "Wednesday:";
            // 
            // label48
            // 
            this.label48.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label48.Location = new System.Drawing.Point(120, 332);
            this.label48.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(95, 25);
            this.label48.TabIndex = 77;
            this.label48.Text = "Tuesday:";
            // 
            // label49
            // 
            this.label49.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label49.Location = new System.Drawing.Point(113, 411);
            this.label49.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(101, 25);
            this.label49.TabIndex = 79;
            this.label49.Text = "Thursday:";
            // 
            // label50
            // 
            this.label50.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label50.Location = new System.Drawing.Point(125, 293);
            this.label50.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(89, 25);
            this.label50.TabIndex = 76;
            this.label50.Text = "Monday:";
            // 
            // label46
            // 
            this.label46.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.Location = new System.Drawing.Point(35, 231);
            this.label46.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(164, 25);
            this.label46.TabIndex = 75;
            this.label46.Text = "Worker Schedule";
            // 
            // pictureBoxWorker
            // 
            this.pictureBoxWorker.Location = new System.Drawing.Point(507, 81);
            this.pictureBoxWorker.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBoxWorker.Name = "pictureBoxWorker";
            this.pictureBoxWorker.Size = new System.Drawing.Size(200, 185);
            this.pictureBoxWorker.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxWorker.TabIndex = 90;
            this.pictureBoxWorker.TabStop = false;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(35, 106);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 25);
            this.label1.TabIndex = 91;
            this.label1.Text = "Worker ID";
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(35, 153);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(133, 25);
            this.label2.TabIndex = 92;
            this.label2.Text = "Worker Name";
            // 
            // labelWorkerID
            // 
            this.labelWorkerID.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labelWorkerID.AutoSize = true;
            this.labelWorkerID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelWorkerID.Location = new System.Drawing.Point(151, 106);
            this.labelWorkerID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelWorkerID.Name = "labelWorkerID";
            this.labelWorkerID.Size = new System.Drawing.Size(122, 25);
            this.labelWorkerID.TabIndex = 93;
            this.labelWorkerID.Text = "##########";
            // 
            // labelWorkerName
            // 
            this.labelWorkerName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labelWorkerName.AutoSize = true;
            this.labelWorkerName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelWorkerName.Location = new System.Drawing.Point(184, 153);
            this.labelWorkerName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelWorkerName.Name = "labelWorkerName";
            this.labelWorkerName.Size = new System.Drawing.Size(122, 25);
            this.labelWorkerName.TabIndex = 94;
            this.labelWorkerName.Text = "##########";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Blue;
            this.panel3.Controls.Add(this.buttonClose);
            this.panel3.Controls.Add(this.label4);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Margin = new System.Windows.Forms.Padding(4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(723, 64);
            this.panel3.TabIndex = 95;
            // 
            // buttonClose
            // 
            this.buttonClose.FlatAppearance.BorderSize = 0;
            this.buttonClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonClose.Location = new System.Drawing.Point(679, 4);
            this.buttonClose.Margin = new System.Windows.Forms.Padding(4);
            this.buttonClose.Name = "buttonClose";
            this.buttonClose.Size = new System.Drawing.Size(40, 37);
            this.buttonClose.TabIndex = 81;
            this.buttonClose.Text = "X";
            this.buttonClose.UseVisualStyleBackColor = true;
            this.buttonClose.Click += new System.EventHandler(this.buttonClose_Click);
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(43, 11);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(203, 39);
            this.label4.TabIndex = 44;
            this.label4.Text = "Worker Shift";
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(-344, 11);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(196, 39);
            this.label3.TabIndex = 43;
            this.label3.Text = "Add Worker";
            // 
            // buttonEditShift
            // 
            this.buttonEditShift.BackColor = System.Drawing.Color.LightBlue;
            this.buttonEditShift.FlatAppearance.BorderSize = 0;
            this.buttonEditShift.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonEditShift.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonEditShift.Location = new System.Drawing.Point(507, 577);
            this.buttonEditShift.Margin = new System.Windows.Forms.Padding(4);
            this.buttonEditShift.Name = "buttonEditShift";
            this.buttonEditShift.Size = new System.Drawing.Size(200, 44);
            this.buttonEditShift.TabIndex = 96;
            this.buttonEditShift.Text = "Edit";
            this.buttonEditShift.UseVisualStyleBackColor = false;
            this.buttonEditShift.Click += new System.EventHandler(this.buttonEditShift_Click);
            // 
            // checkBoxMon
            // 
            this.checkBoxMon.AutoSize = true;
            this.checkBoxMon.Location = new System.Drawing.Point(451, 300);
            this.checkBoxMon.Name = "checkBoxMon";
            this.checkBoxMon.Size = new System.Drawing.Size(18, 17);
            this.checkBoxMon.TabIndex = 97;
            this.checkBoxMon.UseVisualStyleBackColor = true;
            this.checkBoxMon.CheckedChanged += new System.EventHandler(this.checkBoxMon_CheckedChanged);
            // 
            // checkBoxTue
            // 
            this.checkBoxTue.AutoSize = true;
            this.checkBoxTue.Location = new System.Drawing.Point(451, 339);
            this.checkBoxTue.Name = "checkBoxTue";
            this.checkBoxTue.Size = new System.Drawing.Size(18, 17);
            this.checkBoxTue.TabIndex = 98;
            this.checkBoxTue.UseVisualStyleBackColor = true;
            this.checkBoxTue.CheckedChanged += new System.EventHandler(this.checkBoxTue_CheckedChanged);
            // 
            // checkBoxWed
            // 
            this.checkBoxWed.AutoSize = true;
            this.checkBoxWed.Location = new System.Drawing.Point(451, 379);
            this.checkBoxWed.Name = "checkBoxWed";
            this.checkBoxWed.Size = new System.Drawing.Size(18, 17);
            this.checkBoxWed.TabIndex = 99;
            this.checkBoxWed.UseVisualStyleBackColor = true;
            this.checkBoxWed.CheckedChanged += new System.EventHandler(this.checkBoxWed_CheckedChanged);
            // 
            // checkBoxThurs
            // 
            this.checkBoxThurs.AutoSize = true;
            this.checkBoxThurs.Location = new System.Drawing.Point(451, 418);
            this.checkBoxThurs.Name = "checkBoxThurs";
            this.checkBoxThurs.Size = new System.Drawing.Size(18, 17);
            this.checkBoxThurs.TabIndex = 100;
            this.checkBoxThurs.UseVisualStyleBackColor = true;
            this.checkBoxThurs.CheckedChanged += new System.EventHandler(this.checkBoxThurs_CheckedChanged);
            // 
            // checkBoxFri
            // 
            this.checkBoxFri.AutoSize = true;
            this.checkBoxFri.Location = new System.Drawing.Point(451, 457);
            this.checkBoxFri.Name = "checkBoxFri";
            this.checkBoxFri.Size = new System.Drawing.Size(18, 17);
            this.checkBoxFri.TabIndex = 101;
            this.checkBoxFri.UseVisualStyleBackColor = true;
            this.checkBoxFri.CheckedChanged += new System.EventHandler(this.checkBoxFri_CheckedChanged);
            // 
            // checkBoxSat
            // 
            this.checkBoxSat.AutoSize = true;
            this.checkBoxSat.Location = new System.Drawing.Point(451, 497);
            this.checkBoxSat.Name = "checkBoxSat";
            this.checkBoxSat.Size = new System.Drawing.Size(18, 17);
            this.checkBoxSat.TabIndex = 102;
            this.checkBoxSat.UseVisualStyleBackColor = true;
            this.checkBoxSat.CheckedChanged += new System.EventHandler(this.checkBoxSat_CheckedChanged);
            // 
            // checkBoxSun
            // 
            this.checkBoxSun.AutoSize = true;
            this.checkBoxSun.Location = new System.Drawing.Point(451, 536);
            this.checkBoxSun.Name = "checkBoxSun";
            this.checkBoxSun.Size = new System.Drawing.Size(18, 17);
            this.checkBoxSun.TabIndex = 103;
            this.checkBoxSun.UseVisualStyleBackColor = true;
            this.checkBoxSun.CheckedChanged += new System.EventHandler(this.checkBoxSun_CheckedChanged);
            // 
            // FormShiftsEdit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(723, 636);
            this.Controls.Add(this.checkBoxSun);
            this.Controls.Add(this.checkBoxSat);
            this.Controls.Add(this.checkBoxFri);
            this.Controls.Add(this.checkBoxThurs);
            this.Controls.Add(this.checkBoxWed);
            this.Controls.Add(this.checkBoxTue);
            this.Controls.Add(this.checkBoxMon);
            this.Controls.Add(this.buttonEditShift);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.labelWorkerName);
            this.Controls.Add(this.labelWorkerID);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBoxWorker);
            this.Controls.Add(this.dateTimePickerSunday);
            this.Controls.Add(this.dateTimePickerSaturday);
            this.Controls.Add(this.dateTimePickerFriday);
            this.Controls.Add(this.dateTimePickerThursday);
            this.Controls.Add(this.dateTimePickerWednesday);
            this.Controls.Add(this.dateTimePickerTuesday);
            this.Controls.Add(this.dateTimePickerMonday);
            this.Controls.Add(this.label51);
            this.Controls.Add(this.label52);
            this.Controls.Add(this.label54);
            this.Controls.Add(this.label47);
            this.Controls.Add(this.label48);
            this.Controls.Add(this.label49);
            this.Controls.Add(this.label50);
            this.Controls.Add(this.label46);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "FormShiftsEdit";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.FormShiftsEdit_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxWorker)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DateTimePicker dateTimePickerSunday;
        private System.Windows.Forms.DateTimePicker dateTimePickerSaturday;
        private System.Windows.Forms.DateTimePicker dateTimePickerFriday;
        private System.Windows.Forms.DateTimePicker dateTimePickerThursday;
        private System.Windows.Forms.DateTimePicker dateTimePickerWednesday;
        private System.Windows.Forms.DateTimePicker dateTimePickerTuesday;
        private System.Windows.Forms.DateTimePicker dateTimePickerMonday;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.PictureBox pictureBoxWorker;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label labelWorkerID;
        private System.Windows.Forms.Label labelWorkerName;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button buttonClose;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button buttonEditShift;
        private System.Windows.Forms.CheckBox checkBoxMon;
        private System.Windows.Forms.CheckBox checkBoxTue;
        private System.Windows.Forms.CheckBox checkBoxWed;
        private System.Windows.Forms.CheckBox checkBoxThurs;
        private System.Windows.Forms.CheckBox checkBoxFri;
        private System.Windows.Forms.CheckBox checkBoxSat;
        private System.Windows.Forms.CheckBox checkBoxSun;

    }
}