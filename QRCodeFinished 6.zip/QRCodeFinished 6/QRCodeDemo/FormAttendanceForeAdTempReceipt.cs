﻿using Microsoft.Reporting.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace QRCodeDemo
{
    public partial class FormAttendanceForeAdTempReceipt : Form
    {
        SqlConnection tublecon = new SqlConnection(Class.tublecon);

        public FormAttendanceForeAdTempReceipt()
        {
            InitializeComponent();
        }

        private void FormAttendanceEmployeeTemp_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'DBdjaasDataSet3.tblEmpAdTemp' table. You can move, or remove it, as needed.
            this.tblEmpAdTempTableAdapter.Fill(this.DBdjaasDataSet3.tblEmpAdTemp);
            IndividualGetDataName();
        }

        void IndividualGetDataName()
        {
            this.tblEmpAdTempTableAdapter.Fill(this.DBdjaasDataSet3.tblEmpAdTemp);
            SqlCommand tublecmd = new SqlCommand("SELECT ET.LoggedInDate, ET.LoggedInTime, ET.LoggedOutDate, ET.LoggedOutTime, L.LName + ', ' + L.FName + ' ' + L.MName FROM tblEmpAdTemp ET INNER JOIN tblLogin L ON L.ID = ET.ID WHERE ET.ID = @ID AND L.ID = @ID", tublecon);
            tublecmd.Parameters.AddWithValue("@ID", Class.EmployeeID);
            SqlDataAdapter tubleda = new SqlDataAdapter(tublecmd);
            DataTable tubledt = new DataTable();
            tubleda.Fill(tubledt);
            tblEmpAdTempBindingSource.DataSource = tubledt;


            if (tubledt.Rows.Count.Equals(0))
            {
                MessageBox.Show("No Report");
                this.Close();
            }
            else
            {
                ReportParameter[] para = new ReportParameter[] { new ReportParameter("pName", tubledt.Rows[0][4].ToString()), new ReportParameter("pDate", DateTime.Now.ToShortDateString()) };
                this.reportViewer1.LocalReport.SetParameters(para);
                this.reportViewer1.RefreshReport();
            }
        }
    }
}
