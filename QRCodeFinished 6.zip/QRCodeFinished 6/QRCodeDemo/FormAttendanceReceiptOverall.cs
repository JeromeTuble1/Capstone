﻿using Microsoft.Reporting.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace QRCodeDemo
{
    public partial class FormAttendanceReceiptOverall : Form
    {
        public static string PDate = "";
        SqlConnection tublecon = new SqlConnection(Class.tublecon);

        public FormAttendanceReceiptOverall()
        {
            InitializeComponent();
        }

        private void FormAttendanceReceiptOverall_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'DBdjaasDataSet.tblWorkersAttendance' table. You can move, or remove it, as needed.
            GroupGetDataName();
        }
        void GroupGetDataName()
        {
            SqlCommand tublecmd = new SqlCommand("SELECT WBD.WorkersID, WBD.[LName]+', '+ WBD.[FName]+' '+ WBD.[MName] AS FullName,WA.Schedule,WA.CheckIn,WA.CheckOut,CONVERT(datetime,WA.CheckOut) - CONVERT(datetime,WA.CheckIn) AS [Total Hours],WA.[Status],WA.[Day],WA.[Date],WA.AbsentCause FROM tblWorkersAttendance WA INNER JOIN tblWorkersBioData WBD ON WA.WorkersID = WBD.WorkersID WHERE WA.[Date] <= @To AND WA.[Date] >= @From ORDER BY WorkersID ASC", tublecon);
            tublecmd.Parameters.AddWithValue("@To", Convert.ToDateTime(Class.To));
            tublecmd.Parameters.AddWithValue("@From", Convert.ToDateTime(Class.From));
            SqlDataAdapter tubleda = new SqlDataAdapter(tublecmd);
            DataTable tubledt = new DataTable();
            tubleda.Fill(tubledt);
            tblWorkersAttendanceBindingSource.DataSource = tubledt;

            if (tubledt.Rows.Count.Equals(0))
            {
                MessageBox.Show("No Report");
                this.Close();
            }
            else
            {
                PDate = Convert.ToString(DateTime.Now.ToShortDateString());
                ReportParameter[] para = new ReportParameter[] { new ReportParameter("pDate", PDate) };
                this.reportViewer1.LocalReport.SetParameters(para);
                this.reportViewer1.RefreshReport();
            }
        }
    }
}
