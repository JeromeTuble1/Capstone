﻿using QRCoder;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace QRCodeDemo
{
    public partial class FormWorkersAdd : Form
    {
        SqlConnection tublecon = new SqlConnection(Class.tublecon);
        MemoryStream tubleMS, tubleQR;

        public FormWorkersAdd()
        {
            InitializeComponent();
        }

        private void buttonAddWorkers_Click(object sender, EventArgs e)
        {

        }

        private void FormAddWorkers_Load(object sender, EventArgs e)
        {
            CreateNewID();
        }

        void CreateNewID()
        {
            string Workers = "";
            textBoxWorkerID.Text = "";
            SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM tblWorkersBioData WHERE WorkersID LIKE @WorkersID", tublecon);
            cmd.Parameters.AddWithValue("@WorkersID", "%" + DateTime.Now.Year + "%");
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            if (Convert.ToInt16(dt.Rows[0][0]).Equals(0))
            { Workers = "1"; }
            else
            { Workers = (Convert.ToInt16(dt.Rows[0][0]) + 1).ToString(); }
            if (Convert.ToInt16(Workers) < 10)
            {
                Workers = "000" + Workers;
            }
            else if (Convert.ToInt16(Workers) < 100)
            {
                Workers = "00" + Workers;
            }
            else if (Convert.ToInt16(Workers) < 1000)
            {
                Workers = "0" + Workers;
            }
            textBoxWorkerID.Text = DateTime.Now.Year + "-" + Workers + "-Worker-DJAAS";

            for (int i = DateTime.Now.Year - 100; i <= DateTime.Now.Year; i++)
            { comboBoxYearHire.Items.Add(i); }

            textBoxHireDate.Text = DateTime.Now.ToShortDateString();

            QRCodeGenerator QG = new QRCodeGenerator();
            var TubleData = QG.CreateQrCode(textBoxWorkerID.Text, QRCodeGenerator.ECCLevel.H);
            var Tublecode = new QRCode(TubleData);
            pictureBoxQRCode.Image = Tublecode.GetGraphic(50);
        }

        int SuccessBioData = 0, SuccessWorkExp = 0, SuccessErrorEduQual = 0, SuccessErrorSchedule = 0;

        void AddWorker()
        {
            if (Class.AddWorkersCollectionError.Equals(0))
            {
                try
                {
                    if (SuccessBioData.Equals(0))
                    {
                        //Worker Biodata
                        tublecon.Open();
                        SqlCommand TubleBioData = new SqlCommand("INSERT INTO tblWorkersBioData (WorkersID, FName ,LName ,MName ,Suffix ,BirthDate ,HireDate ,MaritalStatus ,Religion ,NumberOfChildren ,Address ,ContactNumber ,EmergencyContact ,Picture, QRPicture, Tin, PhilHealth, SSS) VALUES (@WorkersID ,@FName ,@LName ,@MName,@Suffix ,@BirthDate ,@HireDate,@MaritalStatus ,@Religion ,@NumberOfChildren ,@Address ,@ContactNumber ,@EmergencyContact ,@Picture, @QRPicture, @TinID, @PhilHealth, @SSS)", tublecon);
                        TubleBioData.Parameters.AddWithValue("@WorkersID", textBoxWorkerID.Text);
                        TubleBioData.Parameters.AddWithValue("@FName", textBoxFName.Text);
                        TubleBioData.Parameters.AddWithValue("@LName", textBoxLName.Text);
                        TubleBioData.Parameters.AddWithValue("@MName", textBoxMName.Text);
                        TubleBioData.Parameters.AddWithValue("@Suffix", textBoxSuffix.Text);
                        TubleBioData.Parameters.AddWithValue("@BirthDate", Convert.ToDateTime(dateTimePickerbirthdate.Text));
                        TubleBioData.Parameters.AddWithValue("@HireDate", Convert.ToDateTime(DateTime.Now.ToShortDateString()));
                        TubleBioData.Parameters.AddWithValue("@MaritalStatus", Convert.ToString(comboBoxMartialStatus.SelectedItem));
                        TubleBioData.Parameters.AddWithValue("@Religion", textBoxReligion.Text);
                        TubleBioData.Parameters.AddWithValue("@NumberOfChildren", numericUpDownNumofChil.Value);
                        TubleBioData.Parameters.AddWithValue("@Address", textBoxAddress.Text);
                        TubleBioData.Parameters.AddWithValue("@ContactNumber", Class.contfirstandfirsttuble[0] + Class.contsecondthirdtuble[0] + Class.contsecondthirdtuble[1]);
                        TubleBioData.Parameters.AddWithValue("@EmergencyContact", Class.emerfirstandfirsttuble[0] + Class.emersecondthirdtuble[0] + Class.emersecondthirdtuble[1]);
                        TubleBioData.Parameters.AddWithValue("@TinID", maskedTextBoxTinID.Text);
                        TubleBioData.Parameters.AddWithValue("@PhilHealth", maskedTextBoxPhilHealth.Text);
                        TubleBioData.Parameters.AddWithValue("@SSS", maskedTextBoxSSS.Text);

                        tubleMS = new MemoryStream();
                        pictureBoxWorker.Image.Save(tubleMS, ImageFormat.Jpeg);
                        byte[] photo_array = new byte[tubleMS.Length];
                        tubleMS.Position = 0;
                        tubleMS.Read(photo_array, 0, photo_array.Length);
                        TubleBioData.Parameters.AddWithValue("@Picture", photo_array);

                        tubleQR = new MemoryStream();
                        pictureBoxQRCode.Image.Save(tubleQR, ImageFormat.Jpeg);
                        byte[] qr_array = new byte[tubleQR.Length];
                        tubleQR.Position = 0;
                        tubleQR.Read(qr_array, 0, qr_array.Length);
                        TubleBioData.Parameters.AddWithValue("@QRPicture", qr_array);

                        TubleBioData.ExecuteNonQuery();

                        tublecon.Close();

                        panelBioData.Enabled = false;
                        panelImage.Enabled = false;
                        SuccessBioData++;
                        //END Biodata
                    }
                }
                catch
                {
                    MessageBox.Show("Error in Worker Biodata");
                    tublecon.Close();
                }

                try
                {
                    if (SuccessWorkExp.Equals(0))
                    {
                        int YearHire = 0;
                        if (Convert.ToString(comboBoxYearHire.SelectedItem).Equals("")) { YearHire = 0; }
                        else { YearHire = Convert.ToInt16(comboBoxYearHire.SelectedItem); }
                        //Working Experience
                        SqlCommand TubleWorkingExp = new SqlCommand("INSERT INTO tblWorkingExperience (WorkersID, NameOfCompany, Position, YearHire, Reference) VALUES (@WorkersID, @NameOfCompany, @Position, @YearHire, @Reference)", tublecon);
                        TubleWorkingExp.Parameters.AddWithValue("@WorkersID", textBoxWorkerID.Text);
                        TubleWorkingExp.Parameters.AddWithValue("@NameOfCompany", textBoxNameOfCompany.Text);
                        TubleWorkingExp.Parameters.AddWithValue("@Position", textBoxPosition.Text);
                        TubleWorkingExp.Parameters.AddWithValue("@YearHire", YearHire);
                        TubleWorkingExp.Parameters.AddWithValue("@Reference", textBoxReference.Text);
                        tublecon.Open();
                        TubleWorkingExp.ExecuteNonQuery();
                        tublecon.Close();

                        panelWorkingExperience.Enabled = false;
                        SuccessWorkExp++;
                        //END WorkingExperience
                    }
                }
                catch (Exception)
                {
                    MessageBox.Show("Error in Working Experience");
                    tublecon.Close();
                }

                try
                {
                    if (SuccessErrorEduQual.Equals(0))
                    {
                        //Educational Qualification
                        SqlCommand TubleEducationalQual = new SqlCommand("INSERT INTO tblEducationalQualification (WorkersID, Education) VALUES (@WorkersID, @Education)", tublecon);
                        TubleEducationalQual.Parameters.AddWithValue("@WorkersID", textBoxWorkerID.Text);
                        TubleEducationalQual.Parameters.AddWithValue("@Education", textBoxEducation.Text);
                        tublecon.Open();
                        TubleEducationalQual.ExecuteNonQuery();
                        tublecon.Close();

                        panelEducationalQualification.Enabled = false;
                        SuccessErrorEduQual++;
                        //END Educational Qualification
                    }
                }
                catch (Exception)
                {
                    MessageBox.Show("Error in Educational Qualification");
                    tublecon.Close();
                }

                try
                {
                    if (SuccessErrorSchedule.Equals(0))
                    {
                        //Worker Schedule

                        string[] Monday = new string[1];
                        string[] Tuesday = new string[1];
                        string[] Wednesday = new string[1];
                        string[] Thursday = new string[1];
                        string[] Fridday = new string[1];
                        string[] Saturday = new string[1];
                        string[] Sunday = new string[1];

                        Monday = dateTimePickerMonday.Text.Split(' ');
                        Tuesday = dateTimePickerTuesday.Text.Split(' ');
                        Wednesday = dateTimePickerWednesday.Text.Split(' ');
                        Thursday = dateTimePickerThursday.Text.Split(' ');
                        Fridday = dateTimePickerFriday.Text.Split(' ');
                        Saturday = dateTimePickerSaturday.Text.Split(' ');
                        Sunday = dateTimePickerSunday.Text.Split(' ');

                        if (checkBoxMon.Checked.Equals(true))
                        { Monday[0] = "NULL"; Monday[1] = ""; }
                        else { Monday[0] = "'" + Monday[0] + "'"; }

                        if (checkBoxTue.Checked.Equals(true))
                        { Tuesday[0] = "NULL"; Tuesday[1] = ""; }
                        else { Tuesday[0] = "'" + Tuesday[0] + "'"; }

                        if (checkBoxWed.Checked.Equals(true))
                        { Wednesday[0] = "NULL"; Wednesday[1] = ""; }
                        else { Wednesday[0] = "'" + Wednesday[0] + "'"; }

                        if (checkBoxThurs.Checked.Equals(true))
                        { Thursday[0] = "NULL"; Thursday[1] = ""; }
                        else { Thursday[0] = "'" + Thursday[0] + "'"; }

                        if (checkBoxFri.Checked.Equals(true))
                        { Fridday[0] = "NULL"; Fridday[1] = ""; }
                        else { Fridday[0] = "'" + Fridday[0] + "'"; }

                        if (checkBoxSat.Checked.Equals(true))
                        { Saturday[0] = "NULL"; Saturday[1] = ""; }
                        else { Saturday[0] = "'" + Saturday[0] + "'"; }

                        if (checkBoxSun.Checked.Equals(true))
                        { Sunday[0] = "NULL"; Sunday[1] = ""; }
                        else { Sunday[0] = "'" + Sunday[0] + "'"; }

                        //////////////////////////////////////////////////////
                        Class.intaccept = 0;
                        if (Convert.ToDateTime(dateTimePickerMonday.Text) > Convert.ToDateTime("8:00 AM") && dateTimePickerMonday.Enabled.Equals(true))
                        { Class.intaccept++; }
                        if (Convert.ToDateTime(dateTimePickerTuesday.Text) > Convert.ToDateTime("8:00 AM") && dateTimePickerTuesday.Enabled.Equals(true))
                        { Class.intaccept++; }
                        if (Convert.ToDateTime(dateTimePickerWednesday.Text) > Convert.ToDateTime("8:00 AM") && dateTimePickerWednesday.Enabled.Equals(true))
                        { Class.intaccept++; }
                        if (Convert.ToDateTime(dateTimePickerThursday.Text) > Convert.ToDateTime("8:00 AM") && dateTimePickerThursday.Enabled.Equals(true))
                        { Class.intaccept++; }
                        if (Convert.ToDateTime(dateTimePickerFriday.Text) > Convert.ToDateTime("8:00 AM") && dateTimePickerFriday.Enabled.Equals(true))
                        { Class.intaccept++; }
                        if (Convert.ToDateTime(dateTimePickerSaturday.Text) > Convert.ToDateTime("8:00 AM") && dateTimePickerSaturday.Enabled.Equals(true))
                        { Class.intaccept++; }
                        if (Convert.ToDateTime(dateTimePickerSunday.Text) > Convert.ToDateTime("8:00 AM") && dateTimePickerSunday.Enabled.Equals(true))
                        { Class.intaccept++; }

                        //////////////////////////////////////////////////////

                        if (Class.intaccept.Equals(0))
                        {
                            SqlCommand TubleWorkingExp = new SqlCommand("INSERT INTO tblWorkersSchedule (WorkersID, SunSched, SunDayNight, MonSched, MonDayNight, TueSched, TueDayNight, WedSched, WedDayNight, ThuSched, ThuDayNight, FriSched, FriDayNight, SatSched, SatDayNight) " +
                            "VALUES (@WorkersID, " + Sunday[0] + ", @SunDayNight, " + Monday[0] + ", @MonDayNight, " + Tuesday[0] + ", @TueDayNight, " + Wednesday[0] + ", @WedDayNight, " + Thursday[0] + ", @ThuDayNight, " + Fridday[0] + ", @FriDayNight, " + Saturday[0] + ", @SatDayNight)", tublecon);
                            TubleWorkingExp.Parameters.AddWithValue("@WorkersID", textBoxWorkerID.Text);
                            TubleWorkingExp.Parameters.AddWithValue("@SunDayNight", Sunday[1]);
                            TubleWorkingExp.Parameters.AddWithValue("@MonDayNight", Monday[1]);
                            TubleWorkingExp.Parameters.AddWithValue("@TueDayNight", Tuesday[1]);
                            TubleWorkingExp.Parameters.AddWithValue("@WedDayNight", Wednesday[1]);
                            TubleWorkingExp.Parameters.AddWithValue("@ThuDayNight", Thursday[1]);
                            TubleWorkingExp.Parameters.AddWithValue("@FriDayNight", Fridday[1]);
                            TubleWorkingExp.Parameters.AddWithValue("@SatDayNight", Saturday[1]);
                            tublecon.Open();
                            TubleWorkingExp.ExecuteNonQuery();
                            tublecon.Close();

                            panelWorkerSchedule.Enabled = false;
                            SuccessErrorSchedule++;
                            //END Worker Schedule
                        } else { MessageBox.Show("Can't accept set schedule"); }
                    }
                }
                catch (Exception)
                {
                    MessageBox.Show("Error in Worker Schedule");
                    tublecon.Close();
                }

                if (SuccessBioData != 0 && SuccessWorkExp != 0 && SuccessErrorEduQual != 0 && SuccessErrorSchedule != 0)
                {
                    Class.WorkersID = textBoxWorkerID.Text;
                    FormGenerateQRCode GQRC = new FormGenerateQRCode();
                    GQRC.ShowDialog();
                    EmployeeStatus();
                    this.Hide();
                }
            }
            else
            {
                MessageBox.Show(Class.AddWorkerCollectionStatusError);
            }
        }

        void EmployeeStatus()
        {
            SqlCommand cmd = new SqlCommand("INSERT INTO [dbo].[tblAdminStatus] ([ID],[Date],[Time],[TimeDayNight],[Type],WorkersID,[Description]) VALUES (@ID, @Date ,@Time, @TimeDayNight, @Type, @WorkersID, @Description)", tublecon);
            cmd.Parameters.AddWithValue("@ID", Class.EmployeeID);
            cmd.Parameters.AddWithValue("@Date", Convert.ToDateTime(DateTime.Now.ToShortDateString()));
            cmd.Parameters.AddWithValue("@Time", Convert.ToDateTime(DateTime.Now.ToShortTimeString()));

            string converttime = DateTime.Now.ToShortTimeString();
            string[] convertsplittime = converttime.Split(' ');
            cmd.Parameters.AddWithValue("@TimeDayNight", convertsplittime[1]);

            cmd.Parameters.AddWithValue("@Type", "Add Worker");
            cmd.Parameters.AddWithValue("@WorkersID", textBoxWorkerID.Text);
            cmd.Parameters.AddWithValue("@Description", "Worker BioData, Working Experience, Worker Schedule, Educational Qualification");
            tublecon.Open();
            cmd.ExecuteNonQuery();
            tublecon.Close();
        }

        void DebuggingTubs () 
        {
            Class.AddWorkersCollectionError = 0;
            Class.AddWorkerCollectionStatusError = "";
            //Debug WorkerName
            if (textBoxFName.Text.Equals("") || textBoxLName.Text.Equals(""))
            {
                Class.AddWorkerCollectionStatusError = "Worker Name does not required to be empty";
                Class.AddWorkersCollectionError++;
            }
            //Debug Birth Date
            string splitdate = dateTimePickerbirthdate.Value.ToString();
                //Remove Month and Day
            string[] consplitdate = splitdate.Split('/');
                //Remove Time
            string[] getYear = consplitdate[2].Split(' ');
                //Subtract the Value
            int age = Convert.ToInt16(DateTime.Now.Year.ToString()) - Convert.ToInt16(getYear[0]);

            if (age < 18) { Class.AddWorkerCollectionStatusError += "\nCan't accept your age below 17"; Class.AddWorkersCollectionError++; }
            //Debug MartialStatus
            if (Convert.ToString(comboBoxMartialStatus.SelectedItem).Equals(""))
            {
                Convert.ToString(comboBoxMartialStatus.SelectedItem);
                Class.AddWorkerCollectionStatusError += "\nSelect item in maritial status";
                Class.AddWorkersCollectionError++;
            }
            //Debug Religion
            if (textBoxReligion.Text.Equals(""))
            {
                Convert.ToString(textBoxReligion.Text);
                Class.AddWorkerCollectionStatusError += "\nSelect item in religion";
                Class.AddWorkersCollectionError++;
            }
            //Debug Address
            if (textBoxAddress.Text.Equals("")) 
            {
                Class.AddWorkerCollectionStatusError += "\nFill the Address";
                Class.AddWorkersCollectionError++;
            }
            //Debug Contact Num
            if (maskedTextBoxContactNum.Text.Length < 14)
            {
                Class.AddWorkerCollectionStatusError += "\nFill the Contact Number";
                Class.AddWorkersCollectionError++;
            }
            //Debug Emergency Contact
            if (maskedTextBoxEmergencyContact.Text.Length < 14)
            {
                Class.AddWorkerCollectionStatusError += "\nFill the Emergency Contact";
                Class.AddWorkersCollectionError++;
            }

            if (pictureBoxWorker.Image == null)
            {
                Class.AddWorkerCollectionStatusError += "\nUpload Your Photo";
                Class.AddWorkersCollectionError++;
            }
        }

        void SplitContacts() {
            Class.contsplitspace = maskedTextBoxContactNum.Text;
            Class.contspittuble = Class.contsplitspace.Split(' ');
            Class.contfirsttuble = Class.contspittuble[0].Split('(');
            Class.contsecondthirdtuble = Class.contspittuble[1].Split('-');
            Class.contfirstandfirsttuble = Class.contfirsttuble[1].Split(')');

            Class.emersplitspace = maskedTextBoxEmergencyContact.Text;
            Class.emerspittuble = Class.emersplitspace.Split(' ');
            Class.emerfirsttuble = Class.emerspittuble[0].Split('(');
            Class.emersecondthirdtuble = Class.emerspittuble[1].Split('-');
            Class.emerfirstandfirsttuble = Class.emerfirsttuble[1].Split(')');
        }

        public static byte[] GetPhoto(string filePath)
        {
            FileStream stream = new FileStream(filePath, FileMode.Open, FileAccess.Read);
            BinaryReader reader = new BinaryReader(stream);

            byte[] photo = reader.ReadBytes((int)stream.Length);

            reader.Close();
            stream.Close();

            return photo;
        } 

        private void buttonFileUpload_Click(object sender, EventArgs e)
        {
            openFileDialog1.InitialDirectory = "C://Desktop";
            openFileDialog1.Title = "Select image to be upload.";
            openFileDialog1.Filter = "Image Only(*.jpg; *.jpeg; *.gif; *.bmp; *.png)|*.jpg; *.jpeg; *.gif; *.bmp; *.png";
            openFileDialog1.FilterIndex = 1;
            try
            {
                if (openFileDialog1.ShowDialog().Equals(System.Windows.Forms.DialogResult.OK))
                {
                    if (openFileDialog1.CheckFileExists)
                    {
                        string path = System.IO.Path.GetFullPath(openFileDialog1.FileName);
                        Class.Picture = GetPhoto(path);
                        pictureBoxWorker.Image = new Bitmap(openFileDialog1.FileName);
                        pictureBoxWorker.SizeMode = PictureBoxSizeMode.Zoom;
                    }
                }
                else
                {
                    MessageBox.Show("Please Upload image.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void buttonClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buttonAddWorker_Click(object sender, EventArgs e)
        {
            DebuggingTubs();
            SplitContacts();
            AddWorker();
        }

        private void comboBoxMartialStatus_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (Convert.ToString(comboBoxMartialStatus.SelectedItem).Equals("Single"))
            {
                numericUpDownNumofChil.Enabled = false;
                numericUpDownNumofChil.Value = 0;
            }
            else {
                numericUpDownNumofChil.Enabled = true;
            }
        }

        private void buttonQRCode_Click(object sender, EventArgs e)
        {
            FormGenerateQRCode fqrcode = new FormGenerateQRCode();
            Class.WorkersID = textBoxWorkerID.Text;
            fqrcode.ShowDialog();
        }

        private void buttonTakeAPicture_Click(object sender, EventArgs e)
        {
            FormScannerQRCode SQRC = new FormScannerQRCode();
            SQRC.ShowDialog();
        }

        private void checkBoxMon_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxMon.Checked.Equals(true))
            { dateTimePickerMonday.Enabled = false; }
            else { dateTimePickerMonday.Enabled = true; }
        }

        private void checkBoxTue_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxTue.Checked.Equals(true))
            { dateTimePickerTuesday.Enabled = false; }
            else { dateTimePickerTuesday.Enabled = true; }
        }

        private void checkBoxWed_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxWed.Checked.Equals(true))
            { dateTimePickerWednesday.Enabled = false; }
            else { dateTimePickerWednesday.Enabled = true; }
        }

        private void checkBoxThurs_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxThurs.Checked.Equals(true))
            { dateTimePickerThursday.Enabled = false; }
            else { dateTimePickerThursday.Enabled = true; }
        }

        private void checkBoxFri_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxFri.Checked.Equals(true))
            { dateTimePickerFriday.Enabled = false; }
            else { dateTimePickerFriday.Enabled = true; }
        }

        private void checkBoxSat_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxSat.Checked.Equals(true))
            { dateTimePickerSaturday.Enabled = false; }
            else { dateTimePickerSaturday.Enabled = true; }
        }

        private void checkBoxSun_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxSun.Checked.Equals(true))
            { dateTimePickerSunday.Enabled = false; }
            else { dateTimePickerSunday.Enabled = true; }
        }
    }
}
