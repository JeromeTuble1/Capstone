﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace QRCodeDemo
{
    public partial class FormShifts : Form
    {
        SqlConnection tublecon = new SqlConnection(Class.tublecon);
        public FormShifts()
        {
            InitializeComponent();
        }

        private void FormShifts_Load(object sender, EventArgs e)
        {
            LoadData();
        }
        void LoadData()
        {
            SqlCommand tublecmd = new SqlCommand(@"SELECT WS.WorkersID, WBD.LName + ', ' + WBD.FName + ' ' + WBD.MName + ' ' + WBD.Suffix AS [Name], 
                                                   CONVERT(time(0),CONVERT(VARCHAR(20), WS.MonSched) + ' ' + WS.MonDayNight) AS Monday,
                                                   CONVERT(time(0),CONVERT(VARCHAR(20), WS.TueSched) + ' ' + WS.TueDayNight) AS Tuesday,
                                                   CONVERT(time(0),CONVERT(VARCHAR(20), WS.WedSched) + ' ' + WS.WedDayNight) AS Wednesday,
                                                   CONVERT(time(0),CONVERT(VARCHAR(20), WS.ThuSched) + ' ' + WS.ThuDayNight) AS Thursday,
                                                   CONVERT(time(0),CONVERT(VARCHAR(20), WS.FriSched) + ' ' + WS.FriDayNight) AS Friday,
                                                   CONVERT(time(0),CONVERT(VARCHAR(20), WS.SatSched) + ' ' + WS.SatDayNight) AS Saturday,
                                                   CONVERT(time(0),CONVERT(VARCHAR(20), WS.SunSched) + ' ' + WS.SunDayNight) AS Sunday
                                                   FROM tblWorkersSchedule WS INNER JOIN tblWorkersBioData WBD ON WS.WorkersID = WBD.WorkersID", tublecon);
            SqlDataAdapter da = new SqlDataAdapter(tublecmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            dataGridViewShifts.DataSource = dt;
        }

        private void dataGridViewShifts_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            Class.WorkersID = dataGridViewShifts.CurrentRow.Cells[0].Value.ToString();
            FormShiftsEdit SE = new FormShiftsEdit();
            SE.ShowDialog();
            LoadData();
        }

        private void textBoxSearch_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (textBoxSearch.Text.Equals(""))
                {
                    LoadData();
                }
                else
                {
                    Search();
                }
            }
        }

        void Search()
        {
            SqlCommand tublecmd = new SqlCommand("SELECT WS.WorkersID, WBD.LName + ', ' + WBD.FName + ' ' + WBD.MName + ' ' + WBD.Suffix AS [Name], CONVERT(VARCHAR(20), WS.MonSched) + ' ' + WS.MonDayNight AS Monday, CONVERT(VARCHAR(20), WS.TueSched) + ' ' + WS.TueDayNight AS Tuesday, CONVERT(VARCHAR(20), WS.WedSched) + ' ' + WS.WedDayNight AS Wednesday, CONVERT(VARCHAR(20), WS.ThuSched) + ' ' + WS.ThuDayNight AS Thursday, CONVERT(VARCHAR(20), WS.FriSched) + ' ' + WS.FriDayNight AS Friday, CONVERT(VARCHAR(20), WS.SatSched) + ' ' + WS.SatDayNight AS Saturday, CONVERT(VARCHAR(20), WS.SunSched) + ' ' + WS.SunDayNight AS Sunday FROM tblWorkersSchedule WS INNER JOIN tblWorkersBioData WBD ON WS.WorkersID = WBD.WorkersID WHERE WS.WorkersID = @WorkersID", tublecon);
            tublecmd.Parameters.AddWithValue("@WorkersID", textBoxSearch.Text);
            SqlDataAdapter da = new SqlDataAdapter(tublecmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            dataGridViewShifts.DataSource = dt;
        }
    }
}
