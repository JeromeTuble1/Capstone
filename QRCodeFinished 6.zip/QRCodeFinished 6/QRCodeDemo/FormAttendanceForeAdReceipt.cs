﻿using Microsoft.Reporting.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace QRCodeDemo
{
    public partial class FormAttendanceForeAdReceipt : Form
    {
        SqlConnection tublecon = new SqlConnection(Class.tublecon);

        public FormAttendanceForeAdReceipt()
        {
            InitializeComponent();
        }

        private void FormAttendanceEmployeeReceipt_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'DBdjaasDataSet1.tblAdminStatus' table. You can move, or remove it, as needed.
            // TODO: This line of code loads data into the 'DBdjaasDataSet1.tblAdminStatus' table. You can move, or remove it, as needed.
            
            IndividualGetDataName();
        }

        void IndividualGetDataName()
        {
            this.tblAdminStatusTableAdapter.Fill(this.DBdjaasDataSet1.tblAdminStatus);
            SqlCommand tublecmd = new SqlCommand("SELECT L.ID, L.LName +', '+ L.FName +' '+ L.MName, ES.[Date], ES.[Time], ES.TimeDayNight, ES.[Type], ES.WorkersID, ES.[Description] FROM tblAdminStatus ES INNER JOIN tblLogin L ON ES.ID = L.ID WHERE L.ID = @ID", tublecon);
            tublecmd.Parameters.AddWithValue("@ID", Class.EmployeeID);
            SqlDataAdapter tubleda = new SqlDataAdapter(tublecmd);
            DataTable tubledt = new DataTable();
            tubleda.Fill(tubledt);
            tblAdminStatusBindingSource.DataSource = tubledt;

            if (tubledt.Rows.Count.Equals(0))
            {
                MessageBox.Show("No Report");
                this.Close();
            }
            else
            {
                ReportParameter[] para = new ReportParameter[] { new ReportParameter("ID", tubledt.Rows[0][0].ToString()), new ReportParameter("Name", tubledt.Rows[0][1].ToString()), new ReportParameter("Date", DateTime.Now.ToShortDateString()) };
                this.reportViewer1.LocalReport.SetParameters(para);
                this.reportViewer1.RefreshReport();
            }
        }

        private void reportViewer1_Load(object sender, EventArgs e)
        {

        }
    }
}
