﻿using Microsoft.Reporting.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace QRCodeDemo
{
    public partial class FormAttendanceEmployeeTempReceipt : Form
    {
        SqlConnection tublecon = new SqlConnection(Class.tublecon);

        public FormAttendanceEmployeeTempReceipt()
        {
            InitializeComponent();
        }

        private void FormAttendanceEmployeeTemp_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'DBdjaasDataSet3.tblEmployeeTemp' table. You can move, or remove it, as needed.
            IndividualGetDataName();
        }

        void IndividualGetDataName()
        {

            SqlCommand tublecmd = new SqlCommand("SELECT ET.LoggedInDate, ET.LoggedInTime, ET.LoggedOutDate, ET.LoggedOutTime, L.LName + ', ' + L.FName + ' ' + L.MName FROM tblEmployeeTemp ET INNER JOIN tblLogin L ON L.EmployeeID = ET.EmployeeID WHERE ET.EmployeeID = @EmployeeID AND L.EmployeeID = @EmployeeID", tublecon);
            tublecmd.Parameters.AddWithValue("@EmployeeID", Class.EmployeeID);
            SqlDataAdapter tubleda = new SqlDataAdapter(tublecmd);
            DataTable tubledt = new DataTable();
            tubleda.Fill(tubledt);
            tblEmployeeTempBindingSource.DataSource = tubledt;


            if (tubledt.Rows.Count.Equals(0))
            {
                MessageBox.Show("No Report");
                this.Close();
            }
            else
            {
                ReportParameter[] para = new ReportParameter[] { new ReportParameter("pName", tubledt.Rows[0][4].ToString()), new ReportParameter("pDate", DateTime.Now.ToShortDateString()) };
                this.reportViewer1.LocalReport.SetParameters(para);
                this.reportViewer1.RefreshReport();
            }
        }
    }
}
