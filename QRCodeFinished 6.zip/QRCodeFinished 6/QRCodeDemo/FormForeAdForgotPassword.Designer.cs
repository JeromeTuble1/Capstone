﻿namespace QRCodeDemo
{
    partial class FormForeAdForgotPassword
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBoxEmployID = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.buttonFindPassword = new System.Windows.Forms.Button();
            this.dateTimePickerbirthdate = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxYourPassword = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.shapeContainer1 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.lineShape2 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape1 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.jbtPanelGIF1 = new QRCodeDemo.JBTControls.JBTPanelGIF();
            this.panel1 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // textBoxEmployID
            // 
            this.textBoxEmployID.BackColor = System.Drawing.SystemColors.Control;
            this.textBoxEmployID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxEmployID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxEmployID.Location = new System.Drawing.Point(220, 183);
            this.textBoxEmployID.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxEmployID.Name = "textBoxEmployID";
            this.textBoxEmployID.Size = new System.Drawing.Size(249, 30);
            this.textBoxEmployID.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(73, 186);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(129, 25);
            this.label1.TabIndex = 2;
            this.label1.Text = "Employee ID:";
            // 
            // buttonFindPassword
            // 
            this.buttonFindPassword.BackColor = System.Drawing.Color.LightBlue;
            this.buttonFindPassword.FlatAppearance.BorderSize = 0;
            this.buttonFindPassword.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonFindPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonFindPassword.Location = new System.Drawing.Point(201, 334);
            this.buttonFindPassword.Margin = new System.Windows.Forms.Padding(4);
            this.buttonFindPassword.Name = "buttonFindPassword";
            this.buttonFindPassword.Size = new System.Drawing.Size(140, 48);
            this.buttonFindPassword.TabIndex = 4;
            this.buttonFindPassword.Text = "Submit";
            this.buttonFindPassword.UseVisualStyleBackColor = false;
            this.buttonFindPassword.Click += new System.EventHandler(this.buttonFindPassword_Click);
            // 
            // dateTimePickerbirthdate
            // 
            this.dateTimePickerbirthdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePickerbirthdate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePickerbirthdate.Location = new System.Drawing.Point(220, 222);
            this.dateTimePickerbirthdate.Margin = new System.Windows.Forms.Padding(4);
            this.dateTimePickerbirthdate.Name = "dateTimePickerbirthdate";
            this.dateTimePickerbirthdate.Size = new System.Drawing.Size(140, 30);
            this.dateTimePickerbirthdate.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(103, 228);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 25);
            this.label2.TabIndex = 6;
            this.label2.Text = "Birth date:";
            // 
            // textBoxYourPassword
            // 
            this.textBoxYourPassword.BackColor = System.Drawing.SystemColors.Control;
            this.textBoxYourPassword.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxYourPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxYourPassword.Location = new System.Drawing.Point(220, 263);
            this.textBoxYourPassword.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxYourPassword.Name = "textBoxYourPassword";
            this.textBoxYourPassword.ReadOnly = true;
            this.textBoxYourPassword.Size = new System.Drawing.Size(249, 30);
            this.textBoxYourPassword.TabIndex = 7;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(52, 265);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(150, 25);
            this.label3.TabIndex = 8;
            this.label3.Text = "Your Password:";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(204, 28);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(133, 123);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 9;
            this.pictureBox1.TabStop = false;
            // 
            // shapeContainer1
            // 
            this.shapeContainer1.Location = new System.Drawing.Point(0, 0);
            this.shapeContainer1.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            this.shapeContainer1.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.lineShape2,
            this.lineShape1});
            this.shapeContainer1.Size = new System.Drawing.Size(533, 411);
            this.shapeContainer1.TabIndex = 10;
            this.shapeContainer1.TabStop = false;
            // 
            // lineShape2
            // 
            this.lineShape2.Name = "lineShape2";
            this.lineShape2.X1 = 165;
            this.lineShape2.X2 = 351;
            this.lineShape2.Y1 = 236;
            this.lineShape2.Y2 = 236;
            // 
            // lineShape1
            // 
            this.lineShape1.Name = "lineShape1";
            this.lineShape1.X1 = 165;
            this.lineShape1.X2 = 351;
            this.lineShape1.Y1 = 171;
            this.lineShape1.Y2 = 171;
            // 
            // jbtPanelGIF1
            // 
            this.jbtPanelGIF1.Angle = 356F;
            this.jbtPanelGIF1.BorderRadius = 1;
            this.jbtPanelGIF1.Color0 = System.Drawing.Color.Blue;
            this.jbtPanelGIF1.Color1 = System.Drawing.Color.Pink;
            this.jbtPanelGIF1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.jbtPanelGIF1.ForeColor = System.Drawing.Color.White;
            this.jbtPanelGIF1.Location = new System.Drawing.Point(0, 0);
            this.jbtPanelGIF1.Name = "jbtPanelGIF1";
            this.jbtPanelGIF1.Size = new System.Drawing.Size(533, 411);
            this.jbtPanelGIF1.TabIndex = 11;
            // 
            // panel1
            // 
            this.panel1.Location = new System.Drawing.Point(26, 171);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(469, 140);
            this.panel1.TabIndex = 12;
            // 
            // FormEmployeeForgotPassword
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(533, 411);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBoxYourPassword);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dateTimePickerbirthdate);
            this.Controls.Add(this.buttonFindPassword);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBoxEmployID);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.jbtPanelGIF1);
            this.Controls.Add(this.shapeContainer1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormEmployeeForgotPassword";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Forgot Password";
            this.Load += new System.EventHandler(this.FormEmployeeForgotPassword_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxEmployID;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button buttonFindPassword;
        private System.Windows.Forms.DateTimePicker dateTimePickerbirthdate;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxYourPassword;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape2;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape1;
        private JBTControls.JBTPanelGIF jbtPanelGIF1;
        private System.Windows.Forms.Panel panel1;
    }
}