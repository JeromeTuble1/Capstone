﻿using Microsoft.Reporting.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace QRCodeDemo
{
    public partial class FormWorkerEmployeeID : Form
    {
        SqlConnection con = new SqlConnection(Class.tublecon);

        public FormWorkerEmployeeID()
        {
            InitializeComponent();
        }

        private void FormWorkerEmployeeID_Load(object sender, EventArgs e)
        {
            IndividualGetDataName();
        }
        void IndividualGetDataName()
        {
            this.tblWorkersBioDataTableAdapter.Fill(this.DBdjaasDataSetBioData.tblWorkersBioData);
            SqlCommand tublecmd = new SqlCommand("SELECT LName +', '+ FName + ' ' + MName + ' ' + Suffix, Picture, ContactNumber FROM tblWorkersBioData WHERE WorkersID = @WorkersID", con);
            tublecmd.Parameters.AddWithValue("@WorkersID","2022-0001-Worker-DJAAS");
            SqlDataAdapter da = new SqlDataAdapter(tublecmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            ReportParameter[] para = new ReportParameter[] { new ReportParameter("pName", dt.Rows[0][0].ToString()), new ReportParameter("pContact", dt.Rows[0][2].ToString()) };
            this.reportViewer1.LocalReport.SetParameters(para);
            ReportDataSource rds = new ReportDataSource("DataSetBioData", dt);
            this.reportViewer1.ProcessingMode = ProcessingMode.Local;
            this.reportViewer1.LocalReport.DataSources.Add(rds);
            this.reportViewer1.RefreshReport();
        }
    }
}
