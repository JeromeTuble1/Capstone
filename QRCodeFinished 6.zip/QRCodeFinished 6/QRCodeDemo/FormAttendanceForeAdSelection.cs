﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace QRCodeDemo
{
    public partial class FormAttendanceForeAdSelection : Form
    {
        public FormAttendanceForeAdSelection()
        {
            InitializeComponent();
        }

        private void buttonWorkersAttendanceReport_Click(object sender, EventArgs e)
        {
            FormAttendanceForeAdReceipt AER = new FormAttendanceForeAdReceipt();
            this.Hide();
            AER.ShowDialog();
        }

        private void buttonEmployeeInOutReport_Click(object sender, EventArgs e)
        {
            FormAttendanceForeAdTempReceipt AET = new FormAttendanceForeAdTempReceipt();
            this.Hide();
            AET.ShowDialog();
        }
    }
}
