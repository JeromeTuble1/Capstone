﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace QRCodeDemo
{
    public partial class FormAttendanceEmployeeSelection : Form
    {
        public FormAttendanceEmployeeSelection()
        {
            InitializeComponent();
        }

        private void buttonWorkersAttendanceReport_Click(object sender, EventArgs e)
        {
            FormAttendanceEmployeeReceipt AER = new FormAttendanceEmployeeReceipt();
            this.Hide();
            AER.ShowDialog();
        }

        private void buttonEmployeeInOutReport_Click(object sender, EventArgs e)
        {
            FormAttendanceEmployeeTempReceipt AET = new FormAttendanceEmployeeTempReceipt();
            this.Hide();
            AET.ShowDialog();
        }
    }
}
