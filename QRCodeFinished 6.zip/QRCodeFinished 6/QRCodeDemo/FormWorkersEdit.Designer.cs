﻿namespace QRCodeDemo
{
    partial class FormWorkersEdit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.panelEducationalQualification = new System.Windows.Forms.Panel();
            this.label23 = new System.Windows.Forms.Label();
            this.textBoxEducation = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.flowLayoutPanel3 = new System.Windows.Forms.FlowLayoutPanel();
            this.panelImage = new System.Windows.Forms.Panel();
            this.pictureBoxQRCode = new System.Windows.Forms.PictureBox();
            this.buttonTakeAPicture = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.buttonFileUpload = new System.Windows.Forms.Button();
            this.panel6 = new System.Windows.Forms.Panel();
            this.buttonQRCode = new System.Windows.Forms.Button();
            this.buttonEditWorker = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.dateTimePickerSunday = new System.Windows.Forms.DateTimePicker();
            this.dateTimePickerSaturday = new System.Windows.Forms.DateTimePicker();
            this.dateTimePickerFriday = new System.Windows.Forms.DateTimePicker();
            this.dateTimePickerThursday = new System.Windows.Forms.DateTimePicker();
            this.panel1 = new System.Windows.Forms.Panel();
            this.checkBoxSun = new System.Windows.Forms.CheckBox();
            this.checkBoxSat = new System.Windows.Forms.CheckBox();
            this.checkBoxFri = new System.Windows.Forms.CheckBox();
            this.checkBoxThurs = new System.Windows.Forms.CheckBox();
            this.checkBoxWed = new System.Windows.Forms.CheckBox();
            this.checkBoxTue = new System.Windows.Forms.CheckBox();
            this.checkBoxMon = new System.Windows.Forms.CheckBox();
            this.dateTimePickerWednesday = new System.Windows.Forms.DateTimePicker();
            this.dateTimePickerTuesday = new System.Windows.Forms.DateTimePicker();
            this.dateTimePickerMonday = new System.Windows.Forms.DateTimePicker();
            this.label51 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.panelWorkingExperience = new System.Windows.Forms.Panel();
            this.label16 = new System.Windows.Forms.Label();
            this.comboBoxYearHire = new System.Windows.Forms.ComboBox();
            this.label19 = new System.Windows.Forms.Label();
            this.textBoxPosition = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.textBoxNameOfCompany = new System.Windows.Forms.TextBox();
            this.textBoxReference = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.flowLayoutPanel2 = new System.Windows.Forms.FlowLayoutPanel();
            this.panelBioData = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.maskedTextBoxSSS = new System.Windows.Forms.MaskedTextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.maskedTextBoxPhilHealth = new System.Windows.Forms.MaskedTextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.maskedTextBoxTinID = new System.Windows.Forms.MaskedTextBox();
            this.textBoxReligion = new System.Windows.Forms.TextBox();
            this.label53 = new System.Windows.Forms.Label();
            this.textBoxSuffix = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.textBoxMName = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.maskedTextBoxEmergencyContact = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBoxContactNum = new System.Windows.Forms.MaskedTextBox();
            this.textBoxHireDate = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.buttonBack = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.textBoxLName = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.numericUpDownNumofChil = new System.Windows.Forms.NumericUpDown();
            this.label11 = new System.Windows.Forms.Label();
            this.textBoxFName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.dateTimePickerbirthdate = new System.Windows.Forms.DateTimePicker();
            this.comboBoxMartialStatus = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.textBoxAddress = new System.Windows.Forms.TextBox();
            this.textBoxWorkerID = new System.Windows.Forms.TextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.buttonAddWorkers = new System.Windows.Forms.Button();
            this.buttonGenerateID = new System.Windows.Forms.Button();
            this.panelEducationalQualification.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.flowLayoutPanel3.SuspendLayout();
            this.panelImage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxQRCode)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel6.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panelWorkingExperience.SuspendLayout();
            this.flowLayoutPanel2.SuspendLayout();
            this.panelBioData.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownNumofChil)).BeginInit();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(29, 11);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(194, 39);
            this.label1.TabIndex = 43;
            this.label1.Text = "Edit Worker";
            // 
            // panelEducationalQualification
            // 
            this.panelEducationalQualification.Controls.Add(this.label23);
            this.panelEducationalQualification.Controls.Add(this.textBoxEducation);
            this.panelEducationalQualification.Controls.Add(this.label22);
            this.panelEducationalQualification.Location = new System.Drawing.Point(4, 4);
            this.panelEducationalQualification.Margin = new System.Windows.Forms.Padding(4);
            this.panelEducationalQualification.Name = "panelEducationalQualification";
            this.panelEducationalQualification.Size = new System.Drawing.Size(508, 199);
            this.panelEducationalQualification.TabIndex = 62;
            // 
            // label23
            // 
            this.label23.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(16, 4);
            this.label23.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(226, 25);
            this.label23.TabIndex = 66;
            this.label23.Text = "Educational Qualification";
            // 
            // textBoxEducation
            // 
            this.textBoxEducation.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBoxEducation.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxEducation.Location = new System.Drawing.Point(155, 102);
            this.textBoxEducation.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxEducation.Multiline = true;
            this.textBoxEducation.Name = "textBoxEducation";
            this.textBoxEducation.Size = new System.Drawing.Size(293, 66);
            this.textBoxEducation.TabIndex = 64;
            // 
            // label22
            // 
            this.label22.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(41, 105);
            this.label22.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(88, 20);
            this.label22.TabIndex = 65;
            this.label22.Text = "Education:";
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.AutoScroll = true;
            this.flowLayoutPanel1.Controls.Add(this.panelEducationalQualification);
            this.flowLayoutPanel1.Location = new System.Drawing.Point(4, 227);
            this.flowLayoutPanel1.Margin = new System.Windows.Forms.Padding(4);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(521, 212);
            this.flowLayoutPanel1.TabIndex = 63;
            // 
            // flowLayoutPanel3
            // 
            this.flowLayoutPanel3.Controls.Add(this.panelImage);
            this.flowLayoutPanel3.Controls.Add(this.flowLayoutPanel1);
            this.flowLayoutPanel3.Controls.Add(this.panel6);
            this.flowLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Right;
            this.flowLayoutPanel3.Location = new System.Drawing.Point(940, 64);
            this.flowLayoutPanel3.Margin = new System.Windows.Forms.Padding(4);
            this.flowLayoutPanel3.Name = "flowLayoutPanel3";
            this.flowLayoutPanel3.Size = new System.Drawing.Size(529, 794);
            this.flowLayoutPanel3.TabIndex = 65;
            // 
            // panelImage
            // 
            this.panelImage.Controls.Add(this.pictureBoxQRCode);
            this.panelImage.Controls.Add(this.buttonTakeAPicture);
            this.panelImage.Controls.Add(this.pictureBox1);
            this.panelImage.Controls.Add(this.buttonFileUpload);
            this.panelImage.Location = new System.Drawing.Point(4, 4);
            this.panelImage.Margin = new System.Windows.Forms.Padding(4);
            this.panelImage.Name = "panelImage";
            this.panelImage.Size = new System.Drawing.Size(521, 215);
            this.panelImage.TabIndex = 61;
            // 
            // pictureBoxQRCode
            // 
            this.pictureBoxQRCode.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBoxQRCode.Location = new System.Drawing.Point(305, 20);
            this.pictureBoxQRCode.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBoxQRCode.Name = "pictureBoxQRCode";
            this.pictureBoxQRCode.Size = new System.Drawing.Size(147, 135);
            this.pictureBoxQRCode.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxQRCode.TabIndex = 60;
            this.pictureBoxQRCode.TabStop = false;
            // 
            // buttonTakeAPicture
            // 
            this.buttonTakeAPicture.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonTakeAPicture.BackColor = System.Drawing.Color.LightBlue;
            this.buttonTakeAPicture.FlatAppearance.BorderSize = 0;
            this.buttonTakeAPicture.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTakeAPicture.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonTakeAPicture.ForeColor = System.Drawing.Color.Black;
            this.buttonTakeAPicture.Location = new System.Drawing.Point(86, 165);
            this.buttonTakeAPicture.Margin = new System.Windows.Forms.Padding(4);
            this.buttonTakeAPicture.Name = "buttonTakeAPicture";
            this.buttonTakeAPicture.Size = new System.Drawing.Size(208, 38);
            this.buttonTakeAPicture.TabIndex = 59;
            this.buttonTakeAPicture.Text = "Take a Picture";
            this.buttonTakeAPicture.UseVisualStyleBackColor = false;
            this.buttonTakeAPicture.Click += new System.EventHandler(this.buttonTakeAPicture_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox1.Location = new System.Drawing.Point(99, 20);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(147, 135);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 56;
            this.pictureBox1.TabStop = false;
            // 
            // buttonFileUpload
            // 
            this.buttonFileUpload.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonFileUpload.BackColor = System.Drawing.Color.LightBlue;
            this.buttonFileUpload.FlatAppearance.BorderSize = 0;
            this.buttonFileUpload.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonFileUpload.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonFileUpload.ForeColor = System.Drawing.Color.Black;
            this.buttonFileUpload.Location = new System.Drawing.Point(302, 165);
            this.buttonFileUpload.Margin = new System.Windows.Forms.Padding(4);
            this.buttonFileUpload.Name = "buttonFileUpload";
            this.buttonFileUpload.Size = new System.Drawing.Size(93, 38);
            this.buttonFileUpload.TabIndex = 57;
            this.buttonFileUpload.Text = "Upload";
            this.buttonFileUpload.UseVisualStyleBackColor = false;
            this.buttonFileUpload.Click += new System.EventHandler(this.buttonFileUpload_Click);
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.buttonGenerateID);
            this.panel6.Controls.Add(this.buttonQRCode);
            this.panel6.Controls.Add(this.buttonEditWorker);
            this.panel6.Location = new System.Drawing.Point(4, 447);
            this.panel6.Margin = new System.Windows.Forms.Padding(4);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(521, 343);
            this.panel6.TabIndex = 62;
            // 
            // buttonQRCode
            // 
            this.buttonQRCode.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonQRCode.BackColor = System.Drawing.Color.LightBlue;
            this.buttonQRCode.FlatAppearance.BorderSize = 0;
            this.buttonQRCode.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonQRCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonQRCode.Location = new System.Drawing.Point(20, 276);
            this.buttonQRCode.Margin = new System.Windows.Forms.Padding(4);
            this.buttonQRCode.Name = "buttonQRCode";
            this.buttonQRCode.Size = new System.Drawing.Size(168, 54);
            this.buttonQRCode.TabIndex = 59;
            this.buttonQRCode.Text = "QR Code";
            this.buttonQRCode.UseVisualStyleBackColor = false;
            this.buttonQRCode.Click += new System.EventHandler(this.buttonQRCode_Click);
            // 
            // buttonEditWorker
            // 
            this.buttonEditWorker.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonEditWorker.BackColor = System.Drawing.Color.LightBlue;
            this.buttonEditWorker.FlatAppearance.BorderSize = 0;
            this.buttonEditWorker.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonEditWorker.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonEditWorker.Location = new System.Drawing.Point(196, 276);
            this.buttonEditWorker.Margin = new System.Windows.Forms.Padding(4);
            this.buttonEditWorker.Name = "buttonEditWorker";
            this.buttonEditWorker.Size = new System.Drawing.Size(292, 54);
            this.buttonEditWorker.TabIndex = 58;
            this.buttonEditWorker.Text = "Edit Worker";
            this.buttonEditWorker.UseVisualStyleBackColor = false;
            this.buttonEditWorker.Click += new System.EventHandler(this.buttonEditWorker_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // dateTimePickerSunday
            // 
            this.dateTimePickerSunday.CustomFormat = "hh:mm tt";
            this.dateTimePickerSunday.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePickerSunday.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePickerSunday.Location = new System.Drawing.Point(345, 303);
            this.dateTimePickerSunday.Margin = new System.Windows.Forms.Padding(4);
            this.dateTimePickerSunday.Name = "dateTimePickerSunday";
            this.dateTimePickerSunday.Size = new System.Drawing.Size(184, 30);
            this.dateTimePickerSunday.TabIndex = 74;
            // 
            // dateTimePickerSaturday
            // 
            this.dateTimePickerSaturday.CustomFormat = "hh:mm tt";
            this.dateTimePickerSaturday.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePickerSaturday.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePickerSaturday.Location = new System.Drawing.Point(345, 264);
            this.dateTimePickerSaturday.Margin = new System.Windows.Forms.Padding(4);
            this.dateTimePickerSaturday.Name = "dateTimePickerSaturday";
            this.dateTimePickerSaturday.Size = new System.Drawing.Size(184, 30);
            this.dateTimePickerSaturday.TabIndex = 73;
            // 
            // dateTimePickerFriday
            // 
            this.dateTimePickerFriday.CustomFormat = "hh:mm tt";
            this.dateTimePickerFriday.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePickerFriday.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePickerFriday.Location = new System.Drawing.Point(345, 224);
            this.dateTimePickerFriday.Margin = new System.Windows.Forms.Padding(4);
            this.dateTimePickerFriday.Name = "dateTimePickerFriday";
            this.dateTimePickerFriday.Size = new System.Drawing.Size(184, 30);
            this.dateTimePickerFriday.TabIndex = 72;
            // 
            // dateTimePickerThursday
            // 
            this.dateTimePickerThursday.CustomFormat = "hh:mm tt";
            this.dateTimePickerThursday.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePickerThursday.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePickerThursday.Location = new System.Drawing.Point(345, 185);
            this.dateTimePickerThursday.Margin = new System.Windows.Forms.Padding(4);
            this.dateTimePickerThursday.Name = "dateTimePickerThursday";
            this.dateTimePickerThursday.Size = new System.Drawing.Size(184, 30);
            this.dateTimePickerThursday.TabIndex = 71;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.checkBoxSun);
            this.panel1.Controls.Add(this.checkBoxSat);
            this.panel1.Controls.Add(this.checkBoxFri);
            this.panel1.Controls.Add(this.checkBoxThurs);
            this.panel1.Controls.Add(this.checkBoxWed);
            this.panel1.Controls.Add(this.checkBoxTue);
            this.panel1.Controls.Add(this.checkBoxMon);
            this.panel1.Controls.Add(this.dateTimePickerSunday);
            this.panel1.Controls.Add(this.dateTimePickerSaturday);
            this.panel1.Controls.Add(this.dateTimePickerFriday);
            this.panel1.Controls.Add(this.dateTimePickerThursday);
            this.panel1.Controls.Add(this.dateTimePickerWednesday);
            this.panel1.Controls.Add(this.dateTimePickerTuesday);
            this.panel1.Controls.Add(this.dateTimePickerMonday);
            this.panel1.Controls.Add(this.label51);
            this.panel1.Controls.Add(this.label52);
            this.panel1.Controls.Add(this.label54);
            this.panel1.Controls.Add(this.label47);
            this.panel1.Controls.Add(this.label48);
            this.panel1.Controls.Add(this.label49);
            this.panel1.Controls.Add(this.label50);
            this.panel1.Controls.Add(this.label46);
            this.panel1.Location = new System.Drawing.Point(4, 782);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(896, 374);
            this.panel1.TabIndex = 80;
            // 
            // checkBoxSun
            // 
            this.checkBoxSun.AutoSize = true;
            this.checkBoxSun.Location = new System.Drawing.Point(536, 316);
            this.checkBoxSun.Name = "checkBoxSun";
            this.checkBoxSun.Size = new System.Drawing.Size(18, 17);
            this.checkBoxSun.TabIndex = 110;
            this.checkBoxSun.UseVisualStyleBackColor = true;
            this.checkBoxSun.CheckedChanged += new System.EventHandler(this.checkBoxSun_CheckedChanged);
            // 
            // checkBoxSat
            // 
            this.checkBoxSat.AutoSize = true;
            this.checkBoxSat.Location = new System.Drawing.Point(536, 277);
            this.checkBoxSat.Name = "checkBoxSat";
            this.checkBoxSat.Size = new System.Drawing.Size(18, 17);
            this.checkBoxSat.TabIndex = 109;
            this.checkBoxSat.UseVisualStyleBackColor = true;
            this.checkBoxSat.CheckedChanged += new System.EventHandler(this.checkBoxSat_CheckedChanged);
            // 
            // checkBoxFri
            // 
            this.checkBoxFri.AutoSize = true;
            this.checkBoxFri.Location = new System.Drawing.Point(536, 237);
            this.checkBoxFri.Name = "checkBoxFri";
            this.checkBoxFri.Size = new System.Drawing.Size(18, 17);
            this.checkBoxFri.TabIndex = 108;
            this.checkBoxFri.UseVisualStyleBackColor = true;
            this.checkBoxFri.CheckedChanged += new System.EventHandler(this.checkBoxFri_CheckedChanged);
            // 
            // checkBoxThurs
            // 
            this.checkBoxThurs.AutoSize = true;
            this.checkBoxThurs.Location = new System.Drawing.Point(536, 198);
            this.checkBoxThurs.Name = "checkBoxThurs";
            this.checkBoxThurs.Size = new System.Drawing.Size(18, 17);
            this.checkBoxThurs.TabIndex = 107;
            this.checkBoxThurs.UseVisualStyleBackColor = true;
            this.checkBoxThurs.CheckedChanged += new System.EventHandler(this.checkBoxThurs_CheckedChanged);
            // 
            // checkBoxWed
            // 
            this.checkBoxWed.AutoSize = true;
            this.checkBoxWed.Location = new System.Drawing.Point(536, 159);
            this.checkBoxWed.Name = "checkBoxWed";
            this.checkBoxWed.Size = new System.Drawing.Size(18, 17);
            this.checkBoxWed.TabIndex = 106;
            this.checkBoxWed.UseVisualStyleBackColor = true;
            this.checkBoxWed.CheckedChanged += new System.EventHandler(this.checkBoxWed_CheckedChanged);
            // 
            // checkBoxTue
            // 
            this.checkBoxTue.AutoSize = true;
            this.checkBoxTue.Location = new System.Drawing.Point(536, 119);
            this.checkBoxTue.Name = "checkBoxTue";
            this.checkBoxTue.Size = new System.Drawing.Size(18, 17);
            this.checkBoxTue.TabIndex = 105;
            this.checkBoxTue.UseVisualStyleBackColor = true;
            this.checkBoxTue.CheckedChanged += new System.EventHandler(this.checkBoxTue_CheckedChanged);
            // 
            // checkBoxMon
            // 
            this.checkBoxMon.AutoSize = true;
            this.checkBoxMon.Location = new System.Drawing.Point(536, 80);
            this.checkBoxMon.Name = "checkBoxMon";
            this.checkBoxMon.Size = new System.Drawing.Size(18, 17);
            this.checkBoxMon.TabIndex = 104;
            this.checkBoxMon.UseVisualStyleBackColor = true;
            this.checkBoxMon.CheckedChanged += new System.EventHandler(this.checkBoxMon_CheckedChanged);
            // 
            // dateTimePickerWednesday
            // 
            this.dateTimePickerWednesday.CustomFormat = "hh:mm tt";
            this.dateTimePickerWednesday.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePickerWednesday.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePickerWednesday.Location = new System.Drawing.Point(345, 146);
            this.dateTimePickerWednesday.Margin = new System.Windows.Forms.Padding(4);
            this.dateTimePickerWednesday.Name = "dateTimePickerWednesday";
            this.dateTimePickerWednesday.Size = new System.Drawing.Size(184, 30);
            this.dateTimePickerWednesday.TabIndex = 70;
            // 
            // dateTimePickerTuesday
            // 
            this.dateTimePickerTuesday.CustomFormat = "hh:mm tt";
            this.dateTimePickerTuesday.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePickerTuesday.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePickerTuesday.Location = new System.Drawing.Point(345, 106);
            this.dateTimePickerTuesday.Margin = new System.Windows.Forms.Padding(4);
            this.dateTimePickerTuesday.Name = "dateTimePickerTuesday";
            this.dateTimePickerTuesday.Size = new System.Drawing.Size(184, 30);
            this.dateTimePickerTuesday.TabIndex = 69;
            // 
            // dateTimePickerMonday
            // 
            this.dateTimePickerMonday.CustomFormat = "hh:mm tt";
            this.dateTimePickerMonday.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePickerMonday.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePickerMonday.Location = new System.Drawing.Point(345, 67);
            this.dateTimePickerMonday.Margin = new System.Windows.Forms.Padding(4);
            this.dateTimePickerMonday.Name = "dateTimePickerMonday";
            this.dateTimePickerMonday.Size = new System.Drawing.Size(184, 30);
            this.dateTimePickerMonday.TabIndex = 68;
            this.dateTimePickerMonday.Value = new System.DateTime(2022, 10, 8, 11, 35, 0, 0);
            // 
            // label51
            // 
            this.label51.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label51.Location = new System.Drawing.Point(223, 303);
            this.label51.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(86, 25);
            this.label51.TabIndex = 67;
            this.label51.Text = "Sunday:";
            // 
            // label52
            // 
            this.label52.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label52.Location = new System.Drawing.Point(208, 266);
            this.label52.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(97, 25);
            this.label52.TabIndex = 66;
            this.label52.Text = "Saturday:";
            // 
            // label54
            // 
            this.label54.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label54.AutoSize = true;
            this.label54.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label54.Location = new System.Drawing.Point(237, 225);
            this.label54.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(72, 25);
            this.label54.TabIndex = 65;
            this.label54.Text = "Friday:";
            // 
            // label47
            // 
            this.label47.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.Location = new System.Drawing.Point(185, 147);
            this.label47.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(124, 25);
            this.label47.TabIndex = 63;
            this.label47.Text = "Wednesday:";
            // 
            // label48
            // 
            this.label48.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label48.Location = new System.Drawing.Point(215, 108);
            this.label48.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(95, 25);
            this.label48.TabIndex = 62;
            this.label48.Text = "Tuesday:";
            // 
            // label49
            // 
            this.label49.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label49.Location = new System.Drawing.Point(208, 187);
            this.label49.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(101, 25);
            this.label49.TabIndex = 64;
            this.label49.Text = "Thursday:";
            // 
            // label50
            // 
            this.label50.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label50.Location = new System.Drawing.Point(220, 68);
            this.label50.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(89, 25);
            this.label50.TabIndex = 61;
            this.label50.Text = "Monday:";
            // 
            // label46
            // 
            this.label46.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.Location = new System.Drawing.Point(129, 14);
            this.label46.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(164, 25);
            this.label46.TabIndex = 51;
            this.label46.Text = "Worker Schedule";
            // 
            // panelWorkingExperience
            // 
            this.panelWorkingExperience.Controls.Add(this.label16);
            this.panelWorkingExperience.Controls.Add(this.comboBoxYearHire);
            this.panelWorkingExperience.Controls.Add(this.label19);
            this.panelWorkingExperience.Controls.Add(this.textBoxPosition);
            this.panelWorkingExperience.Controls.Add(this.label18);
            this.panelWorkingExperience.Controls.Add(this.label20);
            this.panelWorkingExperience.Controls.Add(this.textBoxNameOfCompany);
            this.panelWorkingExperience.Controls.Add(this.textBoxReference);
            this.panelWorkingExperience.Controls.Add(this.label17);
            this.panelWorkingExperience.Location = new System.Drawing.Point(4, 477);
            this.panelWorkingExperience.Margin = new System.Windows.Forms.Padding(4);
            this.panelWorkingExperience.Name = "panelWorkingExperience";
            this.panelWorkingExperience.Size = new System.Drawing.Size(899, 297);
            this.panelWorkingExperience.TabIndex = 79;
            // 
            // label16
            // 
            this.label16.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(105, 30);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(188, 25);
            this.label16.TabIndex = 51;
            this.label16.Text = "Working Experience";
            // 
            // comboBoxYearHire
            // 
            this.comboBoxYearHire.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxYearHire.FormattingEnabled = true;
            this.comboBoxYearHire.Location = new System.Drawing.Point(343, 158);
            this.comboBoxYearHire.Margin = new System.Windows.Forms.Padding(4);
            this.comboBoxYearHire.Name = "comboBoxYearHire";
            this.comboBoxYearHire.Size = new System.Drawing.Size(293, 24);
            this.comboBoxYearHire.TabIndex = 78;
            // 
            // label19
            // 
            this.label19.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(209, 159);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(85, 20);
            this.label19.TabIndex = 58;
            this.label19.Text = "Year Hire:";
            // 
            // textBoxPosition
            // 
            this.textBoxPosition.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBoxPosition.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxPosition.Location = new System.Drawing.Point(343, 122);
            this.textBoxPosition.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxPosition.Name = "textBoxPosition";
            this.textBoxPosition.Size = new System.Drawing.Size(293, 26);
            this.textBoxPosition.TabIndex = 55;
            // 
            // label18
            // 
            this.label18.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(223, 126);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(74, 20);
            this.label18.TabIndex = 56;
            this.label18.Text = "Position:";
            // 
            // label20
            // 
            this.label20.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(201, 194);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(91, 20);
            this.label20.TabIndex = 60;
            this.label20.Text = "Reference:";
            // 
            // textBoxNameOfCompany
            // 
            this.textBoxNameOfCompany.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBoxNameOfCompany.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxNameOfCompany.Location = new System.Drawing.Point(343, 85);
            this.textBoxNameOfCompany.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxNameOfCompany.Name = "textBoxNameOfCompany";
            this.textBoxNameOfCompany.Size = new System.Drawing.Size(293, 26);
            this.textBoxNameOfCompany.TabIndex = 53;
            // 
            // textBoxReference
            // 
            this.textBoxReference.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBoxReference.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxReference.Location = new System.Drawing.Point(343, 191);
            this.textBoxReference.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxReference.Multiline = true;
            this.textBoxReference.Name = "textBoxReference";
            this.textBoxReference.Size = new System.Drawing.Size(293, 73);
            this.textBoxReference.TabIndex = 59;
            // 
            // label17
            // 
            this.label17.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(135, 89);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(152, 20);
            this.label17.TabIndex = 54;
            this.label17.Text = "Name of Company:";
            // 
            // flowLayoutPanel2
            // 
            this.flowLayoutPanel2.AutoScroll = true;
            this.flowLayoutPanel2.Controls.Add(this.panelBioData);
            this.flowLayoutPanel2.Controls.Add(this.panelWorkingExperience);
            this.flowLayoutPanel2.Controls.Add(this.panel1);
            this.flowLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.flowLayoutPanel2.Location = new System.Drawing.Point(0, 64);
            this.flowLayoutPanel2.Margin = new System.Windows.Forms.Padding(4);
            this.flowLayoutPanel2.Name = "flowLayoutPanel2";
            this.flowLayoutPanel2.Size = new System.Drawing.Size(936, 794);
            this.flowLayoutPanel2.TabIndex = 64;
            // 
            // panelBioData
            // 
            this.panelBioData.Controls.Add(this.label7);
            this.panelBioData.Controls.Add(this.maskedTextBoxSSS);
            this.panelBioData.Controls.Add(this.label24);
            this.panelBioData.Controls.Add(this.maskedTextBoxPhilHealth);
            this.panelBioData.Controls.Add(this.label25);
            this.panelBioData.Controls.Add(this.maskedTextBoxTinID);
            this.panelBioData.Controls.Add(this.textBoxReligion);
            this.panelBioData.Controls.Add(this.label53);
            this.panelBioData.Controls.Add(this.textBoxSuffix);
            this.panelBioData.Controls.Add(this.label12);
            this.panelBioData.Controls.Add(this.textBoxMName);
            this.panelBioData.Controls.Add(this.label21);
            this.panelBioData.Controls.Add(this.maskedTextBoxEmergencyContact);
            this.panelBioData.Controls.Add(this.maskedTextBoxContactNum);
            this.panelBioData.Controls.Add(this.textBoxHireDate);
            this.panelBioData.Controls.Add(this.label5);
            this.panelBioData.Controls.Add(this.buttonBack);
            this.panelBioData.Controls.Add(this.label15);
            this.panelBioData.Controls.Add(this.textBoxLName);
            this.panelBioData.Controls.Add(this.label14);
            this.panelBioData.Controls.Add(this.label4);
            this.panelBioData.Controls.Add(this.label13);
            this.panelBioData.Controls.Add(this.label6);
            this.panelBioData.Controls.Add(this.numericUpDownNumofChil);
            this.panelBioData.Controls.Add(this.label11);
            this.panelBioData.Controls.Add(this.textBoxFName);
            this.panelBioData.Controls.Add(this.label2);
            this.panelBioData.Controls.Add(this.dateTimePickerbirthdate);
            this.panelBioData.Controls.Add(this.comboBoxMartialStatus);
            this.panelBioData.Controls.Add(this.label3);
            this.panelBioData.Controls.Add(this.label10);
            this.panelBioData.Controls.Add(this.label8);
            this.panelBioData.Controls.Add(this.label9);
            this.panelBioData.Controls.Add(this.textBoxAddress);
            this.panelBioData.Controls.Add(this.textBoxWorkerID);
            this.panelBioData.Location = new System.Drawing.Point(4, 4);
            this.panelBioData.Margin = new System.Windows.Forms.Padding(4);
            this.panelBioData.Name = "panelBioData";
            this.panelBioData.Size = new System.Drawing.Size(899, 465);
            this.panelBioData.TabIndex = 0;
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(45, 428);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(240, 20);
            this.label7.TabIndex = 92;
            this.label7.Text = "Social Security System (CRN):";
            // 
            // maskedTextBoxSSS
            // 
            this.maskedTextBoxSSS.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maskedTextBoxSSS.Location = new System.Drawing.Point(340, 421);
            this.maskedTextBoxSSS.Mask = "0000-0000000-0";
            this.maskedTextBoxSSS.Name = "maskedTextBoxSSS";
            this.maskedTextBoxSSS.Size = new System.Drawing.Size(180, 30);
            this.maskedTextBoxSSS.TabIndex = 91;
            // 
            // label24
            // 
            this.label24.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(544, 392);
            this.label24.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(96, 20);
            this.label24.TabIndex = 90;
            this.label24.Text = "Phil Health:";
            // 
            // maskedTextBoxPhilHealth
            // 
            this.maskedTextBoxPhilHealth.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maskedTextBoxPhilHealth.Location = new System.Drawing.Point(694, 382);
            this.maskedTextBoxPhilHealth.Mask = "00-000000000-0";
            this.maskedTextBoxPhilHealth.Name = "maskedTextBoxPhilHealth";
            this.maskedTextBoxPhilHealth.Size = new System.Drawing.Size(169, 30);
            this.maskedTextBoxPhilHealth.TabIndex = 89;
            // 
            // label25
            // 
            this.label25.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(248, 392);
            this.label25.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(37, 20);
            this.label25.TabIndex = 88;
            this.label25.Text = "Tin:";
            // 
            // maskedTextBoxTinID
            // 
            this.maskedTextBoxTinID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maskedTextBoxTinID.Location = new System.Drawing.Point(340, 385);
            this.maskedTextBoxTinID.Mask = "000-000-000-000";
            this.maskedTextBoxTinID.Name = "maskedTextBoxTinID";
            this.maskedTextBoxTinID.Size = new System.Drawing.Size(180, 30);
            this.maskedTextBoxTinID.TabIndex = 87;
            // 
            // textBoxReligion
            // 
            this.textBoxReligion.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBoxReligion.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxReligion.Location = new System.Drawing.Point(599, 200);
            this.textBoxReligion.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxReligion.Name = "textBoxReligion";
            this.textBoxReligion.Size = new System.Drawing.Size(168, 26);
            this.textBoxReligion.TabIndex = 82;
            // 
            // label53
            // 
            this.label53.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label53.AutoSize = true;
            this.label53.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label53.Location = new System.Drawing.Point(832, 129);
            this.label53.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(42, 17);
            this.label53.TabIndex = 81;
            this.label53.Text = "Suffix";
            // 
            // textBoxSuffix
            // 
            this.textBoxSuffix.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBoxSuffix.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxSuffix.Location = new System.Drawing.Point(810, 94);
            this.textBoxSuffix.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSuffix.Name = "textBoxSuffix";
            this.textBoxSuffix.Size = new System.Drawing.Size(81, 26);
            this.textBoxSuffix.TabIndex = 80;
            // 
            // label12
            // 
            this.label12.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(720, 129);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(56, 17);
            this.label12.TabIndex = 79;
            this.label12.Text = "MName";
            // 
            // textBoxMName
            // 
            this.textBoxMName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBoxMName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxMName.Location = new System.Drawing.Point(694, 94);
            this.textBoxMName.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxMName.Name = "textBoxMName";
            this.textBoxMName.Size = new System.Drawing.Size(107, 26);
            this.textBoxMName.TabIndex = 78;
            // 
            // label21
            // 
            this.label21.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(144, 6);
            this.label21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(147, 25);
            this.label21.TabIndex = 61;
            this.label21.Text = "Worker Biodata";
            // 
            // maskedTextBoxEmergencyContact
            // 
            this.maskedTextBoxEmergencyContact.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.maskedTextBoxEmergencyContact.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maskedTextBoxEmergencyContact.Location = new System.Drawing.Point(340, 349);
            this.maskedTextBoxEmergencyContact.Margin = new System.Windows.Forms.Padding(4);
            this.maskedTextBoxEmergencyContact.Mask = "(999) 000-0000";
            this.maskedTextBoxEmergencyContact.Name = "maskedTextBoxEmergencyContact";
            this.maskedTextBoxEmergencyContact.Size = new System.Drawing.Size(128, 26);
            this.maskedTextBoxEmergencyContact.TabIndex = 59;
            // 
            // maskedTextBoxContactNum
            // 
            this.maskedTextBoxContactNum.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.maskedTextBoxContactNum.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maskedTextBoxContactNum.Location = new System.Drawing.Point(694, 311);
            this.maskedTextBoxContactNum.Margin = new System.Windows.Forms.Padding(4);
            this.maskedTextBoxContactNum.Mask = "(999) 000-0000";
            this.maskedTextBoxContactNum.Name = "maskedTextBoxContactNum";
            this.maskedTextBoxContactNum.Size = new System.Drawing.Size(128, 26);
            this.maskedTextBoxContactNum.TabIndex = 58;
            // 
            // textBoxHireDate
            // 
            this.textBoxHireDate.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBoxHireDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxHireDate.Location = new System.Drawing.Point(693, 349);
            this.textBoxHireDate.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxHireDate.Name = "textBoxHireDate";
            this.textBoxHireDate.ReadOnly = true;
            this.textBoxHireDate.Size = new System.Drawing.Size(128, 26);
            this.textBoxHireDate.TabIndex = 55;
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(546, 352);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(87, 20);
            this.label5.TabIndex = 28;
            this.label5.Text = "Hire Date:";
            // 
            // buttonBack
            // 
            this.buttonBack.BackColor = System.Drawing.Color.LightBlue;
            this.buttonBack.FlatAppearance.BorderSize = 0;
            this.buttonBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonBack.Location = new System.Drawing.Point(-228, 620);
            this.buttonBack.Margin = new System.Windows.Forms.Padding(4);
            this.buttonBack.Name = "buttonBack";
            this.buttonBack.Size = new System.Drawing.Size(184, 52);
            this.buttonBack.TabIndex = 14;
            this.buttonBack.Text = "Back";
            this.buttonBack.UseVisualStyleBackColor = false;
            // 
            // label15
            // 
            this.label15.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(122, 352);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(161, 20);
            this.label15.TabIndex = 53;
            this.label15.Text = "Emergency Contact:";
            // 
            // textBoxLName
            // 
            this.textBoxLName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBoxLName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxLName.Location = new System.Drawing.Point(340, 94);
            this.textBoxLName.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxLName.Name = "textBoxLName";
            this.textBoxLName.Size = new System.Drawing.Size(168, 26);
            this.textBoxLName.TabIndex = 22;
            // 
            // label14
            // 
            this.label14.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(170, 98);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(117, 20);
            this.label14.TabIndex = 52;
            this.label14.Text = "Worker Name:";
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(394, 129);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 17);
            this.label4.TabIndex = 24;
            this.label4.Text = "LName";
            // 
            // label13
            // 
            this.label13.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(202, 165);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(91, 20);
            this.label13.TabIndex = 51;
            this.label13.Text = "Birth Date:";
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(29, 313);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(254, 20);
            this.label6.TabIndex = 29;
            this.label6.Text = "Number of Children/Dependents:";
            // 
            // numericUpDownNumofChil
            // 
            this.numericUpDownNumofChil.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.numericUpDownNumofChil.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numericUpDownNumofChil.Location = new System.Drawing.Point(340, 311);
            this.numericUpDownNumofChil.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDownNumofChil.Name = "numericUpDownNumofChil";
            this.numericUpDownNumofChil.Size = new System.Drawing.Size(129, 26);
            this.numericUpDownNumofChil.TabIndex = 30;
            // 
            // label11
            // 
            this.label11.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(569, 129);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(53, 17);
            this.label11.TabIndex = 48;
            this.label11.Text = "FName";
            // 
            // textBoxFName
            // 
            this.textBoxFName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBoxFName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxFName.Location = new System.Drawing.Point(517, 94);
            this.textBoxFName.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxFName.Name = "textBoxFName";
            this.textBoxFName.Size = new System.Drawing.Size(168, 26);
            this.textBoxFName.TabIndex = 47;
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(172, 204);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(118, 20);
            this.label2.TabIndex = 35;
            this.label2.Text = "Martial Status:";
            // 
            // dateTimePickerbirthdate
            // 
            this.dateTimePickerbirthdate.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dateTimePickerbirthdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePickerbirthdate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePickerbirthdate.Location = new System.Drawing.Point(340, 158);
            this.dateTimePickerbirthdate.Margin = new System.Windows.Forms.Padding(4);
            this.dateTimePickerbirthdate.Name = "dateTimePickerbirthdate";
            this.dateTimePickerbirthdate.Size = new System.Drawing.Size(293, 26);
            this.dateTimePickerbirthdate.TabIndex = 46;
            // 
            // comboBoxMartialStatus
            // 
            this.comboBoxMartialStatus.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBoxMartialStatus.AutoCompleteCustomSource.AddRange(new string[] {
            "Single",
            "Married",
            "Separated",
            "Divorced",
            "Windowed"});
            this.comboBoxMartialStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxMartialStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxMartialStatus.FormattingEnabled = true;
            this.comboBoxMartialStatus.Items.AddRange(new object[] {
            "Single",
            "Married",
            "Widowed",
            "Divorced",
            "Separated"});
            this.comboBoxMartialStatus.Location = new System.Drawing.Point(340, 200);
            this.comboBoxMartialStatus.Margin = new System.Windows.Forms.Padding(4);
            this.comboBoxMartialStatus.Name = "comboBoxMartialStatus";
            this.comboBoxMartialStatus.Size = new System.Drawing.Size(168, 28);
            this.comboBoxMartialStatus.TabIndex = 36;
            this.comboBoxMartialStatus.SelectedIndexChanged += new System.EventHandler(this.comboBoxMartialStatus_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(517, 204);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 20);
            this.label3.TabIndex = 37;
            this.label3.Text = "Religion:";
            // 
            // label10
            // 
            this.label10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(500, 314);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(136, 20);
            this.label10.TabIndex = 43;
            this.label10.Text = "Contact Number:";
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(217, 247);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(76, 20);
            this.label8.TabIndex = 39;
            this.label8.Text = "Address:";
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(202, 58);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(90, 20);
            this.label9.TabIndex = 42;
            this.label9.Text = "Worker ID:";
            // 
            // textBoxAddress
            // 
            this.textBoxAddress.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBoxAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxAddress.Location = new System.Drawing.Point(340, 243);
            this.textBoxAddress.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxAddress.Multiline = true;
            this.textBoxAddress.Name = "textBoxAddress";
            this.textBoxAddress.Size = new System.Drawing.Size(523, 56);
            this.textBoxAddress.TabIndex = 40;
            // 
            // textBoxWorkerID
            // 
            this.textBoxWorkerID.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBoxWorkerID.Enabled = false;
            this.textBoxWorkerID.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxWorkerID.Location = new System.Drawing.Point(340, 54);
            this.textBoxWorkerID.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxWorkerID.Name = "textBoxWorkerID";
            this.textBoxWorkerID.ReadOnly = true;
            this.textBoxWorkerID.Size = new System.Drawing.Size(293, 26);
            this.textBoxWorkerID.TabIndex = 41;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Blue;
            this.panel3.Controls.Add(this.label1);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Margin = new System.Windows.Forms.Padding(4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1469, 64);
            this.panel3.TabIndex = 63;
            // 
            // buttonAddWorkers
            // 
            this.buttonAddWorkers.BackColor = System.Drawing.Color.LightBlue;
            this.buttonAddWorkers.FlatAppearance.BorderSize = 0;
            this.buttonAddWorkers.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAddWorkers.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAddWorkers.Location = new System.Drawing.Point(1424, 804);
            this.buttonAddWorkers.Margin = new System.Windows.Forms.Padding(4);
            this.buttonAddWorkers.Name = "buttonAddWorkers";
            this.buttonAddWorkers.Size = new System.Drawing.Size(264, 68);
            this.buttonAddWorkers.TabIndex = 62;
            this.buttonAddWorkers.Text = "Add";
            this.buttonAddWorkers.UseVisualStyleBackColor = false;
            // 
            // buttonGenerateID
            // 
            this.buttonGenerateID.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonGenerateID.BackColor = System.Drawing.Color.LightBlue;
            this.buttonGenerateID.FlatAppearance.BorderSize = 0;
            this.buttonGenerateID.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonGenerateID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonGenerateID.Location = new System.Drawing.Point(196, 214);
            this.buttonGenerateID.Margin = new System.Windows.Forms.Padding(4);
            this.buttonGenerateID.Name = "buttonGenerateID";
            this.buttonGenerateID.Size = new System.Drawing.Size(292, 54);
            this.buttonGenerateID.TabIndex = 60;
            this.buttonGenerateID.Text = "Generate ID";
            this.buttonGenerateID.UseVisualStyleBackColor = false;
            this.buttonGenerateID.Click += new System.EventHandler(this.buttonGenerateID_Click);
            // 
            // FormWorkersEdit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1469, 858);
            this.Controls.Add(this.flowLayoutPanel3);
            this.Controls.Add(this.flowLayoutPanel2);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.buttonAddWorkers);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "FormWorkersEdit";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.FormWorkersEdit_Load);
            this.panelEducationalQualification.ResumeLayout(false);
            this.panelEducationalQualification.PerformLayout();
            this.flowLayoutPanel1.ResumeLayout(false);
            this.flowLayoutPanel3.ResumeLayout(false);
            this.panelImage.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxQRCode)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel6.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panelWorkingExperience.ResumeLayout(false);
            this.panelWorkingExperience.PerformLayout();
            this.flowLayoutPanel2.ResumeLayout(false);
            this.panelBioData.ResumeLayout(false);
            this.panelBioData.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownNumofChil)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panelEducationalQualification;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox textBoxEducation;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel3;
        private System.Windows.Forms.Panel panelImage;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button buttonFileUpload;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Button buttonEditWorker;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.DateTimePicker dateTimePickerSunday;
        private System.Windows.Forms.DateTimePicker dateTimePickerSaturday;
        private System.Windows.Forms.DateTimePicker dateTimePickerFriday;
        private System.Windows.Forms.DateTimePicker dateTimePickerThursday;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DateTimePicker dateTimePickerWednesday;
        private System.Windows.Forms.DateTimePicker dateTimePickerTuesday;
        private System.Windows.Forms.DateTimePicker dateTimePickerMonday;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Panel panelWorkingExperience;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.ComboBox comboBoxYearHire;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox textBoxPosition;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox textBoxNameOfCompany;
        private System.Windows.Forms.TextBox textBoxReference;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel2;
        private System.Windows.Forms.Panel panelBioData;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.MaskedTextBox maskedTextBoxEmergencyContact;
        private System.Windows.Forms.MaskedTextBox maskedTextBoxContactNum;
        private System.Windows.Forms.TextBox textBoxHireDate;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button buttonBack;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox textBoxLName;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.NumericUpDown numericUpDownNumofChil;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBoxFName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker dateTimePickerbirthdate;
        private System.Windows.Forms.ComboBox comboBoxMartialStatus;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBoxAddress;
        private System.Windows.Forms.TextBox textBoxWorkerID;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button buttonAddWorkers;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBoxMName;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.TextBox textBoxSuffix;
        private System.Windows.Forms.Button buttonQRCode;
        private System.Windows.Forms.TextBox textBoxReligion;
        private System.Windows.Forms.Button buttonTakeAPicture;
        private System.Windows.Forms.CheckBox checkBoxSun;
        private System.Windows.Forms.CheckBox checkBoxSat;
        private System.Windows.Forms.CheckBox checkBoxFri;
        private System.Windows.Forms.CheckBox checkBoxThurs;
        private System.Windows.Forms.CheckBox checkBoxWed;
        private System.Windows.Forms.CheckBox checkBoxTue;
        private System.Windows.Forms.CheckBox checkBoxMon;
        private System.Windows.Forms.PictureBox pictureBoxQRCode;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.MaskedTextBox maskedTextBoxSSS;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.MaskedTextBox maskedTextBoxPhilHealth;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.MaskedTextBox maskedTextBoxTinID;
        private System.Windows.Forms.Button buttonGenerateID;
    }
}