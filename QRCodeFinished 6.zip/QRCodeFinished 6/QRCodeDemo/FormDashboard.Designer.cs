﻿namespace QRCodeDemo
{
    partial class FormDashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.progressBarPresent = new System.Windows.Forms.ProgressBar();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.progressBarAbsent = new System.Windows.Forms.ProgressBar();
            this.label5 = new System.Windows.Forms.Label();
            this.progressBarLate = new System.Windows.Forms.ProgressBar();
            this.button1 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.progressBarOnTime = new System.Windows.Forms.ProgressBar();
            this.label6 = new System.Windows.Forms.Label();
            this.progressBarHalfDay = new System.Windows.Forms.ProgressBar();
            this.button3 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.progressBarEmergencyLeave = new System.Windows.Forms.ProgressBar();
            this.label1 = new System.Windows.Forms.Label();
            this.button6 = new System.Windows.Forms.Button();
            this.listBoxAlreadyLimitAbsent = new System.Windows.Forms.ListBox();
            this.listBoxAlreadyLimitLate = new System.Windows.Forms.ListBox();
            this.listBoxAlreadyLimitLeave = new System.Windows.Forms.ListBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.jbtPanelGIF1 = new QRCodeDemo.JBTControls.JBTPanelGIF();
            this.label10 = new System.Windows.Forms.Label();
            this.progressBarOverTime = new System.Windows.Forms.ProgressBar();
            this.button7 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // progressBarPresent
            // 
            this.progressBarPresent.Location = new System.Drawing.Point(62, 171);
            this.progressBarPresent.Margin = new System.Windows.Forms.Padding(4);
            this.progressBarPresent.Name = "progressBarPresent";
            this.progressBarPresent.Size = new System.Drawing.Size(232, 12);
            this.progressBarPresent.TabIndex = 35;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Blue;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(61, 58);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(108, 31);
            this.label2.TabIndex = 30;
            this.label2.Text = "Present";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Green;
            this.label4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(637, 58);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(99, 31);
            this.label4.TabIndex = 32;
            this.label4.Text = "Absent";
            // 
            // progressBarAbsent
            // 
            this.progressBarAbsent.Location = new System.Drawing.Point(639, 171);
            this.progressBarAbsent.Margin = new System.Windows.Forms.Padding(4);
            this.progressBarAbsent.Name = "progressBarAbsent";
            this.progressBarAbsent.Size = new System.Drawing.Size(232, 12);
            this.progressBarAbsent.TabIndex = 39;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Orange;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(61, 229);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(119, 31);
            this.label5.TabIndex = 33;
            this.label5.Text = "Half Day";
            // 
            // progressBarLate
            // 
            this.progressBarLate.Location = new System.Drawing.Point(349, 346);
            this.progressBarLate.Margin = new System.Windows.Forms.Padding(4);
            this.progressBarLate.Name = "progressBarLate";
            this.progressBarLate.Size = new System.Drawing.Size(232, 12);
            this.progressBarLate.TabIndex = 38;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Blue;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Location = new System.Drawing.Point(42, 41);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(280, 164);
            this.button1.TabIndex = 25;
            this.button1.UseVisualStyleBackColor = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.DarkViolet;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(349, 58);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(117, 31);
            this.label3.TabIndex = 31;
            this.label3.Text = "On Time";
            // 
            // progressBarOnTime
            // 
            this.progressBarOnTime.Location = new System.Drawing.Point(349, 171);
            this.progressBarOnTime.Margin = new System.Windows.Forms.Padding(4);
            this.progressBarOnTime.Name = "progressBarOnTime";
            this.progressBarOnTime.Size = new System.Drawing.Size(232, 12);
            this.progressBarOnTime.TabIndex = 37;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.DarkBlue;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(347, 228);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(67, 31);
            this.label6.TabIndex = 34;
            this.label6.Text = "Late";
            // 
            // progressBarHalfDay
            // 
            this.progressBarHalfDay.Location = new System.Drawing.Point(62, 346);
            this.progressBarHalfDay.Margin = new System.Windows.Forms.Padding(4);
            this.progressBarHalfDay.Name = "progressBarHalfDay";
            this.progressBarHalfDay.Size = new System.Drawing.Size(232, 12);
            this.progressBarHalfDay.TabIndex = 36;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.DarkViolet;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Location = new System.Drawing.Point(330, 41);
            this.button3.Margin = new System.Windows.Forms.Padding(4);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(280, 164);
            this.button3.TabIndex = 28;
            this.button3.UseVisualStyleBackColor = false;
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.Green;
            this.button5.FlatAppearance.BorderSize = 0;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Location = new System.Drawing.Point(618, 41);
            this.button5.Margin = new System.Windows.Forms.Padding(4);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(280, 164);
            this.button5.TabIndex = 29;
            this.button5.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Orange;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Location = new System.Drawing.Point(42, 212);
            this.button2.Margin = new System.Windows.Forms.Padding(4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(280, 164);
            this.button2.TabIndex = 26;
            this.button2.UseVisualStyleBackColor = false;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.DarkBlue;
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Location = new System.Drawing.Point(330, 212);
            this.button4.Margin = new System.Windows.Forms.Padding(4);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(280, 164);
            this.button4.TabIndex = 27;
            this.button4.UseVisualStyleBackColor = false;
            // 
            // progressBarEmergencyLeave
            // 
            this.progressBarEmergencyLeave.Location = new System.Drawing.Point(637, 346);
            this.progressBarEmergencyLeave.Margin = new System.Windows.Forms.Padding(4);
            this.progressBarEmergencyLeave.Name = "progressBarEmergencyLeave";
            this.progressBarEmergencyLeave.Size = new System.Drawing.Size(232, 12);
            this.progressBarEmergencyLeave.TabIndex = 42;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Red;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(635, 228);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(232, 31);
            this.label1.TabIndex = 41;
            this.label1.Text = "Emergency Leave";
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.Red;
            this.button6.FlatAppearance.BorderSize = 0;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Location = new System.Drawing.Point(618, 212);
            this.button6.Margin = new System.Windows.Forms.Padding(4);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(280, 164);
            this.button6.TabIndex = 40;
            this.button6.UseVisualStyleBackColor = false;
            // 
            // listBoxAlreadyLimitAbsent
            // 
            this.listBoxAlreadyLimitAbsent.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.listBoxAlreadyLimitAbsent.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBoxAlreadyLimitAbsent.FormattingEnabled = true;
            this.listBoxAlreadyLimitAbsent.ItemHeight = 20;
            this.listBoxAlreadyLimitAbsent.Location = new System.Drawing.Point(42, 453);
            this.listBoxAlreadyLimitAbsent.Name = "listBoxAlreadyLimitAbsent";
            this.listBoxAlreadyLimitAbsent.Size = new System.Drawing.Size(280, 184);
            this.listBoxAlreadyLimitAbsent.TabIndex = 44;
            this.listBoxAlreadyLimitAbsent.KeyDown += new System.Windows.Forms.KeyEventHandler(this.listBoxAlreadyLimitAbsent_KeyDown);
            // 
            // listBoxAlreadyLimitLate
            // 
            this.listBoxAlreadyLimitLate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.listBoxAlreadyLimitLate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBoxAlreadyLimitLate.FormattingEnabled = true;
            this.listBoxAlreadyLimitLate.ItemHeight = 20;
            this.listBoxAlreadyLimitLate.Location = new System.Drawing.Point(330, 453);
            this.listBoxAlreadyLimitLate.Name = "listBoxAlreadyLimitLate";
            this.listBoxAlreadyLimitLate.Size = new System.Drawing.Size(280, 184);
            this.listBoxAlreadyLimitLate.TabIndex = 45;
            // 
            // listBoxAlreadyLimitLeave
            // 
            this.listBoxAlreadyLimitLeave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.listBoxAlreadyLimitLeave.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBoxAlreadyLimitLeave.FormattingEnabled = true;
            this.listBoxAlreadyLimitLeave.ItemHeight = 20;
            this.listBoxAlreadyLimitLeave.Location = new System.Drawing.Point(616, 453);
            this.listBoxAlreadyLimitLeave.Name = "listBoxAlreadyLimitLeave";
            this.listBoxAlreadyLimitLeave.Size = new System.Drawing.Size(280, 184);
            this.listBoxAlreadyLimitLeave.TabIndex = 46;
            // 
            // label7
            // 
            this.label7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Green;
            this.label7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(61, 410);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(137, 31);
            this.label7.TabIndex = 50;
            this.label7.Text = "3+ Absent";
            // 
            // label8
            // 
            this.label8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.DarkBlue;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(349, 410);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(105, 31);
            this.label8.TabIndex = 51;
            this.label8.Text = "3+ Late";
            // 
            // label9
            // 
            this.label9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Red;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(631, 410);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(110, 31);
            this.label9.TabIndex = 52;
            this.label9.Text = "3 Leave";
            // 
            // jbtPanelGIF1
            // 
            this.jbtPanelGIF1.Angle = 287F;
            this.jbtPanelGIF1.BorderRadius = 1;
            this.jbtPanelGIF1.Color0 = System.Drawing.Color.Blue;
            this.jbtPanelGIF1.Color1 = System.Drawing.Color.Pink;
            this.jbtPanelGIF1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.jbtPanelGIF1.ForeColor = System.Drawing.Color.White;
            this.jbtPanelGIF1.Location = new System.Drawing.Point(0, 0);
            this.jbtPanelGIF1.Name = "jbtPanelGIF1";
            this.jbtPanelGIF1.Size = new System.Drawing.Size(1226, 673);
            this.jbtPanelGIF1.TabIndex = 43;
            this.jbtPanelGIF1.Click += new System.EventHandler(this.jbtPanelGIF1_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.HotPink;
            this.label10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(925, 58);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(140, 31);
            this.label10.TabIndex = 54;
            this.label10.Text = "Over Time";
            // 
            // progressBarOverTime
            // 
            this.progressBarOverTime.Location = new System.Drawing.Point(927, 171);
            this.progressBarOverTime.Margin = new System.Windows.Forms.Padding(4);
            this.progressBarOverTime.Name = "progressBarOverTime";
            this.progressBarOverTime.Size = new System.Drawing.Size(232, 12);
            this.progressBarOverTime.TabIndex = 55;
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.HotPink;
            this.button7.FlatAppearance.BorderSize = 0;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Location = new System.Drawing.Point(906, 41);
            this.button7.Margin = new System.Windows.Forms.Padding(4);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(280, 164);
            this.button7.TabIndex = 53;
            this.button7.UseVisualStyleBackColor = false;
            // 
            // FormDashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1226, 673);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.progressBarOverTime);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.listBoxAlreadyLimitLeave);
            this.Controls.Add(this.listBoxAlreadyLimitLate);
            this.Controls.Add(this.listBoxAlreadyLimitAbsent);
            this.Controls.Add(this.progressBarEmergencyLeave);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.progressBarPresent);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.progressBarAbsent);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.progressBarLate);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.progressBarOnTime);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.progressBarHalfDay);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.jbtPanelGIF1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "FormDashboard";
            this.Load += new System.EventHandler(this.FormMain_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ProgressBar progressBarPresent;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ProgressBar progressBarAbsent;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ProgressBar progressBarLate;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ProgressBar progressBarOnTime;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ProgressBar progressBarHalfDay;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.ProgressBar progressBarEmergencyLeave;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button6;
        private JBTControls.JBTPanelGIF jbtPanelGIF1;
        private System.Windows.Forms.ListBox listBoxAlreadyLimitAbsent;
        private System.Windows.Forms.ListBox listBoxAlreadyLimitLate;
        private System.Windows.Forms.ListBox listBoxAlreadyLimitLeave;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ProgressBar progressBarOverTime;
        private System.Windows.Forms.Button button7;
    }
}