﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace QRCodeDemo
{
    public partial class FormLeaveAdd : Form
    {
        SqlConnection tublecon = new SqlConnection(Class.tublecon);
        string StrReasonLeave = "",date;
        bool accept = true;

        public FormLeaveAdd()
        {
            InitializeComponent();
        }

        private void FormHolidayAdd_Load(object sender, EventArgs e)
        {
            CountLeaveLoad();
            AlreadyLeaveOnLeaveRequested();
            AlreadyPresent();
            Loaddata();
            WorkerSchedule();
        }
        void CountLeaveLoad()
        {
            SqlCommand cmd = new SqlCommand("SELECT * FROM  tblWorkersAttendance WHERE [Date] >= @DateFrom AND [Date] <= @DateTo AND [Status] = @Status AND WorkersID = @WorkersID", tublecon);
            cmd.Parameters.AddWithValue("@DateFrom", Convert.ToDateTime("1/" + DateTime.Now.Month + "/" + DateTime.Now.Year));
            cmd.Parameters.AddWithValue("@DateTo", Convert.ToDateTime(DateTime.DaysInMonth(DateTime.Now.Year, DateTime.Now.Month) + "/" + DateTime.Now.Month + "/" + DateTime.Now.Year));
            cmd.Parameters.AddWithValue("@Status", "Leave");
            cmd.Parameters.AddWithValue("@WorkersID", Class.WorkersID);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count >= 3)
            {
                this.Close();
                MessageBox.Show("This Month Leave is already at limit");
            }
        }
        int message = 0;
        void CountLeave()
        {
            SqlCommand cmd = new SqlCommand("SELECT * FROM  tblWorkersAttendance WHERE [Date] >= @DateFrom AND [Date] <= @DateTo AND [Status] = @Status AND WorkersID = @WorkersID", tublecon);
            cmd.Parameters.AddWithValue("@DateFrom", Convert.ToDateTime("1/" + DateTime.Now.Month + "/" + DateTime.Now.Year));
            cmd.Parameters.AddWithValue("@DateTo", Convert.ToDateTime(DateTime.DaysInMonth(DateTime.Now.Year, DateTime.Now.Month) + "/" + DateTime.Now.Month + "/" + DateTime.Now.Year));
            cmd.Parameters.AddWithValue("@Status", "Leave");
            cmd.Parameters.AddWithValue("@WorkersID", Class.WorkersID);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            
            if (dt.Rows.Count >= 3)
            {
                accept = false;
                message++;
            }
            if (message.Equals(1))
            { MessageBox.Show("This Month Leave is already at limit this will stop at " + date); }
        }

        void AlreadyLeaveOnLeaveRequested()
        {
            SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM tblLeaveRequested WHERE WorkersID = @WorkersID AND [To] >= @Date AND [From] <= @Date", tublecon);
            cmd.Parameters.AddWithValue("@WorkersID", Class.WorkersID);
            cmd.Parameters.AddWithValue("@Date", Convert.ToDateTime(DateTime.Now.ToShortDateString()));
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            if (Convert.ToInt16(dt.Rows[0][0]) > 0)
            {
                MessageBox.Show("Already Leave");
                this.Close();
            }
        }

        void AlreadyPresent()
        {
            SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM tblWorkersAttendance WHERE WorkersID = @WorkersID AND [Date] = @Date AND NOT Status = @Leave AND NOT Status = @Absent", tublecon);
            cmd.Parameters.AddWithValue("@WorkersID", Class.WorkersID);
            cmd.Parameters.AddWithValue("@Date", Convert.ToDateTime(DateTime.Now.ToShortDateString()));
            cmd.Parameters.AddWithValue("@Leave","Leave");
            cmd.Parameters.AddWithValue("@Absent", "Absent");
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            if (Convert.ToInt16(dt.Rows[0][0]) > 0)
            {
                MessageBox.Show("Already Present");
                this.Close();
            }
        }

        void RemoveAbsent()
        {
            SqlCommand cmd = new SqlCommand("DELETE FROM tblWorkersAttendance WHERE WorkersID = @WorkersID AND [Date] = @Date AND Status = @Absent", tublecon);
            cmd.Parameters.AddWithValue("@WorkersID", Class.WorkersID);
            cmd.Parameters.AddWithValue("@Date", Convert.ToDateTime(DateTime.Now.ToShortDateString()));
            cmd.Parameters.AddWithValue("@Absent", "Absent");
            tublecon.Open();
            cmd.ExecuteNonQuery();
            tublecon.Close();
        }

        void Loaddata()
        {
            SqlCommand cmd = new SqlCommand("SELECT * FROM tblWorkersBioData WHERE WorkersID = @WorkersID", tublecon);
            cmd.Parameters.AddWithValue("@WorkersID", Class.WorkersID);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            labelWorkerID.Text = Class.WorkersID;
            labelWorkerName.Text = dt.Rows[0][2] + ", " + dt.Rows[0][1] + " " + dt.Rows[0][3] + " " + dt.Rows[0][4];
            labelDay.Text = DateTime.Now.DayOfWeek.ToString();
            labelDate.Text = DateTime.Now.ToShortDateString();
            MemoryStream mem = new MemoryStream((Byte[])(dt.Rows[0]["Picture"]));
            pictureBox1.Image = Image.FromStream(mem);
            labelReason.Visible = false;
            textBoxReason.Visible = false;
        }

        void ReasonLeave()
        {
            if (Convert.ToString(comboBoxReasonLeave.SelectedItem).Equals("Family and Medical For"))
            {
                labelReason.Visible = true;
                labelReason.Text = "Family and Medical For";
                textBoxReason.Visible = true;
            }
            else if (Convert.ToString(comboBoxReasonLeave.SelectedItem).Equals("Funeral - Relatioship"))
            {
                labelReason.Visible = true;
                labelReason.Text = "Funeral - Relatioship";
                textBoxReason.Visible = true;
            }
            else if (Convert.ToString(comboBoxReasonLeave.SelectedItem).Equals("Other"))
            {
                labelReason.Visible = true;
                labelReason.Text = "Other";
                textBoxReason.Visible = true;
            }
            else
            {
                labelReason.Visible = false;
                labelReason.Text = "";
                textBoxReason.Visible = false;
                textBoxReason.Text = "";
            }
        }

        void ReasonLeaveInsert()
        {
            if (Convert.ToString(comboBoxReasonLeave.SelectedItem).Equals("Family and Medical For"))
            {
                StrReasonLeave = "Family and Medical For - " + textBoxReason.Text;
            }
            else if (Convert.ToString(comboBoxReasonLeave.SelectedItem).Equals("Funeral - Relatioship"))
            {
                StrReasonLeave = "Funeral - Relatioship - " + textBoxReason.Text;
            }
            else if (Convert.ToString(comboBoxReasonLeave.SelectedItem).Equals("Other"))
            {
                StrReasonLeave = "Other - " + textBoxReason.Text;
            }
            else
            {
                StrReasonLeave = Convert.ToString(comboBoxReasonLeave.SelectedItem);
            }
        }

        void WorkerSchedule()
        {
            string Date = "", ColDate = "", DateDayNight = "";
            SqlCommand cmd = new SqlCommand("SELECT * FROM tblWorkersSchedule WHERE WorkersID = @WorkersID", tublecon);
            cmd.Parameters.AddWithValue("@WorkersID", labelWorkerID.Text);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            if (Convert.ToString(DateTime.Now.DayOfWeek).Equals("Monday")) { Date = "Monday"; ColDate = "MonSched"; DateDayNight = "MonDayNight"; }
            else if (Convert.ToString(DateTime.Now.DayOfWeek).Equals("Tuesday")) { Date = "Tuesday"; ColDate = "TueSched"; DateDayNight = "TueDayNight"; }
            else if (Convert.ToString(DateTime.Now.DayOfWeek).Equals("Wednesday")) { Date = "Wednesday"; ColDate = "WedSched"; DateDayNight = "WedDayNight"; }
            else if (Convert.ToString(DateTime.Now.DayOfWeek).Equals("Thursday")) { Date = "Thursday"; ColDate = "ThuSched"; DateDayNight = "ThuDayNight"; }
            else if (Convert.ToString(DateTime.Now.DayOfWeek).Equals("Friday")) { Date = "Friday"; ColDate = "FriSched"; DateDayNight = "FriDayNight"; }
            else if (Convert.ToString(DateTime.Now.DayOfWeek).Equals("Saturday")) { Date = "Saturday"; ColDate = "SatSched"; DateDayNight = "SatDayNight"; }
            else if (Convert.ToString(DateTime.Now.DayOfWeek).Equals("Sunday")) { Date = "Sunday"; ColDate = "SunSched"; DateDayNight = "SunDayNight"; }

            labelSchedule.Text = dt.Rows[0][ColDate] + " " + dt.Rows[0][DateDayNight];
        }

        void AddLeave()
        {
            string[] FromTime = new string[1];
            string[] ToTime = new string[1];

            FromTime = dateTimePickerTimeFrom.Text.Split(' ');
            ToTime = dateTimePickerTimeTo.Text.Split(' ');
            SqlCommand tublecmd = new SqlCommand("INSERT INTO [dbo].[tblLeaveRequested] ([WorkersID],[From],[To],[FromTime],[ToTime],[Date],[FromDayNight],[ToDayNight]) VALUES (@WorkersID,@From,@To,@FromTime,@ToTime,@Date,@FromDayNight,@ToDayNight)", tublecon);
            tublecmd.Parameters.AddWithValue("@WorkersID", labelWorkerID.Text);
            tublecmd.Parameters.AddWithValue("@From", Convert.ToDateTime(dateTimePickerDateFrom.Text));
            tublecmd.Parameters.AddWithValue("@To", Convert.ToDateTime(date));
            tublecmd.Parameters.AddWithValue("@FromTime", ToTime[0]);
            tublecmd.Parameters.AddWithValue("@FromDayNight", FromTime[1]);
            tublecmd.Parameters.AddWithValue("@ToTime", ToTime[0]);
            tublecmd.Parameters.AddWithValue("@ToDayNight", ToTime[1]);
            tublecmd.Parameters.AddWithValue("@Date", Convert.ToDateTime(DateTime.Now.ToShortDateString()));
            tublecon.Open();
            tublecmd.ExecuteNonQuery();
            tublecon.Close();
        }

        void AddAttendanceLeave()
        {
            string []week = new string[7];
            week[0] = "Monday";
            week[1] = "Tuesday";
            week[2] = "Wednesday";
            week[3] = "Thursday";
            week[4] = "Friday";
            week[5] = "Saturday";
            week[6] = "Sunday";

            int intweek = 0;
            switch (DateTime.Now.DayOfWeek.ToString())
            {
                case "Monday":    intweek = 0; break;
                case "Tuesday":   intweek = 1; break;
                case "Wednesday": intweek = 2; break;
                case "Thursday":  intweek = 3; break;
                case "Friday":    intweek = 4; break;
                case "Saturday":  intweek = 5; break;
                case "Sunday":    intweek = 6; break;
            }

            
            if (Convert.ToDateTime(dateTimePickerDateFrom.Text) >= Convert.ToDateTime(DateTime.Now.ToShortDateString()) && 
                Convert.ToDateTime(dateTimePickerDateTo.Text) >= Convert.ToDateTime(DateTime.Now.ToShortDateString()))
            {
                for (DateTime dtm = Convert.ToDateTime(dateTimePickerDateFrom.Text); dtm <= Convert.ToDateTime(dateTimePickerDateTo.Text); dtm = dtm.AddDays(1))
                {
                    CountLeave();

                    if (accept.Equals(true))
                    {

                        SqlCommand tublecmd = new SqlCommand(@"INSERT INTO [dbo].[tblWorkersAttendance]([WorkersID],[Schedule],[Status],[Day],[Date],[AbsentCause]) 
                                                               VALUES (@WorkersID,@Schedule,@Status,@Day,@Date,@AbsentCause)", tublecon);
                        tublecmd.Parameters.AddWithValue("@WorkersID", labelWorkerID.Text);
                        tublecmd.Parameters.AddWithValue("@Schedule", labelSchedule.Text);
                        tublecmd.Parameters.AddWithValue("@Status", labelStatus.Text);
                        tublecmd.Parameters.AddWithValue("@Day", week[intweek]);
                        tublecmd.Parameters.AddWithValue("@Date", Convert.ToDateTime(dtm));
                        tublecmd.Parameters.AddWithValue("@AbsentCause", StrReasonLeave);
                        tublecon.Open();
                        tublecmd.ExecuteNonQuery();
                        tublecon.Close();
                        date = dtm.ToString();
                        intweek++;

                        if (intweek.Equals(7)) { intweek = 0; }
                    }
                }

                AddLeave();
                EmployeeStatus();
                Class.WorkersID = labelWorkerID.Text;
                Class.WorkersDate = labelDate.Text;
                this.Close();
                FormLeaveReceipt LR = new FormLeaveReceipt();
                LR.ShowDialog();
            }
            if (Convert.ToDateTime(dateTimePickerDateFrom.Text) < Convert.ToDateTime(DateTime.Now.ToShortDateString()))
            { MessageBox.Show("Can't accept Date From"); }
            if (Convert.ToDateTime(dateTimePickerDateTo.Text) < Convert.ToDateTime(DateTime.Now.ToShortDateString()))
            { MessageBox.Show("Can't accept Date To"); }
        }

        void EmployeeStatus()
        {
            SqlCommand cmd = new SqlCommand("INSERT INTO [dbo].[tblEmplyeeStatus] ([EmployeeID],[Date],[Time],[TimeDayNight],[Type],WorkersID,[Description]) VALUES (@EmployeeID, @Date ,@Time, @TimeDayNight, @Type, @WorkersID, @Description)", tublecon);
            cmd.Parameters.AddWithValue("@EmployeeID", Class.EmployeeID);
            cmd.Parameters.AddWithValue("@Date", Convert.ToDateTime(DateTime.Now.ToShortDateString()));
            cmd.Parameters.AddWithValue("@Time", Convert.ToDateTime(DateTime.Now.ToShortTimeString()));
                
            string converttime = DateTime.Now.ToShortTimeString();
            string[] convertsplittime = converttime.Split(' ');
            cmd.Parameters.AddWithValue("@TimeDayNight", convertsplittime[1]);
            cmd.Parameters.AddWithValue("@Type", "Add Worker Leave");
            cmd.Parameters.AddWithValue("@WorkersID", labelWorkerID.Text);
            cmd.Parameters.AddWithValue("@Description", "From " + dateTimePickerDateFrom.Text + " - To " + dateTimePickerTimeFrom.Text);
            tublecon.Open();
            cmd.ExecuteNonQuery();
            tublecon.Close();
        }

        private void buttonClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buttonAddLeave_Click(object sender, EventArgs e)
        {
            RemoveAbsent();
            ReasonLeaveInsert();
            AddAttendanceLeave();
        }

        private void comboBoxReasonLeave_SelectedIndexChanged(object sender, EventArgs e)
        {
            ReasonLeave();
        }
    }
}
