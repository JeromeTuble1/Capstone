﻿namespace QRCodeDemo
{
    partial class FormWorkerID
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.DBdjaasDataSetBioData = new QRCodeDemo.DBdjaasDataSetBioData();
            this.tblWorkersBioDataBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tblWorkersBioDataTableAdapter = new QRCodeDemo.DBdjaasDataSetBioDataTableAdapters.tblWorkersBioDataTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.DBdjaasDataSetBioData)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblWorkersBioDataBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // reportViewer1
            // 
            this.reportViewer1.Dock = System.Windows.Forms.DockStyle.Fill;
            reportDataSource1.Name = "DataSetBioData";
            reportDataSource1.Value = this.tblWorkersBioDataBindingSource;
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource1);
            this.reportViewer1.LocalReport.ReportEmbeddedResource = "QRCodeDemo.ReportWorkerID.rdlc";
            this.reportViewer1.Location = new System.Drawing.Point(0, 0);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.Size = new System.Drawing.Size(650, 319);
            this.reportViewer1.TabIndex = 0;
            // 
            // DBdjaasDataSetBioData
            // 
            this.DBdjaasDataSetBioData.DataSetName = "DBdjaasDataSetBioData";
            this.DBdjaasDataSetBioData.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tblWorkersBioDataBindingSource
            // 
            this.tblWorkersBioDataBindingSource.DataMember = "tblWorkersBioData";
            this.tblWorkersBioDataBindingSource.DataSource = this.DBdjaasDataSetBioData;
            // 
            // tblWorkersBioDataTableAdapter
            // 
            this.tblWorkersBioDataTableAdapter.ClearBeforeFill = true;
            // 
            // FormWorkerID
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(650, 319);
            this.Controls.Add(this.reportViewer1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormWorkerID";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Worker ID";
            this.Load += new System.EventHandler(this.FormWorkerID_Load);
            ((System.ComponentModel.ISupportInitialize)(this.DBdjaasDataSetBioData)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblWorkersBioDataBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
        private System.Windows.Forms.BindingSource tblWorkersBioDataBindingSource;
        private DBdjaasDataSetBioData DBdjaasDataSetBioData;
        private DBdjaasDataSetBioDataTableAdapters.tblWorkersBioDataTableAdapter tblWorkersBioDataTableAdapter;





    }
}