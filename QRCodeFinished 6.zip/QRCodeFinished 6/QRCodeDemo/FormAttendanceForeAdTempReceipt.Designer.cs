﻿namespace QRCodeDemo
{
    partial class FormAttendanceForeAdTempReceipt
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.DBdjaasDataSet3 = new QRCodeDemo.DBdjaasDataSet3();
            this.tblEmpAdTempBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tblEmpAdTempTableAdapter = new QRCodeDemo.DBdjaasDataSet3TableAdapters.tblEmpAdTempTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.DBdjaasDataSet3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblEmpAdTempBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // reportViewer1
            // 
            this.reportViewer1.Dock = System.Windows.Forms.DockStyle.Fill;
            reportDataSource1.Name = "DataSet1";
            reportDataSource1.Value = this.tblEmpAdTempBindingSource;
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource1);
            this.reportViewer1.LocalReport.ReportEmbeddedResource = "QRCodeDemo.ReportForeAdTemp.rdlc";
            this.reportViewer1.Location = new System.Drawing.Point(0, 0);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.Size = new System.Drawing.Size(828, 602);
            this.reportViewer1.TabIndex = 0;
            // 
            // DBdjaasDataSet3
            // 
            this.DBdjaasDataSet3.DataSetName = "DBdjaasDataSet3";
            this.DBdjaasDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tblEmpAdTempBindingSource
            // 
            this.tblEmpAdTempBindingSource.DataMember = "tblEmpAdTemp";
            this.tblEmpAdTempBindingSource.DataSource = this.DBdjaasDataSet3;
            // 
            // tblEmpAdTempTableAdapter
            // 
            this.tblEmpAdTempTableAdapter.ClearBeforeFill = true;
            // 
            // FormAttendanceForeAdTempReceipt
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(828, 602);
            this.Controls.Add(this.reportViewer1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormAttendanceForeAdTempReceipt";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = " ";
            this.Load += new System.EventHandler(this.FormAttendanceEmployeeTemp_Load);
            ((System.ComponentModel.ISupportInitialize)(this.DBdjaasDataSet3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblEmpAdTempBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
        private System.Windows.Forms.BindingSource tblEmpAdTempBindingSource;
        private DBdjaasDataSet3 DBdjaasDataSet3;
        private DBdjaasDataSet3TableAdapters.tblEmpAdTempTableAdapter tblEmpAdTempTableAdapter;
    }
}