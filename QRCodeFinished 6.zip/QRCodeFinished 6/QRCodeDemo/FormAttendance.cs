﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace QRCodeDemo
{
    public partial class FormAttendance : Form
    {
        SqlConnection tublecon = new SqlConnection(Class.tublecon);
        public FormAttendance()
        {
            InitializeComponent();
        }

        private void FormAttendance_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        void LoadData()
        {
            try
            {
                SqlCommand cmd = new SqlCommand("SELECT * FROM tblWorkersAttendance WHERE Date = @Date ORDER BY WorkersID ASC", tublecon);
                cmd.Parameters.AddWithValue("@Date", Convert.ToDateTime(DateTime.Now.ToShortDateString()));
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridViewAttendance.DataSource = dt;
            }
            catch
            {
                MessageBox.Show("No Connection");
            }
        }

        void Search()
        {
            try
            {
                bool accept = false;
                string category = Convert.ToString(comboBoxSelectCategory.SelectedItem);
                if (category.Equals("WorkersID") && textBoxSearch.Text != "") { category = "SELECT WorkersID, Schedule, CheckIn, CheckOut, Status, Day, Date, AbsentCause FROM tblWorkersAttendance WHERE WorkersID ="; accept = true; }
                else if (category.Equals("Schedule") && textBoxSearch.Text != "") { category = "SELECT WorkersID, Schedule, CheckIn, CheckOut, Status, Day, Date, AbsentCause FROM tblWorkersAttendance WHERE Schedule ="; accept = true; }
                else if (category.Equals("CheckIn") && textBoxSearch.Text != "") { category = "SELECT WorkersID, Schedule, CheckIn, CheckOut, Status, Day, Date, AbsentCause FROM tblWorkersAttendance WHERE CheckIn ="; accept = true; }
                else if (category.Equals("CheckOut") && textBoxSearch.Text != "") { category = "SELECT WorkersID, Schedule, CheckIn, CheckOut, Status, Day, Date, AbsentCause FROM tblWorkersAttendance WHERE CheckOut ="; accept = true; }
                else if (category.Equals("Status") && textBoxSearch.Text != "") { category = "SELECT WorkersID, Schedule, CheckIn, CheckOut, Status, Day, Date, AbsentCause FROM tblWorkersAttendance WHERE Status ="; accept = true; }
                else if (category.Equals("Day") && textBoxSearch.Text != "") { category = "SELECT WorkersID, Schedule, CheckIn, CheckOut, Status, Day, Date, AbsentCause FROM tblWorkersAttendance WHERE Day ="; accept = true; }
                else if (category.Equals("AbsentCause") && textBoxSearch.Text != "") { category = "SELECT WorkersID, Schedule, CheckIn, CheckOut, Status, Day, Date, AbsentCause FROM tblWorkersAttendance WHERE AbsentCause ="; accept = true; }
                else if (category.Equals("")) { accept = false; }

                if (accept.Equals(true))
                {
                    SqlCommand cmd = new SqlCommand(category + "@Search AND Date=@Date", tublecon);
                    cmd.Parameters.AddWithValue("@Search", textBoxSearch.Text);
                    cmd.Parameters.AddWithValue("@Date", Convert.ToDateTime(DateTime.Now.ToShortDateString()));
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dataGridViewAttendance.DataSource = dt;
                    accept = false;
                }
                else if (accept.Equals(false))
                {
                    LoadData();
                }
            }
            catch (Exception)
            {
                textBoxSearch.Text = "";
            }
        }

        private void textBoxSearch_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                Search();
                //if (Convert.ToString(comboBoxSelectCategory.SelectedItem).Equals("WorkersID"))
                //{
                //
                //        try
                //        {
                //            FormAttendanceEdit AE = new FormAttendanceEdit();
                //            Class.WorkersID = dataGridViewAttendance.CurrentRow.Cells[0].Value.ToString();
                //            Class.WorkersDate = dataGridViewAttendance.CurrentRow.Cells[6].Value.ToString();
                //            AE.ShowDialog();
                //            LoadData();
                //        }
                //        catch { }
                //    }
                //}
            }
        }

        void unknown()
        {
            //SqlCommand cmd = new SqlCommand("SELECT * FROM tblWorkersBioData WHERE WorkersID=@WorkersID", tublecon);
            //cmd.Parameters.AddWithValue("@WorkersID",textBoxSearch.Text);
            //SqlDataAdapter da = new SqlDataAdapter(cmd);
            //DataTable dt = new DataTable();
            //da.Fill(dt);

        }

        private void buttonBack_Click(object sender, EventArgs e)
        {
            FormMain db = new FormMain();
            db.ShowDialog();
        }

        private void buttonAddWorkers_Click(object sender, EventArgs e)
        {
            FormAttendanceAdd AA = new FormAttendanceAdd();
            AA.ShowDialog();
            LoadData();
        }


        private void dataGridViewAttendance_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridViewAttendance.CurrentRow.Cells[4].Value.ToString() != "Leave" && dataGridViewAttendance.CurrentRow.Cells[4].Value.ToString() != "Absent")
            {
                FormSelectFunction SF = new FormSelectFunction();
                Class.WorkersID = dataGridViewAttendance.CurrentRow.Cells[0].Value.ToString();
                Class.WorkersDate = dataGridViewAttendance.CurrentRow.Cells[6].Value.ToString();
                SF.ShowDialog();
                LoadData();
            }
        }

        private void jbtPanelGIF1_Click(object sender, EventArgs e)
        {

        }
    }
}
