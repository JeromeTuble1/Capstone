﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace QRCodeDemo
{
    public partial class FormFromTo : Form
    {
        public FormFromTo()
        {
            InitializeComponent();
        }
        private void FormFromTo_Load(object sender, EventArgs e)
        {

        }

        private void buttonShow_Click(object sender, EventArgs e)
        {
            Class.To = dateTimePickerTo.Text;
            Class.From = dateTimePickerFrom.Text;

            if (Class.AR.Equals(true))
            {
                Class.AR = false;
                FormAttendanceReceipt AR = new FormAttendanceReceipt();
                this.Close();
                AR.ShowDialog();
            }
            if (Class.OverallWorkerAttendance.Equals(true))
            {
                Class.OverallWorkerAttendance = false;
                FormAttendanceReceiptOverall FARO = new FormAttendanceReceiptOverall();
                this.Close();
                FARO.ShowDialog();
            }
        }
    }
}
