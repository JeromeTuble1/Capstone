﻿namespace QRCodeDemo
{
    partial class FormAttendanceEmployeeSelection
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.jbtPanelGIF1 = new QRCodeDemo.JBTControls.JBTPanelGIF();
            this.buttonWorkersAttendanceReport = new System.Windows.Forms.Button();
            this.buttonEmployeeInOutReport = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // jbtPanelGIF1
            // 
            this.jbtPanelGIF1.Angle = 15F;
            this.jbtPanelGIF1.BorderRadius = 1;
            this.jbtPanelGIF1.Color0 = System.Drawing.Color.Blue;
            this.jbtPanelGIF1.Color1 = System.Drawing.Color.Pink;
            this.jbtPanelGIF1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.jbtPanelGIF1.ForeColor = System.Drawing.Color.White;
            this.jbtPanelGIF1.Location = new System.Drawing.Point(0, 0);
            this.jbtPanelGIF1.Name = "jbtPanelGIF1";
            this.jbtPanelGIF1.Size = new System.Drawing.Size(417, 149);
            this.jbtPanelGIF1.TabIndex = 5;
            // 
            // buttonWorkersAttendanceReport
            // 
            this.buttonWorkersAttendanceReport.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.buttonWorkersAttendanceReport.FlatAppearance.BorderSize = 0;
            this.buttonWorkersAttendanceReport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonWorkersAttendanceReport.Font = new System.Drawing.Font("Segoe UI Symbol", 12F, System.Drawing.FontStyle.Bold);
            this.buttonWorkersAttendanceReport.ForeColor = System.Drawing.Color.White;
            this.buttonWorkersAttendanceReport.Location = new System.Drawing.Point(13, 19);
            this.buttonWorkersAttendanceReport.Margin = new System.Windows.Forms.Padding(4);
            this.buttonWorkersAttendanceReport.Name = "buttonWorkersAttendanceReport";
            this.buttonWorkersAttendanceReport.Size = new System.Drawing.Size(389, 52);
            this.buttonWorkersAttendanceReport.TabIndex = 6;
            this.buttonWorkersAttendanceReport.Text = "Employee Status Report";
            this.buttonWorkersAttendanceReport.UseVisualStyleBackColor = false;
            this.buttonWorkersAttendanceReport.Click += new System.EventHandler(this.buttonWorkersAttendanceReport_Click);
            // 
            // buttonEmployeeInOutReport
            // 
            this.buttonEmployeeInOutReport.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.buttonEmployeeInOutReport.FlatAppearance.BorderSize = 0;
            this.buttonEmployeeInOutReport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonEmployeeInOutReport.Font = new System.Drawing.Font("Segoe UI Symbol", 12F, System.Drawing.FontStyle.Bold);
            this.buttonEmployeeInOutReport.ForeColor = System.Drawing.Color.White;
            this.buttonEmployeeInOutReport.Location = new System.Drawing.Point(13, 79);
            this.buttonEmployeeInOutReport.Margin = new System.Windows.Forms.Padding(4);
            this.buttonEmployeeInOutReport.Name = "buttonEmployeeInOutReport";
            this.buttonEmployeeInOutReport.Size = new System.Drawing.Size(389, 52);
            this.buttonEmployeeInOutReport.TabIndex = 7;
            this.buttonEmployeeInOutReport.Text = "Employee In and Out Report";
            this.buttonEmployeeInOutReport.UseVisualStyleBackColor = false;
            this.buttonEmployeeInOutReport.Click += new System.EventHandler(this.buttonEmployeeInOutReport_Click);
            // 
            // FormAttendanceEmployeeSelection
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(417, 149);
            this.Controls.Add(this.buttonEmployeeInOutReport);
            this.Controls.Add(this.buttonWorkersAttendanceReport);
            this.Controls.Add(this.jbtPanelGIF1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormAttendanceEmployeeSelection";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Employee Selection";
            this.ResumeLayout(false);

        }

        #endregion

        private JBTControls.JBTPanelGIF jbtPanelGIF1;
        private System.Windows.Forms.Button buttonWorkersAttendanceReport;
        private System.Windows.Forms.Button buttonEmployeeInOutReport;
    }
}