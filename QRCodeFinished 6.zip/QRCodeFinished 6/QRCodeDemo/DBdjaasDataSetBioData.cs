﻿namespace QRCodeDemo {
    
    
    public partial class DBdjaasDataSetBioData {
    }
}

namespace QRCodeDemo.DBdjaasDataSetBioDataTableAdapters {
    
    
    public partial class tblWorkersBioDataTableAdapter {
    }
}
