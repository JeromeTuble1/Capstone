﻿using Microsoft.Reporting.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace QRCodeDemo
{
    public partial class FormAttendanceEmployeeReceipt : Form
    {
        SqlConnection tublecon = new SqlConnection(Class.tublecon);

        public FormAttendanceEmployeeReceipt()
        {
            InitializeComponent();
        }

        private void FormAttendanceEmployeeReceipt_Load(object sender, EventArgs e)
        {
            IndividualGetDataName();
        }

        void IndividualGetDataName()
        {

            SqlCommand tublecmd = new SqlCommand("SELECT L.EmployeeID, L.LName +', '+ L.FName +' '+ L.MName, ES.[Date], ES.[Time], ES.TimeDayNight, ES.[Type], ES.[WorkersID], ES.[Description] FROM tblEmplyeeStatus ES INNER JOIN tblLogin L ON ES.EmployeeID = L.EmployeeID WHERE L.EmployeeID = @EmployeeID", tublecon);
            tublecmd.Parameters.AddWithValue("@EmployeeID", Class.EmployeeID);
            SqlDataAdapter tubleda = new SqlDataAdapter(tublecmd);
            DataTable tubledt = new DataTable();
            tubleda.Fill(tubledt);
            tblEmplyeeStatusBindingSource.DataSource = tubledt;
            

            if (tubledt.Rows.Count.Equals(0))
            {
                MessageBox.Show("No Report");
                this.Close();
            }
            else
            {
                ReportParameter[] para = new ReportParameter[] { new ReportParameter("EmployeeID", tubledt.Rows[0][0].ToString()), new ReportParameter("EmployeeName", tubledt.Rows[0][1].ToString()), new ReportParameter("Date", DateTime.Now.ToShortDateString()) };
                this.reportViewer1.LocalReport.SetParameters(para);
                this.reportViewer1.RefreshReport();
            }
        }

        private void reportViewer1_Load(object sender, EventArgs e)
        {

        }
    }
}
