﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace QRCodeDemo
{
    public partial class FormLeaveAdd : Form
    {
        SqlConnection tublecon = new SqlConnection(Class.tublecon);
        string StrReasonLeave = "";
        bool isabsent = false;

        public FormLeaveAdd()
        {
            InitializeComponent();
        }

        private void FormHolidayAdd_Load(object sender, EventArgs e)
        {
            
            AlreadyLeaveOnLeaveRequested();
            AlreadyPresent();
            Loaddata();
            WorkerSchedule();
        }

        void AlreadyLeaveOnLeaveRequested()
        {
            SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM tblLeaveRequested WHERE WorkersID = @WorkersID AND [To] >= @Date", tublecon);
            cmd.Parameters.AddWithValue("@WorkersID", Class.WorkersID);
            cmd.Parameters.AddWithValue("@Date", Convert.ToDateTime(DateTime.Now.ToShortDateString()));
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            if (Convert.ToInt16(dt.Rows[0][0]) != 0)
            {
                MessageBox.Show("Already Leave");
                this.Close();
            }
        }

        void AlreadyPresent()
        {
            SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM tblWorkersAttendance WHERE WorkersID = @WorkersID AND [Date] = @Date AND NOT Status = @Leave AND NOT Status = @Absent", tublecon);
            cmd.Parameters.AddWithValue("@WorkersID", Class.WorkersID);
            cmd.Parameters.AddWithValue("@Date", Convert.ToDateTime(DateTime.Now.ToShortDateString()));
            cmd.Parameters.AddWithValue("@Leave","Leave");
            cmd.Parameters.AddWithValue("@Absent", "Absent");
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            if (Convert.ToInt16(dt.Rows[0][0]) != 0)
            {
                MessageBox.Show("Already Present");
                this.Close();
            }
        }

        void RemoveAbsent()
        {
            SqlCommand cmd = new SqlCommand("DELETE FROM tblWorkersAttendance WHERE WorkersID = @WorkersID AND [Date] = @Date AND Status = @Absent", tublecon);
            cmd.Parameters.AddWithValue("@WorkersID", Class.WorkersID);
            cmd.Parameters.AddWithValue("@Date", Convert.ToDateTime(DateTime.Now.ToShortDateString()));
            cmd.Parameters.AddWithValue("@Absent", "Absent");
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
        }

        void Loaddata()
        {
            SqlCommand cmd = new SqlCommand("SELECT * FROM tblWorkersBioData WHERE WorkersID = @WorkersID", tublecon);
            cmd.Parameters.AddWithValue("@WorkersID", Class.WorkersID);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            labelWorkerID.Text = Class.WorkersID;
            labelWorkerName.Text = dt.Rows[0][2] + ", " + dt.Rows[0][1] + " " + dt.Rows[0][3] + " " + dt.Rows[0][4];
            labelDay.Text = DateTime.Now.DayOfWeek.ToString();
            labelDate.Text = DateTime.Now.ToShortDateString();
            MemoryStream mem = new MemoryStream((Byte[])(dt.Rows[0]["Picture"]));
            pictureBox1.Image = Image.FromStream(mem);
            labelReason.Visible = false;
            textBoxReason.Visible = false;
        }

        void ReasonLeave()
        {
            if (Convert.ToString(comboBoxReasonLeave.SelectedItem).Equals("Family and Medical For"))
            {
                labelReason.Visible = true;
                labelReason.Text = "Family and Medical For";
                textBoxReason.Visible = true;
            }
            else if (Convert.ToString(comboBoxReasonLeave.SelectedItem).Equals("Funeral - Relatioship"))
            {
                labelReason.Visible = true;
                labelReason.Text = "Funeral - Relatioship";
                textBoxReason.Visible = true;
            }
            else if (Convert.ToString(comboBoxReasonLeave.SelectedItem).Equals("Other"))
            {
                labelReason.Visible = true;
                labelReason.Text = "Other";
                textBoxReason.Visible = true;
            }
            else
            {
                labelReason.Visible = false;
                labelReason.Text = "";
                textBoxReason.Visible = false;
                textBoxReason.Text = "";
            }
        }

        void ReasonLeaveInsert()
        {
            if (Convert.ToString(comboBoxReasonLeave.SelectedItem).Equals("Family and Medical For"))
            {
                StrReasonLeave = "Family and Medical For - " + textBoxReason.Text;
            }
            else if (Convert.ToString(comboBoxReasonLeave.SelectedItem).Equals("Funeral - Relatioship"))
            {
                StrReasonLeave = "Funeral - Relatioship - " + textBoxReason.Text;
            }
            else if (Convert.ToString(comboBoxReasonLeave.SelectedItem).Equals("Other"))
            {
                StrReasonLeave = "Other - " + textBoxReason.Text;
            }
            else
            {
                StrReasonLeave = Convert.ToString(comboBoxReasonLeave.SelectedItem);
            }
        }

        void WorkerSchedule()
        {
            try
            {
                string Date ="", ColDate = "", DateDayNight = "";
                SqlCommand cmd = new SqlCommand("SELECT * FROM tblWorkersSchedule WHERE WorkersID = @WorkersID", tublecon);
                cmd.Parameters.AddWithValue("@WorkersID", labelWorkerID.Text);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);

                if (Convert.ToString(DateTime.Now.DayOfWeek).Equals("Monday")) { Date = "Monday"; ColDate = "MonSched"; DateDayNight = "MonDayNight"; }
                else if (Convert.ToString(DateTime.Now.DayOfWeek).Equals("Tuesday")) { Date = "Tuesday"; ColDate = "TueSched"; DateDayNight = "TueDayNight"; }
                else if (Convert.ToString(DateTime.Now.DayOfWeek).Equals("Wednesday")) { Date = "Wednesday"; ColDate = "WedSched"; DateDayNight = "WedDayNight"; }
                else if (Convert.ToString(DateTime.Now.DayOfWeek).Equals("Thursday")) { Date = "Thursday"; ColDate = "ThuSched"; DateDayNight = "ThuDayNight"; }
                else if (Convert.ToString(DateTime.Now.DayOfWeek).Equals("Friday")) { Date = "Friday"; ColDate = "FriSched"; DateDayNight = "FriDayNight"; }
                else if (Convert.ToString(DateTime.Now.DayOfWeek).Equals("Saturday")) { Date = "Saturday"; ColDate = "SatSched"; DateDayNight = "SatDayNight"; }
                else if (Convert.ToString(DateTime.Now.DayOfWeek).Equals("Sunday")) { Date = "Sunday"; ColDate = "SunSched"; DateDayNight = "SunDayNight"; }

                labelSchedule.Text = dt.Rows[0][ColDate] + " " + dt.Rows[0][DateDayNight];
            }
            catch
            {

            }
        }

        void AddLeave()
        {
            try
            {
                string[] FromTime = new string[1];
                string[] ToTime = new string[1];

                FromTime = dateTimePickerTimeFrom.Text.Split(' ');
                ToTime = dateTimePickerTimeTo.Text.Split(' ');

                SqlCommand tublecmd = new SqlCommand("INSERT INTO [dbo].[tblLeaveRequested] ([WorkersID],[From],[To],[FromTime],[ToTime],[Date],[FromDayNight],[ToDayNight]) VALUES (@WorkersID,@From,@To,@FromTime,@ToTime,@Date,@FromDayNight,@ToDayNight)", tublecon);
                tublecmd.Parameters.AddWithValue("@WorkersID",labelWorkerID.Text);
                tublecmd.Parameters.AddWithValue("@From", Convert.ToDateTime(dateTimePickerDateFrom.Text));
                tublecmd.Parameters.AddWithValue("@To",Convert.ToDateTime(dateTimePickerDateTo.Text));
                tublecmd.Parameters.AddWithValue("@FromTime",ToTime[0]);
                tublecmd.Parameters.AddWithValue("@FromDayNight",FromTime[1]);
                tublecmd.Parameters.AddWithValue("@ToTime",ToTime[0]);
                tublecmd.Parameters.AddWithValue("@ToDayNight",ToTime[1]);
                tublecmd.Parameters.AddWithValue("@Date",Convert.ToDateTime(DateTime.Now.ToShortDateString()));
                tublecon.Open();
                tublecmd.ExecuteNonQuery();
                tublecon.Close();
            }
            catch
            {
                tublecon.Close();
            }
        }

        void AddAttendanceLeave()
        {
            try
            {
                for (DateTime dtm = Convert.ToDateTime(dateTimePickerDateFrom.Text); dtm <= Convert.ToDateTime(dateTimePickerDateTo.Text); dtm = dtm.AddDays(1))
                {
                    SqlCommand tublecmd = new SqlCommand("INSERT INTO [dbo].[tblWorkersAttendance]([WorkersID],[Schedule],[Status],[Day],[Date],[AbsentCause]) VALUES (@WorkersID,@Schedule,@Status,@Day,@Date,@AbsentCause)", tublecon);
                    tublecmd.Parameters.AddWithValue("@WorkersID", labelWorkerID.Text);
                    tublecmd.Parameters.AddWithValue("@Schedule", labelSchedule.Text);
                    tublecmd.Parameters.AddWithValue("@Status", labelStatus.Text);
                    tublecmd.Parameters.AddWithValue("@Day", labelDay.Text);
                    tublecmd.Parameters.AddWithValue("@Date", Convert.ToDateTime(dtm));
                    tublecmd.Parameters.AddWithValue("@AbsentCause", StrReasonLeave);
                    tublecon.Open();
                    tublecmd.ExecuteNonQuery();
                    tublecon.Close();
                }
            }
            catch
            {
                tublecon.Close();
            }
        }

        void EmployeeStatus()
        {
            SqlCommand cmd = new SqlCommand("INSERT INTO [dbo].[tblEmplyeeStatus] ([EmployeeID],[Date],[Time],[TimeDayNight],[Type],WorkersID,[Description]) VALUES (@EmployeeID, @Date ,@Time, @TimeDayNight, @Type, @WorkersID, @Description)", tublecon);
            cmd.Parameters.AddWithValue("@EmployeeID", Class.EmployeeID);
            cmd.Parameters.AddWithValue("@Date", Convert.ToDateTime(DateTime.Now.ToShortDateString()));
            cmd.Parameters.AddWithValue("@Time", Convert.ToDateTime(DateTime.Now.ToShortTimeString()));

            string converttime = DateTime.Now.ToShortTimeString();
            string[] convertsplittime = converttime.Split(' ');
            cmd.Parameters.AddWithValue("@TimeDayNight", convertsplittime[1]);
            cmd.Parameters.AddWithValue("@Type", "Add Worker Leave");
            cmd.Parameters.AddWithValue("@WorkersID", labelWorkerID.Text);
            cmd.Parameters.AddWithValue("@Description", "From " + dateTimePickerDateFrom.Text + " - To " + dateTimePickerTimeFrom.Text);
            tublecon.Open();
            cmd.ExecuteNonQuery();
            tublecon.Close();
        }

        private void buttonClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buttonAddLeave_Click(object sender, EventArgs e)
        {
            RemoveAbsent();
            ReasonLeaveInsert();
            AddLeave();
            AddAttendanceLeave();
            EmployeeStatus();

            Class.WorkersID = labelWorkerID.Text;
            Class.WorkersDate = labelDate.Text;
            this.Close();
            FormLeaveReceipt LR = new FormLeaveReceipt();
            LR.ShowDialog();
        }

        private void comboBoxReasonLeave_SelectedIndexChanged(object sender, EventArgs e)
        {
            ReasonLeave();
        }
    }
}
