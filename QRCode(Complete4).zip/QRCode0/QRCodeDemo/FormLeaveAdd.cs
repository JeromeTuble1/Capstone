﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace QRCodeDemo
{
    public partial class FormLeaveAdd : Form
    {
        SqlConnection tublecon = new SqlConnection(Class.tublecon);
        string StrReasonLeave = "";

        public FormLeaveAdd()
        {
            InitializeComponent();
        }

        private void FormHolidayAdd_Load(object sender, EventArgs e)
        {
            AlreadyPresent();
            AlreadyLeaveOnLeaveRequested();
            Loaddata();
            WorkerSchedule();
        }

        void AlreadyLeaveOnLeaveRequested()
        {
            SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM tblLeaveRequested WHERE WorkersID = @WorkersID AND [To] >= @Date", tublecon);
            cmd.Parameters.AddWithValue("@WorkersID", Class.WorkersID);
            cmd.Parameters.AddWithValue("@Date", Convert.ToDateTime(DateTime.Now.ToShortDateString()));
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            if (Convert.ToInt16(dt.Rows[0][0]) != 0)
            {
                MessageBox.Show("Already Leave");
                this.Close();
            }
        }

        void AlreadyPresent()
        {
            SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM tblWorkersAttendance WHERE WorkersID = @WorkersID AND [Date] = @Date AND NOT Status = @Status", tublecon);
            cmd.Parameters.AddWithValue("@WorkersID", Class.WorkersID);
            cmd.Parameters.AddWithValue("@Date", Convert.ToDateTime(DateTime.Now.ToShortDateString()));
            cmd.Parameters.AddWithValue("@Status","Leave");
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            if (Convert.ToInt16(dt.Rows[0][0]) != 0)
            {
                MessageBox.Show("Already Present");
                this.Close();
            }
        }

        void Loaddata()
        {
            SqlCommand cmd = new SqlCommand("SELECT * FROM tblWorkersBioData WHERE WorkersID = @WorkersID", tublecon);
            cmd.Parameters.AddWithValue("@WorkersID", Class.WorkersID);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            labelWorkerID.Text = Class.WorkersID;
            labelWorkerName.Text = dt.Rows[0][2] + ", " + dt.Rows[0][1] + " " + dt.Rows[0][3];
            labelDay.Text = DateTime.Now.DayOfWeek.ToString();
            labelDate.Text = DateTime.Now.ToShortDateString();
            MemoryStream mem = new MemoryStream((Byte[])(dt.Rows[0]["Picture"]));
            pictureBox1.Image = Image.FromStream(mem);
            labelReason.Visible = false;
            textBoxReason.Visible = false;
        }

        void ReasonLeave()
        {
            if (Convert.ToString(comboBoxReasonLeave.SelectedItem).Equals("Family and Medical For"))
            {
                labelReason.Visible = true;
                labelReason.Text = "Family and Medical For";
                textBoxReason.Visible = true;
            }
            else if (Convert.ToString(comboBoxReasonLeave.SelectedItem).Equals("Funeral - Relatioship"))
            {
                labelReason.Visible = true;
                labelReason.Text = "Funeral - Relatioship";
                textBoxReason.Visible = true;
            }
            else if (Convert.ToString(comboBoxReasonLeave.SelectedItem).Equals("Other"))
            {
                labelReason.Visible = true;
                labelReason.Text = "Other";
                textBoxReason.Visible = true;
            }
            else
            {
                labelReason.Visible = false;
                labelReason.Text = "";
                textBoxReason.Visible = false;
                textBoxReason.Text = "";
            }
        }

        void ReasonLeaveInsert()
        {
            if (Convert.ToString(comboBoxReasonLeave.SelectedItem).Equals("Family and Medical For"))
            {
                StrReasonLeave = "Family and Medical For - " + textBoxReason.Text;
            }
            else if (Convert.ToString(comboBoxReasonLeave.SelectedItem).Equals("Funeral - Relatioship"))
            {
                StrReasonLeave = "Funeral - Relatioship - " + textBoxReason.Text;
            }
            else if (Convert.ToString(comboBoxReasonLeave.SelectedItem).Equals("Other"))
            {
                StrReasonLeave = "Other - " + textBoxReason.Text;
            }
            else
            {
                StrReasonLeave = Convert.ToString(comboBoxReasonLeave.SelectedItem);
            }
        }

        void WorkerSchedule()
        {
            try
            {
                string Date ="", ColDate = "", DateDayNight = "";
                SqlCommand cmd = new SqlCommand("SELECT * FROM tblWorkersSchedule WHERE WorkersID = @WorkersID", tublecon);
                cmd.Parameters.AddWithValue("@WorkersID", labelWorkerID.Text);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);

                if (Convert.ToString(DateTime.Now.DayOfWeek).Equals("Monday")) { Date = "Monday"; ColDate = "MonSched"; DateDayNight = "MonDayNight"; }
                else if (Convert.ToString(DateTime.Now.DayOfWeek).Equals("Tuesday")) { Date = "Tuesday"; ColDate = "TueSched"; DateDayNight = "TueDayNight"; }
                else if (Convert.ToString(DateTime.Now.DayOfWeek).Equals("Wednesday")) { Date = "Wednesday"; ColDate = "WedSched"; DateDayNight = "WedDayNight"; }
                else if (Convert.ToString(DateTime.Now.DayOfWeek).Equals("Thursday")) { Date = "Thursday"; ColDate = "ThuSched"; DateDayNight = "ThuDayNight"; }
                else if (Convert.ToString(DateTime.Now.DayOfWeek).Equals("Friday")) { Date = "Friday"; ColDate = "FriSched"; DateDayNight = "FriDayNight"; }
                else if (Convert.ToString(DateTime.Now.DayOfWeek).Equals("Saturday")) { Date = "Saturday"; ColDate = "SatSched"; DateDayNight = "SatDayNight"; }
                else if (Convert.ToString(DateTime.Now.DayOfWeek).Equals("Sunday")) { Date = "Sunday"; ColDate = "SunSched"; DateDayNight = "SunDayNight"; }

                labelSchedule.Text = dt.Rows[0][ColDate] + " " + dt.Rows[0][DateDayNight];
            }
            catch
            {

            }
        }

        void AddLeave()
        {
            try
            {
                string[] FromTime = new string[1];
                string[] ToTime = new string[1];

                FromTime = dateTimePickerTimeFrom.Text.Split(' ');
                ToTime = dateTimePickerTimeTo.Text.Split(' ');

                SqlCommand tublecmd = new SqlCommand("INSERT INTO [dbo].[tblLeaveRequested] ([WorkersID],[From],[To],[FromTime],[ToTime],[Date],[FromDayNight],[ToDayNight]) VALUES (@WorkersID,@From,@To,@FromTime,@ToTime,@Date,@FromDayNight,@ToDayNight)", tublecon);
                tublecmd.Parameters.AddWithValue("@WorkersID",labelWorkerID.Text);
                tublecmd.Parameters.AddWithValue("@From", Convert.ToDateTime(dateTimePickerDateFrom.Text));
                tublecmd.Parameters.AddWithValue("@To",Convert.ToDateTime(dateTimePickerDateTo.Text));
                tublecmd.Parameters.AddWithValue("@FromTime",ToTime[0]);
                tublecmd.Parameters.AddWithValue("@FromDayNight",FromTime[1]);
                tublecmd.Parameters.AddWithValue("@ToTime",ToTime[0]);
                tublecmd.Parameters.AddWithValue("@ToDayNight",ToTime[1]);
                tublecmd.Parameters.AddWithValue("@Date",Convert.ToDateTime(DateTime.Now.ToShortDateString()));
                tublecon.Open();
                tublecmd.ExecuteNonQuery();
                tublecon.Close();
                MessageBox.Show("LR Success");
            }
            catch
            {
                tublecon.Close();
            }
        }

        void AddAttendanceLeave()
        {
            try
            {
                SqlCommand tublecmd = new SqlCommand("INSERT INTO [dbo].[tblWorkersAttendance]([WorkersID],[Schedule],[Status],[Day],[Date],[AbsentCause]) VALUES (@WorkersID,@Schedule,@Status,@Day,@Date,@AbsentCause)", tublecon);
                tublecmd.Parameters.AddWithValue("@WorkersID",labelWorkerID.Text);
                tublecmd.Parameters.AddWithValue("@Schedule",labelSchedule.Text);
                tublecmd.Parameters.AddWithValue("@Status",labelStatus.Text);
                tublecmd.Parameters.AddWithValue("@Day",labelDay.Text);
                tublecmd.Parameters.AddWithValue("@Date",Convert.ToDateTime(labelDate.Text));
                tublecmd.Parameters.AddWithValue("@AbsentCause",StrReasonLeave);
                tublecon.Open();
                tublecmd.ExecuteNonQuery();
                tublecon.Close();
                MessageBox.Show("WA Success");
            }
            catch
            {
                tublecon.Close();
            }
        }

        private void buttonClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buttonAddLeave_Click(object sender, EventArgs e)
        {
            ReasonLeaveInsert();
            AddLeave();
            AddAttendanceLeave();

            Class.WorkersID = labelWorkerID.Text;
            Class.WorkersDate = labelDate.Text;
            this.Close();
            FormLeaveReceipt LR = new FormLeaveReceipt();
            LR.ShowDialog();
        }

        private void comboBoxReasonLeave_SelectedIndexChanged(object sender, EventArgs e)
        {
            ReasonLeave();
        }
    }
}
