﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace QRCodeDemo
{
    public partial class FormHolidayAdd : Form
    {
        SqlConnection tublecon = new SqlConnection(Class.tublecon);

        public FormHolidayAdd()
        {
            InitializeComponent();
        }

        private void FormHolidayAdd_Load(object sender, EventArgs e)
        {
            Loaddata();
            LoadAlreadyHoliday();

        }

        void Loaddata()
        {
            string week = "";
            bool accept = false;
            if (DateTime.Now.DayOfWeek.ToString().Equals("Monday")) { week = "SELECT MonSched FROM tblWorkersSchedule WHERE WorkersID = "; accept = true; }
            else if (DateTime.Now.DayOfWeek.ToString().Equals("Tuesday")) { week = "SELECT TueSched FROM tblWorkersSchedule WHERE WorkersID = "; accept = true; }
            else if (DateTime.Now.DayOfWeek.ToString().Equals("Wednesday")) { week = "SELECT WedSched FROM tblWorkersSchedule WHERE WorkersID = "; accept = true; }
            else if (DateTime.Now.DayOfWeek.ToString().Equals("Thursday")) { week = "SELECT ThuSched FROM tblWorkersSchedule WHERE WorkersID = "; accept = true; }
            else if (DateTime.Now.DayOfWeek.ToString().Equals("Friday")) { week = "SELECT FriSched FROM tblWorkersSchedule WHERE WorkersID = "; accept = true; }
            else if (DateTime.Now.DayOfWeek.ToString().Equals("Saturday")) { week = "SELECT SatSched FROM tblWorkersSchedule WHERE WorkersID = "; accept = true; }
            else if (DateTime.Now.DayOfWeek.ToString().Equals("Sunday")) { week = "SELECT SunSched FROM tblWorkersSchedule WHERE WorkersID = "; accept = true; }

            if (accept.Equals(true))
            {

                SqlCommand cmd = new SqlCommand(week+"@WorkersID", tublecon);
                cmd.Parameters.AddWithValue("@WorkersID", Class.WorkersID);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);

                labelWorkersID.Text = Class.WorkersID;
                labelSchedule.Text = dt.Rows[0][0].ToString();
                labelDay.Text = DateTime.Now.DayOfWeek.ToString();
                labelDate.Text = DateTime.Now.ToShortDateString();
                accept = false;
            }
        }

        private void buttonAddHoliday_Click(object sender, EventArgs e)
        {
            AlreadyHoliday();
        }

        void LoadAlreadyHoliday() 
        {
            SqlCommand tublecmd = new SqlCommand("SELECT COUNT(*) FROM tblWorkersAttendance WHERE WorkersID = @WorkersID AND [Date] = @Date", tublecon);
            tublecmd.Parameters.AddWithValue("@WorkersID", Class.WorkersID);
            tublecmd.Parameters.AddWithValue("@Date", Convert.ToDateTime(DateTime.Now.ToShortDateString()));
            SqlDataAdapter da = new SqlDataAdapter(tublecmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            if (Convert.ToInt16(dt.Rows[0][0]) != 0)
            {
                MessageBox.Show("Already on the List");
                this.Close();
            }
        }

        void AlreadyHoliday()
        {
            bool accept = true;

            if (Convert.ToString(comboBoxStatus.SelectedItem).Equals("") || textBoxAbsentCause.Text.Equals(""))
            {
                MessageBox.Show("Fillup the blanks");
                accept = false;
            }

            if (accept.Equals(true))
            {
                AddHoliday();
                this.Hide();
            }

        }

        void AddHoliday()
        {
            tublecon.Open();
            SqlCommand tublecmd = new SqlCommand("INSERT INTO tblWorkersAttendance (WorkersID,Schedule,Status,Day,Date,AbsentCause) VALUES (@WorkersID,@Schedule,@Status,@Day,@Date,@AbsentCause)", tublecon);
            tublecmd.Parameters.AddWithValue("@WorkersID",Class.WorkersID);
            tublecmd.Parameters.AddWithValue("@Schedule", labelSchedule.Text);
            tublecmd.Parameters.AddWithValue("@Status",Convert.ToString(comboBoxStatus.SelectedItem));
            tublecmd.Parameters.AddWithValue("@Day",labelDay.Text);
            tublecmd.Parameters.AddWithValue("@Date",labelDate.Text);
            tublecmd.Parameters.AddWithValue("@AbsentCause",textBoxAbsentCause.Text);
            tublecmd.ExecuteNonQuery();
            tublecon.Close();
        }

        private void buttonClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
