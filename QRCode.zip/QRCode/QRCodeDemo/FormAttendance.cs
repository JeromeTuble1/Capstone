﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace QRCodeDemo
{
    public partial class FormAttendance : Form
    {
        SqlConnection tublecon = new SqlConnection(Class.tublecon);
        public FormAttendance()
        {
            InitializeComponent();
        }

        private void FormAttendance_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        void LoadData()
        {
            try
            {
                SqlCommand cmd = new SqlCommand("SELECT * FROM tblWorkersAttendance WHERE Date=@Date", tublecon);
                cmd.Parameters.AddWithValue("@Date", Convert.ToDateTime(DateTime.Now.ToShortDateString()));
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridViewAttendance.DataSource = dt;
            }
            catch
            {
                MessageBox.Show("No Connection");
            }
        }

        void Search()
        {
            bool accept = false;
            string category = Convert.ToString(comboBoxSelectCategory.SelectedItem);
            if (category.Equals("WorkersID") && textBoxSearch.Text != "") { category = "SELECT WBD.WorkersID, WBD.LName, WBD.FName, WBD.MName, WBD.BirthDate, WBD.HireDate, WBD.[Address], WBD.ContactNumber, WBD.EmergencyContact FROM tblWorkersBioData WBD WHERE WBD.WorkersID ="; accept = true; }
            else if (category.Equals("LName") && textBoxSearch.Text != "") { category = "SELECT WBD.WorkersID, WBD.LName, WBD.FName, WBD.MName, WBD.BirthDate, WBD.HireDate, WBD.[Address], WBD.ContactNumber, WBD.EmergencyContact FROM tblWorkersBioData WBD WHERE WBD.LName ="; accept = true; }
            else if (category.Equals("FName") && textBoxSearch.Text != "") { category = "SELECT WBD.WorkersID, WBD.LName, WBD.FName, WBD.MName, WBD.BirthDate, WBD.HireDate, WBD.[Address], WBD.ContactNumber, WBD.EmergencyContact FROM tblWorkersBioData WBD WHERE WBD.FName ="; accept = true; }
            else if (category.Equals("MName") && textBoxSearch.Text != "") { category = "SELECT WBD.WorkersID, WBD.LName, WBD.FName, WBD.MName, WBD.BirthDate, WBD.HireDate, WBD.[Address], WBD.ContactNumber, WBD.EmergencyContact FROM tblWorkersBioData WBD WHERE WBD.MName ="; accept = true; }
            else if (category.Equals("BirthDate") && textBoxSearch.Text != "") { category = "SELECT WBD.WorkersID, WBD.LName, WBD.FName, WBD.MName, WBD.BirthDate, WBD.HireDate, WBD.[Address], WBD.ContactNumber, WBD.EmergencyContact FROM tblWorkersBioData WBD WHERE WBD.BirthDate ="; accept = true; }
            else if (category.Equals("HireDate") && textBoxSearch.Text != "") { category = "SELECT WBD.WorkersID, WBD.LName, WBD.FName, WBD.MName, WBD.BirthDate, WBD.HireDate, WBD.[Address], WBD.ContactNumber, WBD.EmergencyContact FROM tblWorkersBioData WBD WHERE WBD.HireDate = "; accept = true; }
            else if (category.Equals("Address") && textBoxSearch.Text != "") { category = "SELECT WBD.WorkersID, WBD.LName, WBD.FName, WBD.MName, WBD.BirthDate, WBD.HireDate, WBD.[Address], WBD.ContactNumber, WBD.EmergencyContact FROM tblWorkersBioData WBD WHERE WBD.Address ="; accept = true; }
            else if (category.Equals("ContactNumber") && textBoxSearch.Text != "") { category = "SELECT WBD.WorkersID, WBD.LName, WBD.FName, WBD.MName, WBD.BirthDate, WBD.HireDate, WBD.[Address], WBD.ContactNumber, WBD.EmergencyContact FROM tblWorkersBioData WBD WHERE WBD.ContactNumber ="; accept = true; }
            else if (category.Equals("EmergencyContact") && textBoxSearch.Text != "") { category = "SELECT WBD.WorkersID, WBD.LName, WBD.FName, WBD.MName, WBD.BirthDate, WBD.HireDate, WBD.[Address], WBD.ContactNumber, WBD.EmergencyContact FROM tblWorkersBioData WBD WHERE WBD.EmergencyContact ="; accept = true; }
            else if (category.Equals("")) { accept = false; }

            if (accept.Equals(true))
            {
                SqlCommand cmd = new SqlCommand(category + "@Search", tublecon);
                cmd.Parameters.AddWithValue("@Search", textBoxSearch.Text);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridViewAttendance.DataSource = dt;
                accept = false;
            }
            else if (accept.Equals(false))
            {
                LoadData();
            }
        }

        private void buttonSearch_Click(object sender, EventArgs e)
        {
            Search();
        }

        private void textBoxSearch_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                Search();
            }
        }

        private void buttonBack_Click(object sender, EventArgs e)
        {
            FormMain db = new FormMain();
            db.ShowDialog();
        }

        private void buttonAddWorkers_Click(object sender, EventArgs e)
        {
            FormAttendanceAdd AA = new FormAttendanceAdd();
            AA.ShowDialog();
            LoadData();
        }


        private void dataGridViewAttendance_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            FormAttendanceEdit AE = new FormAttendanceEdit();
            Class.WorkersID = dataGridViewAttendance.CurrentRow.Cells[0].Value.ToString();
            Class.WorkersDate = dataGridViewAttendance.CurrentRow.Cells[6].Value.ToString();
            AE.ShowDialog();
            LoadData();
        }
    }
}
