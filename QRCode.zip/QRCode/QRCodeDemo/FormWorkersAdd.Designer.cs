﻿namespace QRCodeDemo
{
    partial class FormWorkersAdd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonAddWorkers = new System.Windows.Forms.Button();
            this.numericUpDownNumofChil = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxLName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.comboBoxMartialStatus = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxAddress = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.textBoxWorkerID = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.dateTimePickerbirthdate = new System.Windows.Forms.DateTimePicker();
            this.label11 = new System.Windows.Forms.Label();
            this.textBoxFName = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.textBoxMName = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.panelBioData = new System.Windows.Forms.Panel();
            this.textBoxMotherLName = new System.Windows.Forms.TextBox();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.textBoxMotherMName = new System.Windows.Forms.TextBox();
            this.label45 = new System.Windows.Forms.Label();
            this.textBoxMotherFName = new System.Windows.Forms.TextBox();
            this.textBoxFatherLName = new System.Windows.Forms.TextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.textBoxFatherMName = new System.Windows.Forms.TextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.textBoxFatherFName = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.comboBoxReligion = new System.Windows.Forms.ComboBox();
            this.label21 = new System.Windows.Forms.Label();
            this.maskedTextBoxEmergencyContact = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBoxContactNum = new System.Windows.Forms.MaskedTextBox();
            this.textBoxHireDate = new System.Windows.Forms.TextBox();
            this.comboBoxYearHire = new System.Windows.Forms.ComboBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.textBoxReference = new System.Windows.Forms.TextBox();
            this.textBoxNameOfCompany = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.textBoxPosition = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.buttonFileUpload = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.panelEducationalQualification = new System.Windows.Forms.Panel();
            this.label35 = new System.Windows.Forms.Label();
            this.comboBoxMasterYearPassed = new System.Windows.Forms.ComboBox();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.numericUpDownMasterGrade = new System.Windows.Forms.NumericUpDown();
            this.textBoxMasterName = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.comboBoxGraduationYearPassed = new System.Windows.Forms.ComboBox();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.numericUpDownGraduationGrade = new System.Windows.Forms.NumericUpDown();
            this.textBoxGraduationName = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.comboBoxIntermediateYearPassed = new System.Windows.Forms.ComboBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.numericUpDownIntermediateGrade = new System.Windows.Forms.NumericUpDown();
            this.textBoxIntermediateName = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.comboBoxMatricYearPassed = new System.Windows.Forms.ComboBox();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.numericUpDownMatricGrade = new System.Windows.Forms.NumericUpDown();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.textBoxMatricName = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.panelImage = new System.Windows.Forms.Panel();
            this.flowLayoutPanel2 = new System.Windows.Forms.FlowLayoutPanel();
            this.panelWorkingExperience = new System.Windows.Forms.Panel();
            this.panelWorkerSchedule = new System.Windows.Forms.Panel();
            this.dateTimePickerSunday = new System.Windows.Forms.DateTimePicker();
            this.dateTimePickerSaturday = new System.Windows.Forms.DateTimePicker();
            this.dateTimePickerFriday = new System.Windows.Forms.DateTimePicker();
            this.dateTimePickerThursday = new System.Windows.Forms.DateTimePicker();
            this.dateTimePickerWednesday = new System.Windows.Forms.DateTimePicker();
            this.dateTimePickerTuesday = new System.Windows.Forms.DateTimePicker();
            this.dateTimePickerMonday = new System.Windows.Forms.DateTimePicker();
            this.label51 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.buttonAddWorker = new System.Windows.Forms.Button();
            this.panel6 = new System.Windows.Forms.Panel();
            this.flowLayoutPanel3 = new System.Windows.Forms.FlowLayoutPanel();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownNumofChil)).BeginInit();
            this.panelBioData.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel3.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.panelEducationalQualification.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownMasterGrade)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownGraduationGrade)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownIntermediateGrade)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownMatricGrade)).BeginInit();
            this.panelImage.SuspendLayout();
            this.flowLayoutPanel2.SuspendLayout();
            this.panelWorkingExperience.SuspendLayout();
            this.panelWorkerSchedule.SuspendLayout();
            this.panel6.SuspendLayout();
            this.flowLayoutPanel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // buttonAddWorkers
            // 
            this.buttonAddWorkers.BackColor = System.Drawing.Color.LightBlue;
            this.buttonAddWorkers.FlatAppearance.BorderSize = 0;
            this.buttonAddWorkers.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAddWorkers.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAddWorkers.Location = new System.Drawing.Point(1252, 664);
            this.buttonAddWorkers.Name = "buttonAddWorkers";
            this.buttonAddWorkers.Size = new System.Drawing.Size(198, 55);
            this.buttonAddWorkers.TabIndex = 13;
            this.buttonAddWorkers.Text = "Add";
            this.buttonAddWorkers.UseVisualStyleBackColor = false;
            this.buttonAddWorkers.Click += new System.EventHandler(this.buttonAddWorkers_Click);
            // 
            // numericUpDownNumofChil
            // 
            this.numericUpDownNumofChil.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.numericUpDownNumofChil.Enabled = false;
            this.numericUpDownNumofChil.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numericUpDownNumofChil.Location = new System.Drawing.Point(260, 384);
            this.numericUpDownNumofChil.Name = "numericUpDownNumofChil";
            this.numericUpDownNumofChil.Size = new System.Drawing.Size(97, 23);
            this.numericUpDownNumofChil.TabIndex = 30;
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(7, 386);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(215, 17);
            this.label6.TabIndex = 29;
            this.label6.Text = "Number of Children/Dependents:";
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(415, 418);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(72, 17);
            this.label5.TabIndex = 28;
            this.label5.Text = "Hire Date:";
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(301, 121);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 13);
            this.label4.TabIndex = 24;
            this.label4.Text = "LName";
            // 
            // textBoxLName
            // 
            this.textBoxLName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBoxLName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxLName.Location = new System.Drawing.Point(260, 93);
            this.textBoxLName.Name = "textBoxLName";
            this.textBoxLName.Size = new System.Drawing.Size(127, 23);
            this.textBoxLName.TabIndex = 22;
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(124, 182);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(98, 17);
            this.label2.TabIndex = 35;
            this.label2.Text = "Martial Status:";
            // 
            // comboBoxMartialStatus
            // 
            this.comboBoxMartialStatus.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBoxMartialStatus.AutoCompleteCustomSource.AddRange(new string[] {
            "Single",
            "Married",
            "Separated",
            "Divorced",
            "Windowed"});
            this.comboBoxMartialStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxMartialStatus.FormattingEnabled = true;
            this.comboBoxMartialStatus.Items.AddRange(new object[] {
            "Single",
            "Married",
            "Widowed",
            "Divorced",
            "Separated"});
            this.comboBoxMartialStatus.Location = new System.Drawing.Point(260, 179);
            this.comboBoxMartialStatus.Name = "comboBoxMartialStatus";
            this.comboBoxMartialStatus.Size = new System.Drawing.Size(127, 24);
            this.comboBoxMartialStatus.TabIndex = 36;
            this.comboBoxMartialStatus.Text = "(Selection)";
            this.comboBoxMartialStatus.SelectedIndexChanged += new System.EventHandler(this.comboBoxMartialStatus_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(393, 182);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 17);
            this.label3.TabIndex = 37;
            this.label3.Text = "Religion:";
            // 
            // textBoxAddress
            // 
            this.textBoxAddress.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBoxAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxAddress.Location = new System.Drawing.Point(260, 329);
            this.textBoxAddress.Multiline = true;
            this.textBoxAddress.Name = "textBoxAddress";
            this.textBoxAddress.Size = new System.Drawing.Size(393, 46);
            this.textBoxAddress.TabIndex = 40;
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(158, 332);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(64, 17);
            this.label8.TabIndex = 39;
            this.label8.Text = "Address:";
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(147, 63);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(75, 17);
            this.label9.TabIndex = 42;
            this.label9.Text = "Worker ID:";
            // 
            // textBoxWorkerID
            // 
            this.textBoxWorkerID.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBoxWorkerID.Enabled = false;
            this.textBoxWorkerID.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxWorkerID.Location = new System.Drawing.Point(260, 60);
            this.textBoxWorkerID.Name = "textBoxWorkerID";
            this.textBoxWorkerID.ReadOnly = true;
            this.textBoxWorkerID.Size = new System.Drawing.Size(221, 23);
            this.textBoxWorkerID.TabIndex = 41;
            // 
            // label10
            // 
            this.label10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(374, 387);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(114, 17);
            this.label10.TabIndex = 43;
            this.label10.Text = "Contact Number:";
            // 
            // dateTimePickerbirthdate
            // 
            this.dateTimePickerbirthdate.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dateTimePickerbirthdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePickerbirthdate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePickerbirthdate.Location = new System.Drawing.Point(260, 145);
            this.dateTimePickerbirthdate.Name = "dateTimePickerbirthdate";
            this.dateTimePickerbirthdate.Size = new System.Drawing.Size(221, 23);
            this.dateTimePickerbirthdate.TabIndex = 46;
            // 
            // label11
            // 
            this.label11.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(432, 121);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(41, 13);
            this.label11.TabIndex = 48;
            this.label11.Text = "FName";
            // 
            // textBoxFName
            // 
            this.textBoxFName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBoxFName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxFName.Location = new System.Drawing.Point(393, 93);
            this.textBoxFName.Name = "textBoxFName";
            this.textBoxFName.Size = new System.Drawing.Size(127, 23);
            this.textBoxFName.TabIndex = 47;
            // 
            // label12
            // 
            this.label12.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(563, 121);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(44, 13);
            this.label12.TabIndex = 50;
            this.label12.Text = "MName";
            // 
            // textBoxMName
            // 
            this.textBoxMName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBoxMName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxMName.Location = new System.Drawing.Point(526, 93);
            this.textBoxMName.Name = "textBoxMName";
            this.textBoxMName.Size = new System.Drawing.Size(127, 23);
            this.textBoxMName.TabIndex = 49;
            // 
            // label13
            // 
            this.label13.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(147, 150);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(75, 17);
            this.label13.TabIndex = 51;
            this.label13.Text = "Birth Date:";
            // 
            // label14
            // 
            this.label14.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(123, 96);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(99, 17);
            this.label14.TabIndex = 52;
            this.label14.Text = "Worker Name:";
            // 
            // label15
            // 
            this.label15.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(87, 418);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(135, 17);
            this.label15.TabIndex = 53;
            this.label15.Text = "Emergency Contact:";
            // 
            // panelBioData
            // 
            this.panelBioData.Controls.Add(this.textBoxMotherLName);
            this.panelBioData.Controls.Add(this.label43);
            this.panelBioData.Controls.Add(this.label44);
            this.panelBioData.Controls.Add(this.textBoxMotherMName);
            this.panelBioData.Controls.Add(this.label45);
            this.panelBioData.Controls.Add(this.textBoxMotherFName);
            this.panelBioData.Controls.Add(this.textBoxFatherLName);
            this.panelBioData.Controls.Add(this.label40);
            this.panelBioData.Controls.Add(this.label41);
            this.panelBioData.Controls.Add(this.textBoxFatherMName);
            this.panelBioData.Controls.Add(this.label42);
            this.panelBioData.Controls.Add(this.textBoxFatherFName);
            this.panelBioData.Controls.Add(this.label7);
            this.panelBioData.Controls.Add(this.label39);
            this.panelBioData.Controls.Add(this.comboBoxReligion);
            this.panelBioData.Controls.Add(this.label21);
            this.panelBioData.Controls.Add(this.maskedTextBoxEmergencyContact);
            this.panelBioData.Controls.Add(this.maskedTextBoxContactNum);
            this.panelBioData.Controls.Add(this.textBoxHireDate);
            this.panelBioData.Controls.Add(this.label5);
            this.panelBioData.Controls.Add(this.label15);
            this.panelBioData.Controls.Add(this.textBoxLName);
            this.panelBioData.Controls.Add(this.label14);
            this.panelBioData.Controls.Add(this.label4);
            this.panelBioData.Controls.Add(this.label13);
            this.panelBioData.Controls.Add(this.label6);
            this.panelBioData.Controls.Add(this.label12);
            this.panelBioData.Controls.Add(this.numericUpDownNumofChil);
            this.panelBioData.Controls.Add(this.textBoxMName);
            this.panelBioData.Controls.Add(this.label11);
            this.panelBioData.Controls.Add(this.textBoxFName);
            this.panelBioData.Controls.Add(this.label2);
            this.panelBioData.Controls.Add(this.dateTimePickerbirthdate);
            this.panelBioData.Controls.Add(this.comboBoxMartialStatus);
            this.panelBioData.Controls.Add(this.label3);
            this.panelBioData.Controls.Add(this.label10);
            this.panelBioData.Controls.Add(this.label8);
            this.panelBioData.Controls.Add(this.label9);
            this.panelBioData.Controls.Add(this.textBoxAddress);
            this.panelBioData.Controls.Add(this.textBoxWorkerID);
            this.panelBioData.Location = new System.Drawing.Point(3, 3);
            this.panelBioData.Name = "panelBioData";
            this.panelBioData.Size = new System.Drawing.Size(661, 453);
            this.panelBioData.TabIndex = 0;
            // 
            // textBoxMotherLName
            // 
            this.textBoxMotherLName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBoxMotherLName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxMotherLName.Location = new System.Drawing.Point(260, 273);
            this.textBoxMotherLName.Name = "textBoxMotherLName";
            this.textBoxMotherLName.Size = new System.Drawing.Size(127, 23);
            this.textBoxMotherLName.TabIndex = 72;
            // 
            // label43
            // 
            this.label43.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(301, 301);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(41, 13);
            this.label43.TabIndex = 73;
            this.label43.Text = "LName";
            // 
            // label44
            // 
            this.label44.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.Location = new System.Drawing.Point(563, 301);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(44, 13);
            this.label44.TabIndex = 77;
            this.label44.Text = "MName";
            // 
            // textBoxMotherMName
            // 
            this.textBoxMotherMName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBoxMotherMName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxMotherMName.Location = new System.Drawing.Point(526, 273);
            this.textBoxMotherMName.Name = "textBoxMotherMName";
            this.textBoxMotherMName.Size = new System.Drawing.Size(127, 23);
            this.textBoxMotherMName.TabIndex = 76;
            // 
            // label45
            // 
            this.label45.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.Location = new System.Drawing.Point(432, 301);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(41, 13);
            this.label45.TabIndex = 75;
            this.label45.Text = "FName";
            // 
            // textBoxMotherFName
            // 
            this.textBoxMotherFName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBoxMotherFName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxMotherFName.Location = new System.Drawing.Point(393, 273);
            this.textBoxMotherFName.Name = "textBoxMotherFName";
            this.textBoxMotherFName.Size = new System.Drawing.Size(127, 23);
            this.textBoxMotherFName.TabIndex = 74;
            // 
            // textBoxFatherLName
            // 
            this.textBoxFatherLName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBoxFatherLName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxFatherLName.Location = new System.Drawing.Point(260, 214);
            this.textBoxFatherLName.Name = "textBoxFatherLName";
            this.textBoxFatherLName.Size = new System.Drawing.Size(127, 23);
            this.textBoxFatherLName.TabIndex = 66;
            // 
            // label40
            // 
            this.label40.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(301, 242);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(41, 13);
            this.label40.TabIndex = 67;
            this.label40.Text = "LName";
            // 
            // label41
            // 
            this.label41.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(563, 242);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(44, 13);
            this.label41.TabIndex = 71;
            this.label41.Text = "MName";
            // 
            // textBoxFatherMName
            // 
            this.textBoxFatherMName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBoxFatherMName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxFatherMName.Location = new System.Drawing.Point(526, 214);
            this.textBoxFatherMName.Name = "textBoxFatherMName";
            this.textBoxFatherMName.Size = new System.Drawing.Size(127, 23);
            this.textBoxFatherMName.TabIndex = 70;
            // 
            // label42
            // 
            this.label42.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.Location = new System.Drawing.Point(432, 242);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(41, 13);
            this.label42.TabIndex = 69;
            this.label42.Text = "FName";
            // 
            // textBoxFatherFName
            // 
            this.textBoxFatherFName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBoxFatherFName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxFatherFName.Location = new System.Drawing.Point(393, 214);
            this.textBoxFatherFName.Name = "textBoxFatherFName";
            this.textBoxFatherFName.Size = new System.Drawing.Size(127, 23);
            this.textBoxFatherFName.TabIndex = 68;
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(125, 276);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(97, 17);
            this.label7.TabIndex = 65;
            this.label7.Text = "Mother Name:";
            // 
            // label39
            // 
            this.label39.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(128, 217);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(94, 17);
            this.label39.TabIndex = 64;
            this.label39.Text = "Father Name:";
            // 
            // comboBoxReligion
            // 
            this.comboBoxReligion.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBoxReligion.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxReligion.FormattingEnabled = true;
            this.comboBoxReligion.Items.AddRange(new object[] {
            "Christianity",
            "Islam",
            "Bathalism",
            "Baháʼí Faith"});
            this.comboBoxReligion.Location = new System.Drawing.Point(462, 179);
            this.comboBoxReligion.Name = "comboBoxReligion";
            this.comboBoxReligion.Size = new System.Drawing.Size(127, 24);
            this.comboBoxReligion.TabIndex = 62;
            this.comboBoxReligion.Text = "(Selection)";
            this.comboBoxReligion.SelectedIndexChanged += new System.EventHandler(this.comboBoxReligion_SelectedIndexChanged);
            // 
            // label21
            // 
            this.label21.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(103, 21);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(119, 20);
            this.label21.TabIndex = 61;
            this.label21.Text = "Worker Biodata";
            // 
            // maskedTextBoxEmergencyContact
            // 
            this.maskedTextBoxEmergencyContact.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.maskedTextBoxEmergencyContact.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maskedTextBoxEmergencyContact.Location = new System.Drawing.Point(260, 415);
            this.maskedTextBoxEmergencyContact.Mask = "(999) 000-0000";
            this.maskedTextBoxEmergencyContact.Name = "maskedTextBoxEmergencyContact";
            this.maskedTextBoxEmergencyContact.Size = new System.Drawing.Size(97, 23);
            this.maskedTextBoxEmergencyContact.TabIndex = 59;
            // 
            // maskedTextBoxContactNum
            // 
            this.maskedTextBoxContactNum.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.maskedTextBoxContactNum.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maskedTextBoxContactNum.Location = new System.Drawing.Point(526, 384);
            this.maskedTextBoxContactNum.Mask = "(999) 000-0000";
            this.maskedTextBoxContactNum.Name = "maskedTextBoxContactNum";
            this.maskedTextBoxContactNum.Size = new System.Drawing.Size(97, 23);
            this.maskedTextBoxContactNum.TabIndex = 58;
            // 
            // textBoxHireDate
            // 
            this.textBoxHireDate.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBoxHireDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxHireDate.Location = new System.Drawing.Point(525, 415);
            this.textBoxHireDate.Name = "textBoxHireDate";
            this.textBoxHireDate.ReadOnly = true;
            this.textBoxHireDate.Size = new System.Drawing.Size(97, 23);
            this.textBoxHireDate.TabIndex = 55;
            // 
            // comboBoxYearHire
            // 
            this.comboBoxYearHire.FormattingEnabled = true;
            this.comboBoxYearHire.Location = new System.Drawing.Point(260, 128);
            this.comboBoxYearHire.Name = "comboBoxYearHire";
            this.comboBoxYearHire.Size = new System.Drawing.Size(221, 21);
            this.comboBoxYearHire.TabIndex = 78;
            // 
            // label16
            // 
            this.label16.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(72, 24);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(150, 20);
            this.label16.TabIndex = 51;
            this.label16.Text = "Working Experience";
            // 
            // label17
            // 
            this.label17.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(94, 72);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(128, 17);
            this.label17.TabIndex = 54;
            this.label17.Text = "Name of Company:";
            // 
            // textBoxReference
            // 
            this.textBoxReference.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBoxReference.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxReference.Location = new System.Drawing.Point(260, 155);
            this.textBoxReference.Multiline = true;
            this.textBoxReference.Name = "textBoxReference";
            this.textBoxReference.Size = new System.Drawing.Size(221, 60);
            this.textBoxReference.TabIndex = 59;
            // 
            // textBoxNameOfCompany
            // 
            this.textBoxNameOfCompany.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBoxNameOfCompany.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxNameOfCompany.Location = new System.Drawing.Point(260, 69);
            this.textBoxNameOfCompany.Name = "textBoxNameOfCompany";
            this.textBoxNameOfCompany.Size = new System.Drawing.Size(221, 23);
            this.textBoxNameOfCompany.TabIndex = 53;
            // 
            // label20
            // 
            this.label20.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(144, 158);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(78, 17);
            this.label20.TabIndex = 60;
            this.label20.Text = "Reference:";
            // 
            // label18
            // 
            this.label18.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(160, 102);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(62, 17);
            this.label18.TabIndex = 56;
            this.label18.Text = "Position:";
            // 
            // textBoxPosition
            // 
            this.textBoxPosition.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBoxPosition.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxPosition.Location = new System.Drawing.Point(260, 99);
            this.textBoxPosition.Name = "textBoxPosition";
            this.textBoxPosition.Size = new System.Drawing.Size(221, 23);
            this.textBoxPosition.TabIndex = 55;
            // 
            // label19
            // 
            this.label19.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(150, 129);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(72, 17);
            this.label19.TabIndex = 58;
            this.label19.Text = "Year Hire:";
            // 
            // buttonFileUpload
            // 
            this.buttonFileUpload.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonFileUpload.BackColor = System.Drawing.Color.LightBlue;
            this.buttonFileUpload.FlatAppearance.BorderSize = 0;
            this.buttonFileUpload.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonFileUpload.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonFileUpload.ForeColor = System.Drawing.Color.Black;
            this.buttonFileUpload.Location = new System.Drawing.Point(167, 134);
            this.buttonFileUpload.Name = "buttonFileUpload";
            this.buttonFileUpload.Size = new System.Drawing.Size(70, 31);
            this.buttonFileUpload.TabIndex = 57;
            this.buttonFileUpload.Text = "Upload";
            this.buttonFileUpload.UseVisualStyleBackColor = false;
            this.buttonFileUpload.Click += new System.EventHandler(this.buttonFileUpload_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox1.Location = new System.Drawing.Point(147, 18);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(110, 110);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 56;
            this.pictureBox1.TabStop = false;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Blue;
            this.panel3.Controls.Add(this.label1);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1082, 52);
            this.panel3.TabIndex = 57;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(156, 31);
            this.label1.TabIndex = 43;
            this.label1.Text = "Add Worker";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.AutoScroll = true;
            this.flowLayoutPanel1.Controls.Add(this.panelEducationalQualification);
            this.flowLayoutPanel1.Location = new System.Drawing.Point(3, 184);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(391, 389);
            this.flowLayoutPanel1.TabIndex = 63;
            // 
            // panelEducationalQualification
            // 
            this.panelEducationalQualification.Controls.Add(this.label35);
            this.panelEducationalQualification.Controls.Add(this.comboBoxMasterYearPassed);
            this.panelEducationalQualification.Controls.Add(this.label36);
            this.panelEducationalQualification.Controls.Add(this.label37);
            this.panelEducationalQualification.Controls.Add(this.numericUpDownMasterGrade);
            this.panelEducationalQualification.Controls.Add(this.textBoxMasterName);
            this.panelEducationalQualification.Controls.Add(this.label38);
            this.panelEducationalQualification.Controls.Add(this.label31);
            this.panelEducationalQualification.Controls.Add(this.comboBoxGraduationYearPassed);
            this.panelEducationalQualification.Controls.Add(this.label32);
            this.panelEducationalQualification.Controls.Add(this.label33);
            this.panelEducationalQualification.Controls.Add(this.numericUpDownGraduationGrade);
            this.panelEducationalQualification.Controls.Add(this.textBoxGraduationName);
            this.panelEducationalQualification.Controls.Add(this.label34);
            this.panelEducationalQualification.Controls.Add(this.label30);
            this.panelEducationalQualification.Controls.Add(this.comboBoxIntermediateYearPassed);
            this.panelEducationalQualification.Controls.Add(this.label27);
            this.panelEducationalQualification.Controls.Add(this.label28);
            this.panelEducationalQualification.Controls.Add(this.numericUpDownIntermediateGrade);
            this.panelEducationalQualification.Controls.Add(this.textBoxIntermediateName);
            this.panelEducationalQualification.Controls.Add(this.label29);
            this.panelEducationalQualification.Controls.Add(this.comboBoxMatricYearPassed);
            this.panelEducationalQualification.Controls.Add(this.label26);
            this.panelEducationalQualification.Controls.Add(this.label25);
            this.panelEducationalQualification.Controls.Add(this.numericUpDownMatricGrade);
            this.panelEducationalQualification.Controls.Add(this.label24);
            this.panelEducationalQualification.Controls.Add(this.label23);
            this.panelEducationalQualification.Controls.Add(this.textBoxMatricName);
            this.panelEducationalQualification.Controls.Add(this.label22);
            this.panelEducationalQualification.Location = new System.Drawing.Point(3, 3);
            this.panelEducationalQualification.Name = "panelEducationalQualification";
            this.panelEducationalQualification.Size = new System.Drawing.Size(367, 490);
            this.panelEducationalQualification.TabIndex = 62;
            // 
            // label35
            // 
            this.label35.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(50, 379);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(51, 17);
            this.label35.TabIndex = 92;
            this.label35.Text = "Master";
            // 
            // comboBoxMasterYearPassed
            // 
            this.comboBoxMasterYearPassed.FormattingEnabled = true;
            this.comboBoxMasterYearPassed.Location = new System.Drawing.Point(287, 436);
            this.comboBoxMasterYearPassed.Name = "comboBoxMasterYearPassed";
            this.comboBoxMasterYearPassed.Size = new System.Drawing.Size(55, 21);
            this.comboBoxMasterYearPassed.TabIndex = 91;
            // 
            // label36
            // 
            this.label36.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(63, 438);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(52, 17);
            this.label36.TabIndex = 90;
            this.label36.Text = "Grade:";
            // 
            // label37
            // 
            this.label37.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(188, 438);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(93, 17);
            this.label37.TabIndex = 89;
            this.label37.Text = "Year Passed:";
            // 
            // numericUpDownMasterGrade
            // 
            this.numericUpDownMasterGrade.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numericUpDownMasterGrade.Location = new System.Drawing.Point(121, 435);
            this.numericUpDownMasterGrade.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownMasterGrade.Name = "numericUpDownMasterGrade";
            this.numericUpDownMasterGrade.Size = new System.Drawing.Size(49, 23);
            this.numericUpDownMasterGrade.TabIndex = 88;
            this.numericUpDownMasterGrade.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // textBoxMasterName
            // 
            this.textBoxMasterName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBoxMasterName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxMasterName.Location = new System.Drawing.Point(121, 407);
            this.textBoxMasterName.Name = "textBoxMasterName";
            this.textBoxMasterName.Size = new System.Drawing.Size(221, 23);
            this.textBoxMasterName.TabIndex = 86;
            // 
            // label38
            // 
            this.label38.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(66, 410);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(49, 17);
            this.label38.TabIndex = 87;
            this.label38.Text = "Name:";
            // 
            // label31
            // 
            this.label31.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(50, 274);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(79, 17);
            this.label31.TabIndex = 85;
            this.label31.Text = "Graduation";
            // 
            // comboBoxGraduationYearPassed
            // 
            this.comboBoxGraduationYearPassed.FormattingEnabled = true;
            this.comboBoxGraduationYearPassed.Location = new System.Drawing.Point(287, 331);
            this.comboBoxGraduationYearPassed.Name = "comboBoxGraduationYearPassed";
            this.comboBoxGraduationYearPassed.Size = new System.Drawing.Size(55, 21);
            this.comboBoxGraduationYearPassed.TabIndex = 84;
            // 
            // label32
            // 
            this.label32.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(63, 333);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(52, 17);
            this.label32.TabIndex = 83;
            this.label32.Text = "Grade:";
            // 
            // label33
            // 
            this.label33.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(188, 333);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(93, 17);
            this.label33.TabIndex = 82;
            this.label33.Text = "Year Passed:";
            // 
            // numericUpDownGraduationGrade
            // 
            this.numericUpDownGraduationGrade.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numericUpDownGraduationGrade.Location = new System.Drawing.Point(121, 330);
            this.numericUpDownGraduationGrade.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownGraduationGrade.Name = "numericUpDownGraduationGrade";
            this.numericUpDownGraduationGrade.Size = new System.Drawing.Size(49, 23);
            this.numericUpDownGraduationGrade.TabIndex = 81;
            this.numericUpDownGraduationGrade.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // textBoxGraduationName
            // 
            this.textBoxGraduationName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBoxGraduationName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxGraduationName.Location = new System.Drawing.Point(121, 302);
            this.textBoxGraduationName.Name = "textBoxGraduationName";
            this.textBoxGraduationName.Size = new System.Drawing.Size(221, 23);
            this.textBoxGraduationName.TabIndex = 79;
            // 
            // label34
            // 
            this.label34.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(66, 305);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(49, 17);
            this.label34.TabIndex = 80;
            this.label34.Text = "Name:";
            // 
            // label30
            // 
            this.label30.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(50, 174);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(86, 17);
            this.label30.TabIndex = 78;
            this.label30.Text = "Intermediate";
            // 
            // comboBoxIntermediateYearPassed
            // 
            this.comboBoxIntermediateYearPassed.FormattingEnabled = true;
            this.comboBoxIntermediateYearPassed.Location = new System.Drawing.Point(287, 231);
            this.comboBoxIntermediateYearPassed.Name = "comboBoxIntermediateYearPassed";
            this.comboBoxIntermediateYearPassed.Size = new System.Drawing.Size(55, 21);
            this.comboBoxIntermediateYearPassed.TabIndex = 77;
            // 
            // label27
            // 
            this.label27.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(63, 233);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(52, 17);
            this.label27.TabIndex = 76;
            this.label27.Text = "Grade:";
            // 
            // label28
            // 
            this.label28.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(188, 233);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(93, 17);
            this.label28.TabIndex = 75;
            this.label28.Text = "Year Passed:";
            // 
            // numericUpDownIntermediateGrade
            // 
            this.numericUpDownIntermediateGrade.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numericUpDownIntermediateGrade.Location = new System.Drawing.Point(121, 230);
            this.numericUpDownIntermediateGrade.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownIntermediateGrade.Name = "numericUpDownIntermediateGrade";
            this.numericUpDownIntermediateGrade.Size = new System.Drawing.Size(49, 23);
            this.numericUpDownIntermediateGrade.TabIndex = 74;
            this.numericUpDownIntermediateGrade.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // textBoxIntermediateName
            // 
            this.textBoxIntermediateName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBoxIntermediateName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxIntermediateName.Location = new System.Drawing.Point(121, 202);
            this.textBoxIntermediateName.Name = "textBoxIntermediateName";
            this.textBoxIntermediateName.Size = new System.Drawing.Size(221, 23);
            this.textBoxIntermediateName.TabIndex = 72;
            // 
            // label29
            // 
            this.label29.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(66, 205);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(49, 17);
            this.label29.TabIndex = 73;
            this.label29.Text = "Name:";
            // 
            // comboBoxMatricYearPassed
            // 
            this.comboBoxMatricYearPassed.FormattingEnabled = true;
            this.comboBoxMatricYearPassed.Location = new System.Drawing.Point(287, 135);
            this.comboBoxMatricYearPassed.Name = "comboBoxMatricYearPassed";
            this.comboBoxMatricYearPassed.Size = new System.Drawing.Size(55, 21);
            this.comboBoxMatricYearPassed.TabIndex = 71;
            // 
            // label26
            // 
            this.label26.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(63, 137);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(52, 17);
            this.label26.TabIndex = 70;
            this.label26.Text = "Grade:";
            // 
            // label25
            // 
            this.label25.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(188, 137);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(93, 17);
            this.label25.TabIndex = 69;
            this.label25.Text = "Year Passed:";
            // 
            // numericUpDownMatricGrade
            // 
            this.numericUpDownMatricGrade.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numericUpDownMatricGrade.Location = new System.Drawing.Point(121, 134);
            this.numericUpDownMatricGrade.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownMatricGrade.Name = "numericUpDownMatricGrade";
            this.numericUpDownMatricGrade.Size = new System.Drawing.Size(49, 23);
            this.numericUpDownMatricGrade.TabIndex = 68;
            this.numericUpDownMatricGrade.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label24
            // 
            this.label24.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(50, 74);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(46, 17);
            this.label24.TabIndex = 67;
            this.label24.Text = "Matric";
            // 
            // label23
            // 
            this.label23.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(25, 33);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(184, 20);
            this.label23.TabIndex = 66;
            this.label23.Text = "Educational Qualification";
            // 
            // textBoxMatricName
            // 
            this.textBoxMatricName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBoxMatricName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxMatricName.Location = new System.Drawing.Point(121, 106);
            this.textBoxMatricName.Name = "textBoxMatricName";
            this.textBoxMatricName.Size = new System.Drawing.Size(221, 23);
            this.textBoxMatricName.TabIndex = 64;
            // 
            // label22
            // 
            this.label22.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(66, 109);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(49, 17);
            this.label22.TabIndex = 65;
            this.label22.Text = "Name:";
            // 
            // panelImage
            // 
            this.panelImage.Controls.Add(this.pictureBox1);
            this.panelImage.Controls.Add(this.buttonFileUpload);
            this.panelImage.Location = new System.Drawing.Point(3, 3);
            this.panelImage.Name = "panelImage";
            this.panelImage.Size = new System.Drawing.Size(391, 175);
            this.panelImage.TabIndex = 61;
            // 
            // flowLayoutPanel2
            // 
            this.flowLayoutPanel2.AutoScroll = true;
            this.flowLayoutPanel2.Controls.Add(this.panelBioData);
            this.flowLayoutPanel2.Controls.Add(this.panelWorkingExperience);
            this.flowLayoutPanel2.Controls.Add(this.panelWorkerSchedule);
            this.flowLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.flowLayoutPanel2.Location = new System.Drawing.Point(0, 52);
            this.flowLayoutPanel2.Name = "flowLayoutPanel2";
            this.flowLayoutPanel2.Size = new System.Drawing.Size(685, 645);
            this.flowLayoutPanel2.TabIndex = 60;
            // 
            // panelWorkingExperience
            // 
            this.panelWorkingExperience.Controls.Add(this.label16);
            this.panelWorkingExperience.Controls.Add(this.comboBoxYearHire);
            this.panelWorkingExperience.Controls.Add(this.label19);
            this.panelWorkingExperience.Controls.Add(this.textBoxPosition);
            this.panelWorkingExperience.Controls.Add(this.label18);
            this.panelWorkingExperience.Controls.Add(this.label20);
            this.panelWorkingExperience.Controls.Add(this.textBoxNameOfCompany);
            this.panelWorkingExperience.Controls.Add(this.textBoxReference);
            this.panelWorkingExperience.Controls.Add(this.label17);
            this.panelWorkingExperience.Location = new System.Drawing.Point(3, 462);
            this.panelWorkingExperience.Name = "panelWorkingExperience";
            this.panelWorkingExperience.Size = new System.Drawing.Size(661, 241);
            this.panelWorkingExperience.TabIndex = 79;
            // 
            // panelWorkerSchedule
            // 
            this.panelWorkerSchedule.Controls.Add(this.dateTimePickerSunday);
            this.panelWorkerSchedule.Controls.Add(this.dateTimePickerSaturday);
            this.panelWorkerSchedule.Controls.Add(this.dateTimePickerFriday);
            this.panelWorkerSchedule.Controls.Add(this.dateTimePickerThursday);
            this.panelWorkerSchedule.Controls.Add(this.dateTimePickerWednesday);
            this.panelWorkerSchedule.Controls.Add(this.dateTimePickerTuesday);
            this.panelWorkerSchedule.Controls.Add(this.dateTimePickerMonday);
            this.panelWorkerSchedule.Controls.Add(this.label51);
            this.panelWorkerSchedule.Controls.Add(this.label52);
            this.panelWorkerSchedule.Controls.Add(this.label54);
            this.panelWorkerSchedule.Controls.Add(this.label47);
            this.panelWorkerSchedule.Controls.Add(this.label48);
            this.panelWorkerSchedule.Controls.Add(this.label49);
            this.panelWorkerSchedule.Controls.Add(this.label50);
            this.panelWorkerSchedule.Controls.Add(this.label46);
            this.panelWorkerSchedule.Location = new System.Drawing.Point(3, 709);
            this.panelWorkerSchedule.Name = "panelWorkerSchedule";
            this.panelWorkerSchedule.Size = new System.Drawing.Size(661, 311);
            this.panelWorkerSchedule.TabIndex = 80;
            this.panelWorkerSchedule.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // dateTimePickerSunday
            // 
            this.dateTimePickerSunday.CustomFormat = "hh:mm tt";
            this.dateTimePickerSunday.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePickerSunday.Location = new System.Drawing.Point(260, 250);
            this.dateTimePickerSunday.Name = "dateTimePickerSunday";
            this.dateTimePickerSunday.Size = new System.Drawing.Size(139, 20);
            this.dateTimePickerSunday.TabIndex = 74;
            // 
            // dateTimePickerSaturday
            // 
            this.dateTimePickerSaturday.CustomFormat = "hh:mm tt";
            this.dateTimePickerSaturday.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePickerSaturday.Location = new System.Drawing.Point(260, 222);
            this.dateTimePickerSaturday.Name = "dateTimePickerSaturday";
            this.dateTimePickerSaturday.Size = new System.Drawing.Size(139, 20);
            this.dateTimePickerSaturday.TabIndex = 73;
            // 
            // dateTimePickerFriday
            // 
            this.dateTimePickerFriday.CustomFormat = "hh:mm tt";
            this.dateTimePickerFriday.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePickerFriday.Location = new System.Drawing.Point(260, 195);
            this.dateTimePickerFriday.Name = "dateTimePickerFriday";
            this.dateTimePickerFriday.Size = new System.Drawing.Size(139, 20);
            this.dateTimePickerFriday.TabIndex = 72;
            // 
            // dateTimePickerThursday
            // 
            this.dateTimePickerThursday.CustomFormat = "hh:mm tt";
            this.dateTimePickerThursday.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePickerThursday.Location = new System.Drawing.Point(260, 168);
            this.dateTimePickerThursday.Name = "dateTimePickerThursday";
            this.dateTimePickerThursday.Size = new System.Drawing.Size(139, 20);
            this.dateTimePickerThursday.TabIndex = 71;
            // 
            // dateTimePickerWednesday
            // 
            this.dateTimePickerWednesday.CustomFormat = "hh:mm tt";
            this.dateTimePickerWednesday.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePickerWednesday.Location = new System.Drawing.Point(260, 141);
            this.dateTimePickerWednesday.Name = "dateTimePickerWednesday";
            this.dateTimePickerWednesday.Size = new System.Drawing.Size(139, 20);
            this.dateTimePickerWednesday.TabIndex = 70;
            // 
            // dateTimePickerTuesday
            // 
            this.dateTimePickerTuesday.CustomFormat = "hh:mm tt";
            this.dateTimePickerTuesday.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePickerTuesday.Location = new System.Drawing.Point(260, 114);
            this.dateTimePickerTuesday.Name = "dateTimePickerTuesday";
            this.dateTimePickerTuesday.Size = new System.Drawing.Size(139, 20);
            this.dateTimePickerTuesday.TabIndex = 69;
            // 
            // dateTimePickerMonday
            // 
            this.dateTimePickerMonday.CustomFormat = "hh:mm tt";
            this.dateTimePickerMonday.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePickerMonday.Location = new System.Drawing.Point(260, 88);
            this.dateTimePickerMonday.Name = "dateTimePickerMonday";
            this.dateTimePickerMonday.Size = new System.Drawing.Size(139, 20);
            this.dateTimePickerMonday.TabIndex = 68;
            // 
            // label51
            // 
            this.label51.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label51.Location = new System.Drawing.Point(162, 254);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(60, 17);
            this.label51.TabIndex = 67;
            this.label51.Text = "Sunday:";
            // 
            // label52
            // 
            this.label52.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label52.Location = new System.Drawing.Point(153, 226);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(69, 17);
            this.label52.TabIndex = 66;
            this.label52.Text = "Saturday:";
            // 
            // label54
            // 
            this.label54.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label54.AutoSize = true;
            this.label54.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label54.Location = new System.Drawing.Point(171, 199);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(51, 17);
            this.label54.TabIndex = 65;
            this.label54.Text = "Friday:";
            // 
            // label47
            // 
            this.label47.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.Location = new System.Drawing.Point(135, 145);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(87, 17);
            this.label47.TabIndex = 63;
            this.label47.Text = "Wednesday:";
            // 
            // label48
            // 
            this.label48.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label48.Location = new System.Drawing.Point(155, 118);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(67, 17);
            this.label48.TabIndex = 62;
            this.label48.Text = "Tuesday:";
            // 
            // label49
            // 
            this.label49.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label49.Location = new System.Drawing.Point(150, 172);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(72, 17);
            this.label49.TabIndex = 64;
            this.label49.Text = "Thursday:";
            // 
            // label50
            // 
            this.label50.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label50.Location = new System.Drawing.Point(160, 92);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(62, 17);
            this.label50.TabIndex = 61;
            this.label50.Text = "Monday:";
            // 
            // label46
            // 
            this.label46.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.Location = new System.Drawing.Point(91, 37);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(131, 20);
            this.label46.TabIndex = 51;
            this.label46.Text = "Worker Schedule";
            // 
            // buttonAddWorker
            // 
            this.buttonAddWorker.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonAddWorker.BackColor = System.Drawing.Color.LightBlue;
            this.buttonAddWorker.FlatAppearance.BorderSize = 0;
            this.buttonAddWorker.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAddWorker.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAddWorker.Location = new System.Drawing.Point(123, 12);
            this.buttonAddWorker.Name = "buttonAddWorker";
            this.buttonAddWorker.Size = new System.Drawing.Size(243, 44);
            this.buttonAddWorker.TabIndex = 58;
            this.buttonAddWorker.Text = "Add Worker";
            this.buttonAddWorker.UseVisualStyleBackColor = false;
            this.buttonAddWorker.Click += new System.EventHandler(this.buttonAddWorker_Click);
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.buttonAddWorker);
            this.panel6.Location = new System.Drawing.Point(3, 579);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(391, 63);
            this.panel6.TabIndex = 62;
            // 
            // flowLayoutPanel3
            // 
            this.flowLayoutPanel3.Controls.Add(this.panelImage);
            this.flowLayoutPanel3.Controls.Add(this.flowLayoutPanel1);
            this.flowLayoutPanel3.Controls.Add(this.panel6);
            this.flowLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Right;
            this.flowLayoutPanel3.Location = new System.Drawing.Point(685, 52);
            this.flowLayoutPanel3.Name = "flowLayoutPanel3";
            this.flowLayoutPanel3.Size = new System.Drawing.Size(397, 645);
            this.flowLayoutPanel3.TabIndex = 61;
            // 
            // FormWorkersAdd
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1082, 697);
            this.Controls.Add(this.flowLayoutPanel3);
            this.Controls.Add(this.flowLayoutPanel2);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.buttonAddWorkers);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormWorkersAdd";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.FormAddWorkers_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownNumofChil)).EndInit();
            this.panelBioData.ResumeLayout(false);
            this.panelBioData.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.flowLayoutPanel1.ResumeLayout(false);
            this.panelEducationalQualification.ResumeLayout(false);
            this.panelEducationalQualification.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownMasterGrade)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownGraduationGrade)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownIntermediateGrade)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownMatricGrade)).EndInit();
            this.panelImage.ResumeLayout(false);
            this.flowLayoutPanel2.ResumeLayout(false);
            this.panelWorkingExperience.ResumeLayout(false);
            this.panelWorkingExperience.PerformLayout();
            this.panelWorkerSchedule.ResumeLayout(false);
            this.panelWorkerSchedule.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.flowLayoutPanel3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button buttonAddWorkers;
        private System.Windows.Forms.NumericUpDown numericUpDownNumofChil;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxLName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox comboBoxMartialStatus;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxAddress;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBoxWorkerID;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.DateTimePicker dateTimePickerbirthdate;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBoxFName;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBoxMName;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Panel panelBioData;
        private System.Windows.Forms.TextBox textBoxHireDate;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button buttonFileUpload;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.MaskedTextBox maskedTextBoxContactNum;
        private System.Windows.Forms.MaskedTextBox maskedTextBoxEmergencyContact;
        private System.Windows.Forms.Panel panelImage;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox textBoxReference;
        private System.Windows.Forms.TextBox textBoxNameOfCompany;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox textBoxPosition;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Panel panelEducationalQualification;
        private System.Windows.Forms.ComboBox comboBoxReligion;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.ComboBox comboBoxMasterYearPassed;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.NumericUpDown numericUpDownMasterGrade;
        private System.Windows.Forms.TextBox textBoxMasterName;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.ComboBox comboBoxGraduationYearPassed;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.NumericUpDown numericUpDownGraduationGrade;
        private System.Windows.Forms.TextBox textBoxGraduationName;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.ComboBox comboBoxIntermediateYearPassed;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.NumericUpDown numericUpDownIntermediateGrade;
        private System.Windows.Forms.TextBox textBoxIntermediateName;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.ComboBox comboBoxMatricYearPassed;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.NumericUpDown numericUpDownMatricGrade;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox textBoxMatricName;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBoxFatherLName;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TextBox textBoxFatherMName;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.TextBox textBoxFatherFName;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel2;
        private System.Windows.Forms.Button buttonAddWorker;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel3;
        private System.Windows.Forms.TextBox textBoxMotherLName;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.TextBox textBoxMotherMName;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.TextBox textBoxMotherFName;
        private System.Windows.Forms.ComboBox comboBoxYearHire;
        private System.Windows.Forms.Panel panelWorkingExperience;
        private System.Windows.Forms.Panel panelWorkerSchedule;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.DateTimePicker dateTimePickerSunday;
        private System.Windows.Forms.DateTimePicker dateTimePickerSaturday;
        private System.Windows.Forms.DateTimePicker dateTimePickerFriday;
        private System.Windows.Forms.DateTimePicker dateTimePickerThursday;
        private System.Windows.Forms.DateTimePicker dateTimePickerWednesday;
        private System.Windows.Forms.DateTimePicker dateTimePickerTuesday;
        private System.Windows.Forms.DateTimePicker dateTimePickerMonday;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label50;
    }
}