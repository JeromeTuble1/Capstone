﻿namespace QRCodeDemo
{
    partial class FormLeaveSelection
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonViewLeave = new System.Windows.Forms.Button();
            this.buttonAddLeave = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // buttonViewLeave
            // 
            this.buttonViewLeave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.buttonViewLeave.FlatAppearance.BorderSize = 0;
            this.buttonViewLeave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonViewLeave.Font = new System.Drawing.Font("Segoe UI Symbol", 12F, System.Drawing.FontStyle.Bold);
            this.buttonViewLeave.ForeColor = System.Drawing.Color.White;
            this.buttonViewLeave.Location = new System.Drawing.Point(19, 74);
            this.buttonViewLeave.Name = "buttonViewLeave";
            this.buttonViewLeave.Size = new System.Drawing.Size(212, 42);
            this.buttonViewLeave.TabIndex = 3;
            this.buttonViewLeave.Text = "View Leave";
            this.buttonViewLeave.UseVisualStyleBackColor = false;
            this.buttonViewLeave.Click += new System.EventHandler(this.buttonViewLeave_Click);
            // 
            // buttonAddLeave
            // 
            this.buttonAddLeave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.buttonAddLeave.FlatAppearance.BorderSize = 0;
            this.buttonAddLeave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAddLeave.Font = new System.Drawing.Font("Segoe UI Symbol", 12F, System.Drawing.FontStyle.Bold);
            this.buttonAddLeave.ForeColor = System.Drawing.Color.White;
            this.buttonAddLeave.Location = new System.Drawing.Point(19, 22);
            this.buttonAddLeave.Name = "buttonAddLeave";
            this.buttonAddLeave.Size = new System.Drawing.Size(212, 42);
            this.buttonAddLeave.TabIndex = 2;
            this.buttonAddLeave.Text = "Add Leave";
            this.buttonAddLeave.UseVisualStyleBackColor = false;
            this.buttonAddLeave.Click += new System.EventHandler(this.buttonAddLeave_Click);
            // 
            // FormLeaveSelection
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(250, 135);
            this.Controls.Add(this.buttonViewLeave);
            this.Controls.Add(this.buttonAddLeave);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormLeaveSelection";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Leave Selection";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button buttonViewLeave;
        private System.Windows.Forms.Button buttonAddLeave;
    }
}