﻿namespace QRCodeDemo
{
    partial class FormAttendanceEmployeeReport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.comboBoxSelectCategory = new System.Windows.Forms.ComboBox();
            this.buttonAddAttendance = new System.Windows.Forms.Button();
            this.textBoxSearch = new System.Windows.Forms.TextBox();
            this.dataGridViewEmployeeAttendance = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewEmployeeAttendance)).BeginInit();
            this.SuspendLayout();
            // 
            // comboBoxSelectCategory
            // 
            this.comboBoxSelectCategory.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxSelectCategory.FormattingEnabled = true;
            this.comboBoxSelectCategory.Items.AddRange(new object[] {
            "EmployeeID",
            "UserName",
            "FName",
            "LName",
            "MName"});
            this.comboBoxSelectCategory.Location = new System.Drawing.Point(238, 29);
            this.comboBoxSelectCategory.Name = "comboBoxSelectCategory";
            this.comboBoxSelectCategory.Size = new System.Drawing.Size(196, 28);
            this.comboBoxSelectCategory.TabIndex = 17;
            this.comboBoxSelectCategory.Text = "(Selection)";
            // 
            // buttonAddAttendance
            // 
            this.buttonAddAttendance.BackColor = System.Drawing.Color.LightBlue;
            this.buttonAddAttendance.FlatAppearance.BorderSize = 0;
            this.buttonAddAttendance.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAddAttendance.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAddAttendance.Location = new System.Drawing.Point(440, 332);
            this.buttonAddAttendance.Name = "buttonAddAttendance";
            this.buttonAddAttendance.Size = new System.Drawing.Size(243, 44);
            this.buttonAddAttendance.TabIndex = 16;
            this.buttonAddAttendance.Text = "Add Attendance";
            this.buttonAddAttendance.UseVisualStyleBackColor = false;
            // 
            // textBoxSearch
            // 
            this.textBoxSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxSearch.Location = new System.Drawing.Point(440, 29);
            this.textBoxSearch.Name = "textBoxSearch";
            this.textBoxSearch.Size = new System.Drawing.Size(243, 26);
            this.textBoxSearch.TabIndex = 15;
            // 
            // dataGridViewEmployeeAttendance
            // 
            this.dataGridViewEmployeeAttendance.AllowUserToAddRows = false;
            this.dataGridViewEmployeeAttendance.AllowUserToDeleteRows = false;
            this.dataGridViewEmployeeAttendance.AllowUserToResizeColumns = false;
            this.dataGridViewEmployeeAttendance.AllowUserToResizeRows = false;
            this.dataGridViewEmployeeAttendance.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dataGridViewEmployeeAttendance.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridViewEmployeeAttendance.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewEmployeeAttendance.Location = new System.Drawing.Point(49, 88);
            this.dataGridViewEmployeeAttendance.Name = "dataGridViewEmployeeAttendance";
            this.dataGridViewEmployeeAttendance.ReadOnly = true;
            this.dataGridViewEmployeeAttendance.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewEmployeeAttendance.Size = new System.Drawing.Size(634, 229);
            this.dataGridViewEmployeeAttendance.TabIndex = 14;
            this.dataGridViewEmployeeAttendance.CellContentDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewAttendance_CellContentDoubleClick);
            // 
            // FormAttendanceEmployeeReport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(748, 398);
            this.Controls.Add(this.comboBoxSelectCategory);
            this.Controls.Add(this.buttonAddAttendance);
            this.Controls.Add(this.textBoxSearch);
            this.Controls.Add(this.dataGridViewEmployeeAttendance);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FormAttendanceEmployeeReport";
            this.Text = "FormAttendanceEmployeeReport";
            this.Load += new System.EventHandler(this.FormAttendanceEmployeeReport_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewEmployeeAttendance)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox comboBoxSelectCategory;
        private System.Windows.Forms.Button buttonAddAttendance;
        private System.Windows.Forms.TextBox textBoxSearch;
        private System.Windows.Forms.DataGridView dataGridViewEmployeeAttendance;
    }
}