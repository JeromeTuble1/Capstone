﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace QRCodeDemo
{
    public partial class FormAttendanceAdd : Form
    {
        public static string WorkersID, FullName, Schedule, CheckIn, Status, Day, Date;
        SqlConnection tublecon = new SqlConnection(Class.tublecon);
        int accept = 0;
        bool Leave;

        public FormAttendanceAdd()
        {
            InitializeComponent();
        }

        private void textBoxQRCode_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                AlreadyLeaveOnLeaveRequested();

                if (Leave == false)
                {
                    Search();
                    Search2();

                    if (accept.Equals(1))
                    {
                        WorkersID = "WorkersID: " + labelWorkerID.Text;
                        FullName = "FullName:" + labelFullName.Text;
                        Schedule = "Schedule:" + labelSchedule.Text;
                        CheckIn = "CheckIn:" + labelCheckIn.Text;
                        Status = "Status:" + labelStatus.Text;
                        Day = "Day:" + labelDay.Text;
                        Date = "Date:" + labelDate.Text;

                        EmployeeStatus();
                        /////////////////////////////////////////////////////
                        textBoxQRCode.Text = "";
                        Class.WorkersID = WorkersID + "\n" + FullName + "\n" + Schedule + "\n" + CheckIn + "\n" + Status + "\n" + Day + "\n" + Date;
                        Class.AttendanceAdd = true;
                        FormGenerateQRCode fgq = new FormGenerateQRCode();
                        fgq.ShowDialog();
                        Class.AttendanceAdd = false;
                        accept = 0;
                    }
                }
            }
        }

        void EmployeeStatus()
        {
            SqlCommand cmd = new SqlCommand("INSERT INTO [dbo].[tblEmplyeeStatus] ([EmployeeID],[Date],[Time],[TimeDayNight],[Type],WorkersID,[Description]) VALUES (@EmployeeID, @Date ,@Time, @TimeDayNight, @Type, @WorkersID, @Description)", tublecon);
            cmd.Parameters.AddWithValue("@EmployeeID", Class.EmployeeID);
            cmd.Parameters.AddWithValue("@Date", Convert.ToDateTime(DateTime.Now.ToShortDateString()));
            cmd.Parameters.AddWithValue("@Time", Convert.ToDateTime(DateTime.Now.ToShortTimeString()));

            string converttime = DateTime.Now.ToShortTimeString();
            string[] convertsplittime = converttime.Split(' ');
            cmd.Parameters.AddWithValue("@TimeDayNight", convertsplittime[1]);
            cmd.Parameters.AddWithValue("@Type", "Add Worker Attendance");
            cmd.Parameters.AddWithValue("@WorkersID", labelWorkerID.Text);
            cmd.Parameters.AddWithValue("@Description", Convert.ToString(labelDay.Text + " (" + labelStatus.Text + ")"));
            tublecon.Open();
            cmd.ExecuteNonQuery();
            tublecon.Close();
        }

        void AlreadyLeaveOnLeaveRequested()
        {
            int count = 0; Leave = true;
            SqlCommand cmd = new SqlCommand("SELECT WorkersID, [Date], [From], [To], CONVERT(VARCHAR(20), [FromTime]) + ' ' + FromDayNight AS [FromTime], CONVERT(VARCHAR(20), [ToTime]) + ' ' + ToDayNight AS [ToTime] FROM tblLeaveRequested WHERE WorkersID = @WorkersID AND @Date <= [To] AND [From] <= @Date", tublecon);
            cmd.Parameters.AddWithValue("@WorkersID", textBoxQRCode.Text);
            cmd.Parameters.AddWithValue("@Date", Convert.ToDateTime(DateTime.Now.ToShortDateString()));
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            //From Date
            if (dt.Rows.Count != 0)
            {
                if (Convert.ToDateTime(dt.Rows[0][3]) >= Convert.ToDateTime(DateTime.Now.ToShortDateString()) &&
                    Convert.ToDateTime(dt.Rows[0][2]) <= Convert.ToDateTime(DateTime.Now.ToShortDateString()))
                {
                    count = 1;
                    if (Convert.ToDateTime(dt.Rows[0][3]) == Convert.ToDateTime(DateTime.Now.ToShortDateString()))
                    {
                        if (Convert.ToDateTime(dt.Rows[0][5]) >= Convert.ToDateTime(DateTime.Now.ToShortTimeString()) &&
                            Convert.ToDateTime(dt.Rows[0][4]) <= Convert.ToDateTime(DateTime.Now.ToShortTimeString()))
                        {
                            count = 1;
                        }
                        else
                        {
                            count = 0;
                        }
                    }
                }
            }
            if (count.Equals(0) || dt.Rows.Count.Equals(0))
            {
                Leave = false;
            }
            else if (count.Equals(1))
            {
                MessageBox.Show("Already Leave");
                textBoxQRCode.Text = "";
            }
        }

        void Search()
        {
            SqlCommand cmdTubs = new SqlCommand("SELECT * FROM tblWorkersBioData WHERE WorkersID = @WorkersID", tublecon);
            cmdTubs.Parameters.AddWithValue("@WorkersID", textBoxQRCode.Text);
            SqlDataAdapter daTubs = new SqlDataAdapter(cmdTubs);
            DataTable dtTubs = new DataTable();
            daTubs.Fill(dtTubs);
            if (dtTubs.Rows.Count.Equals(1))
            {
                labelWorkerID.Text = Convert.ToString(dtTubs.Rows[0][0]);
                labelFullName.Text = Convert.ToString(dtTubs.Rows[0][2] + ", " + dtTubs.Rows[0][1] + " " + dtTubs.Rows[0][3] + " " + dtTubs.Rows[0][4]);
                MemoryStream mem = new MemoryStream((Byte[])(dtTubs.Rows[0]["Picture"]));
                pictureBox1.Image = Image.FromStream(mem);
            }
        } //Get Worker ID and Full Name

        void Search2()
        {
            labelCheckIn.Text = DateTime.Now.ToShortTimeString();

            string Date = "", ColDate = "", DateDayNight = "", WeekNow;
            SqlCommand cmd = new SqlCommand("SELECT * FROM tblWorkersSchedule WHERE WorkersID = @WorkersID", tublecon);
            cmd.Parameters.AddWithValue("@WorkersID", labelWorkerID.Text);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            WeekNow = Convert.ToString(DateTime.Now.DayOfWeek);

            if (WeekNow == "Monday") { Date = "Monday"; ColDate = "MonSched"; DateDayNight = "MonDayNight"; }
            else if (WeekNow == "Tuesday") { Date = "Tuesday"; ColDate = "TueSched"; DateDayNight = "TueDayNight"; }
            else if (WeekNow == "Wednesday") { Date = "Wednesday"; ColDate = "WedSched"; DateDayNight = "WedDayNight"; }
            else if (WeekNow == "Thursday") { Date = "Thursday"; ColDate = "ThuSched"; DateDayNight = "ThuDayNight"; }
            else if (WeekNow == "Friday") { Date = "Friday"; ColDate = "FriSched"; DateDayNight = "FriDayNight"; }
            else if (WeekNow == "Saturday") { Date = "Saturday"; ColDate = "SatSched"; DateDayNight = "SatDayNight"; }
            else if (WeekNow == "Sunday") { Date = "Sunday"; ColDate = "SunSched"; DateDayNight = "SunDayNight"; }
            if (Convert.ToInt16(dt.Rows.Count).Equals(1))
            {
                //Show Time from DateTimePicker
                string schedule = Convert.ToString(dt.Rows[0][ColDate]) + " " + Convert.ToString(dt.Rows[0][DateDayNight]);
                labelSchedule.Text = dt.Rows[0][ColDate] + " " + dt.Rows[0][DateDayNight];

                if (Convert.ToDateTime(DateTime.Now.ToShortTimeString()) < Convert.ToDateTime(labelSchedule.Text))
                { labelStatus.Text = "OnTime"; }
                else if (Convert.ToDateTime(DateTime.Now.ToShortTimeString()) > Convert.ToDateTime(labelSchedule.Text))
                { labelStatus.Text = "Late"; }
                if (Convert.ToDateTime(DateTime.Now.ToShortTimeString()) > Convert.ToDateTime("12:00 PM"))
                { labelStatus.Text = "Half Day"; }
                if (Convert.ToDateTime(DateTime.Now.ToShortTimeString()) > Convert.ToDateTime("04:00 PM"))
                { labelStatus.Text = "Overnight"; }

                labelDay.Text = Date;
                labelDate.Text = DateTime.Now.ToShortDateString();

                Search3();
            }
        } //SEt Status Late and OnTime

        void Search3()
        {
            Search4();

            SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM tblWorkersAttendance WHERE [Date] = @Date AND WorkersID = @WorkersID AND NOT Status = @Leave", tublecon);
            cmd.Parameters.AddWithValue("@WorkersID", labelWorkerID.Text);
            cmd.Parameters.AddWithValue("@Date", Convert.ToDateTime(DateTime.Now.ToShortDateString()));
            cmd.Parameters.AddWithValue("@Leave", "Leave");
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            if (Convert.ToInt16(dt.Rows[0][0]).Equals(0))
            {
                SqlCommand cmd1 = new SqlCommand("INSERT INTO tblWorkersAttendance (WorkersID, Schedule, CheckIn, CheckOut, Status, Day, [Date]) VALUES (@WorkersID, @Schedule, @CheckIn, @CheckOut, @Status, @Day, @Date)", tublecon);
                cmd1.Parameters.AddWithValue("@WorkersID", labelWorkerID.Text);
                cmd1.Parameters.AddWithValue("@Schedule", Convert.ToDateTime(labelSchedule.Text));
                cmd1.Parameters.AddWithValue("@CheckIn", Convert.ToDateTime(labelCheckIn.Text));
                cmd1.Parameters.AddWithValue("@CheckOut", "00:00:00");
                cmd1.Parameters.AddWithValue("@Status", labelStatus.Text);
                cmd1.Parameters.AddWithValue("@Day", labelDay.Text);
                cmd1.Parameters.AddWithValue("@Date", Convert.ToDateTime(DateTime.Now.ToShortDateString()));
                tublecon.Open();
                cmd1.ExecuteNonQuery();
                tublecon.Close();
                accept++;
                textBoxQRCode.Text = "";
            }
            else
            {
                MessageBox.Show("Already Present");
                textBoxQRCode.Text = "";
            }
        } //Insert new day Attendance

        void Search4()
        {
            SqlCommand tublecmd = new SqlCommand("DELETE FROM tblWorkersAttendance WHERE WorkersID = @WorkersID AND [Date] = @Date AND Status = @Absent", tublecon);
            tublecmd.Parameters.AddWithValue("@WorkersID", labelWorkerID.Text);
            tublecmd.Parameters.AddWithValue("@Date", Convert.ToDateTime(DateTime.Now.ToShortDateString()));
            tublecmd.Parameters.AddWithValue("@Absent", "Absent");
            tublecon.Open();
            tublecmd.ExecuteNonQuery();
            tublecon.Close();
        }

        private void FormAttendanceAdd_Load(object sender, EventArgs e)
        {

        }

        private void buttonClose_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}