﻿using Microsoft.Reporting.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace QRCodeDemo
{
    public partial class FormLeaveReceipt : Form
    {
        SqlConnection tublecon = new SqlConnection(Class.tublecon);

        public FormLeaveReceipt()
        {
            InitializeComponent();
        }

        private void FormLeaveReceipt_Load(object sender, EventArgs e)
        {
            GetDataName();
        }

        void GetDataName()
        {
            SqlCommand tublecmd = new SqlCommand("SELECT LR.WorkersID, WBD.LName +', '+ WBD.FName +' '+ WBD.MName AS 'FullName', LR.[From], LR.[To], CONVERT(VARCHAR(20), LR.FromTime) + ' ' + LR.FromDayNight AS 'FromTime', CONVERT(VARCHAR(20), LR.ToTime) + ' ' + LR.ToDayNight AS 'ToTime', LR.[Date], WA.AbsentCause FROM tblLeaveRequested LR INNER JOIN tblWorkersAttendance WA ON LR.WorkersID = WA.WorkersID INNER JOIN tblWorkersBioData WBD ON LR.WorkersID = WBD.WorkersID WHERE LR.WorkersID = @WorkersID AND WA.WorkersID = @WorkersID AND NOT AbsentCause = ''", tublecon);
            tublecmd.Parameters.AddWithValue("@WorkersID",Class.WorkersID);
            SqlDataAdapter da = new SqlDataAdapter(tublecmd);
            DataTable tubledt = new DataTable();
            da.Fill(tubledt);

            if (tubledt.Rows.Count.Equals(0))
            {
                MessageBox.Show("No Report");
                this.Close();
            }
            else
            {
                string pdate = Convert.ToString(tubledt.Rows[0]["Date"]);
                string []pdatesplit = pdate.Split(' ');
                string pFromDate = Convert.ToString(tubledt.Rows[0]["From"]);
                string []pFromDatesplit = pFromDate.Split(' ');
                string pToDate = Convert.ToString(tubledt.Rows[0]["To"]);
                string[] pToDatesplit = pToDate.Split(' ');
                ReportParameter[] para = new ReportParameter[] { 
                    new ReportParameter("pID", Convert.ToString(tubledt.Rows[0]["WorkersID"])), 
                    new ReportParameter("pName", Convert.ToString(tubledt.Rows[0]["FullName"])),
                    new ReportParameter("pDate", pdatesplit[0]),
                    new ReportParameter("pLeave", Convert.ToString(tubledt.Rows[0]["AbsentCause"])),
                    new ReportParameter("pFromDate", pFromDatesplit[0]),
                    new ReportParameter("pFromTime", Convert.ToString(tubledt.Rows[0]["FromTime"])),
                    new ReportParameter("pToDate", pToDatesplit[0]),
                    new ReportParameter("pToTime", Convert.ToString(tubledt.Rows[0]["ToTime"]))
                };
                this.reportViewer1.LocalReport.SetParameters(para);
                this.reportViewer1.RefreshReport();
            }
        }
    }
}
