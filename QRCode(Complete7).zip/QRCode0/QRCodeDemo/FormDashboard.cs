﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace QRCodeDemo
{
    public partial class FormDashboard : Form
    {
        SqlConnection tublecon = new SqlConnection(Class.tublecon);
        int absent = 0;
        public FormDashboard()
        {
            InitializeComponent();
        }

        private void FormMain_Load(object sender, EventArgs e)
        {
            progressbarcount();
            Present();
            On_Time();
            Late();
            Absent();
            Half_Day();
            EmergencyLeave();
        }

        void progressbarcount()
        {
            SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM tblWorkersBioData", tublecon);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows[0][0].ToString().Equals(""))
            {
                progressBarPresent.Maximum = 0;
                progressBarOnTime.Maximum = 0;
                progressBarLate.Maximum = 0;
                progressBarAbsent.Maximum = 0;
                progressBarHalfDay.Maximum = 0;
                progressBarEmergencyLeave.Maximum = 0;
            }
            else
            {
                progressBarPresent.Maximum = Convert.ToInt16(dt.Rows[0][0]);
                progressBarOnTime.Maximum = Convert.ToInt16(dt.Rows[0][0]);
                progressBarLate.Maximum = Convert.ToInt16(dt.Rows[0][0]);
                progressBarAbsent.Maximum = Convert.ToInt16(dt.Rows[0][0]);
                progressBarHalfDay.Maximum = Convert.ToInt16(dt.Rows[0][0]);
                progressBarEmergencyLeave.Maximum = Convert.ToInt16(dt.Rows[0][0]);
            }
        }

        void Present()
        {
            SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM tblWorkersAttendance WHERE [Date]=@Date AND NOT [Status]=@StatusAbsent AND NOT [Status]=@StatusHoliday AND NOT [Status]=@StatusLeave", tublecon);
            cmd.Parameters.AddWithValue("@Date", Convert.ToDateTime(DateTime.Now.ToShortDateString()));
            cmd.Parameters.AddWithValue("@StatusAbsent", "Absent");
            cmd.Parameters.AddWithValue("@StatusHoliday", "Holiday");
            cmd.Parameters.AddWithValue("@StatusLeave", "Leave");
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows[0][0].ToString().Equals(0)) { progressBarPresent.Value = 0; }
            else { progressBarPresent.Value = Convert.ToInt16(dt.Rows[0][0]); absent = Convert.ToInt16(dt.Rows[0][0]);}
        }

        void On_Time()
        {
            SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM tblWorkersAttendance WHERE Status=@Status AND Date=@Date", tublecon);

            string splitdatetime = DateTime.Now.Date.ToString();
            string[] consplitdatetime = splitdatetime.Split(' ');
            cmd.Parameters.AddWithValue("@Date", Convert.ToDateTime(DateTime.Now.ToShortDateString()));
            cmd.Parameters.AddWithValue("@Status", "OnTime");

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            if (dt.Rows[0][0].ToString().Equals(0)) { progressBarOnTime.Value = 0; }
            else { progressBarOnTime.Value = Convert.ToInt16(dt.Rows[0][0]); }
        }

        void Late()
        {
            SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM tblWorkersAttendance WHERE Status=@Status AND Date=@Date", tublecon);

            string splitdatetime = DateTime.Now.Date.ToString();
            string[] consplitdatetime = splitdatetime.Split(' ');
            cmd.Parameters.AddWithValue("@Date", Convert.ToDateTime(DateTime.Now.ToShortDateString()));
            cmd.Parameters.AddWithValue("@Status", "Late");

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            
            if (dt.Rows[0][0].ToString().Equals(0)) { progressBarLate.Value = 0; }
            else { progressBarLate.Value = Convert.ToInt16(dt.Rows[0][0]); }
        }

        void Absent()
        {
            SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM tblWorkersBioData", tublecon);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            if (dt.Rows[0][0].ToString().Equals(0)) { progressBarAbsent.Value = 0; }
            else { progressBarAbsent.Value = Convert.ToInt16(dt.Rows[0][0]) - absent; }
        }

        void Half_Day()
        {
            SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM tblWorkersAttendance WHERE Status=@Status AND Date=@Date", tublecon);

            string splitdatetime = DateTime.Now.Date.ToString();
            string[] consplitdatetime = splitdatetime.Split(' ');
            cmd.Parameters.AddWithValue("@Date", Convert.ToDateTime(DateTime.Now.ToShortDateString()));
            cmd.Parameters.AddWithValue("@Status", "Half Day");

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            if (dt.Rows[0][0].ToString().Equals(0)) { progressBarHalfDay.Value = 0; }
            else { progressBarHalfDay.Value = Convert.ToInt16(dt.Rows[0][0]); }
        }

        void EmergencyLeave()
        {
            SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM tblLeaveRequested WHERE @Date <= [To] AND [From] <= @Date", tublecon);

            string splitdatetime = DateTime.Now.Date.ToString();
            string[] consplitdatetime = splitdatetime.Split(' ');
            cmd.Parameters.AddWithValue("@Date", Convert.ToDateTime(DateTime.Now.ToShortDateString()));

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            if (dt.Rows[0][0].ToString().Equals(0)) { progressBarHalfDay.Value = 0; }
            else { progressBarEmergencyLeave.Value = Convert.ToInt16(dt.Rows[0][0]); }
        }
    }
}
