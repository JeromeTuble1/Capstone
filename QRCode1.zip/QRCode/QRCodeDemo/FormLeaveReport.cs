﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace QRCodeDemo
{
    public partial class FormLeaveReport : Form
    {
        SqlConnection tublecon = new SqlConnection(Class.tublecon);

        public FormLeaveReport()
        {
            InitializeComponent();
        }

        private void FormLeaveReport_Load(object sender, EventArgs e)
        {
            loaddtata();
        }

        void loaddtata()
        {
            SqlCommand tublecmd = new SqlCommand("SELECT WorkersID, [From], [To], CONVERT(VARCHAR(20), FromTime) + ' ' + FromDayNight AS 'FromTime', CONVERT(VARCHAR(20), ToTime) + ' ' + ToDayNight AS 'ToTime', [Date] FROM tblLeaveRequested", tublecon);
            SqlDataAdapter da = new SqlDataAdapter(tublecmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridViewReport.DataSource = dt;
        }

        private void dataGridViewReport_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            Class.WorkersID = dataGridViewReport.CurrentRow.Cells[0].Value.ToString();
            Class.WorkersDate = dataGridViewReport.CurrentRow.Cells[5].Value.ToString();
            FormLeaveReceipt LR = new FormLeaveReceipt();
            LR.ShowDialog();
        }
    }
}
