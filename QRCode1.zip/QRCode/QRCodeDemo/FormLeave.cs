﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace QRCodeDemo
{
    public partial class FormLeave : Form
    {
        SqlConnection tublecon = new SqlConnection(Class.tublecon);

        public FormLeave()
        {
            InitializeComponent();
        }

        private void FormHoliday_Load(object sender, EventArgs e)
        {
            loaddata();
        }

        void loaddata()
        {
            SqlCommand cmd = new SqlCommand("SELECT WorkersID, LName +', '+ FName +' '+ MName +' '+ Suffix AS Name, BirthDate, HireDate, MaritalStatus, ContactNumber, EmergencyContact FROM tblWorkersBioData", tublecon);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridViewAttendanceHoliday.DataSource = dt;
        }

        private void textBoxSearch_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                SqlCommand cmd = new SqlCommand("SELECT WorkersID, LName +', '+ FName +' '+ MName +' '+ Suffix AS Name, BirthDate, HireDate, MaritalStatus, ContactNumber, EmergencyContact FROM tblWorkersBioData WHERE WorkersID = @WorkersID", tublecon);
                cmd.Parameters.AddWithValue("@WorkersID", textBoxSearch.Text);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridViewAttendanceHoliday.DataSource = dt;
            }
        }

        private void dataGridViewAttendanceHoliday_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            Class.WorkersID = dataGridViewAttendanceHoliday.CurrentRow.Cells[0].Value.ToString();
            FormLeaveAdd HA = new FormLeaveAdd();
            HA.ShowDialog();
            loaddata();
        }
    }
}
