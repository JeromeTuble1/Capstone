﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace QRCodeDemo
{
    public partial class FormWorkersEdit : Form
    {
        SqlConnection tublecon = new SqlConnection(Class.tublecon);
        MemoryStream tubleMS;

        public FormWorkersEdit()
        {
            InitializeComponent();
        }

        private void FormWorkersEdit_Load(object sender, EventArgs e)
        {
            GetBioData();
        }

        void GetBioData()
        {

            SqlCommand cmd = new SqlCommand("SELECT WBD.WorkersID, WBD.LName, WBD.FName, WBD.MName, WBD.BirthDate, WBD.HireDate, WBD.FatherName, WBD.MotherName, WBD.MaritalStatus, WBD.Religion, WBD.NumberOfChildren, WBD.[Address], WBD.ContactNumber, WBD.EmergencyContact, WBD.Picture, WE.NameOfCompany, WE.Position, WE.YearHire, WE.Reference, WS.Monday, WS.Tuesday, WS.Wednesday, WS.Thursday, WS.Friday, WS.Saturday, WS.Sunday,EQ.Matric, EQ.YearMatric, EQ.GradeMatric, EQ.[Intermediate], EQ.YearIntermediate, EQ.GradeIntermediate, EQ.Graduation, EQ.YearGraduation, EQ.GradeGraduation,  EQ.Masters, EQ.YearMasters, EQ.GradeMasters FROM tblWorkersBioData WBD INNER JOIN tblWorkingExperience WE ON WBD.WorkersID = WE.WorkersID INNER JOIN tblWorkersSchedule WS ON WBD.WorkersID = WS.WorkersID INNER JOIN tblEducationalQualification EQ ON WBD.WorkersID = EQ.WorkersID WHERE WBD.WorkersID = @WorkersID", tublecon);
            cmd.Parameters.AddWithValue("@WorkersID", Class.WorkersID);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            textBoxWorkerID.Text = Convert.ToString(dt.Rows[0][0]);
            textBoxLName.Text = Convert.ToString(dt.Rows[0][1]);
            textBoxFName.Text = Convert.ToString(dt.Rows[0][2]);
            textBoxMName.Text = Convert.ToString(dt.Rows[0][3]);
            dateTimePickerbirthdate.Text = Convert.ToString(dt.Rows[0][4]);
            string HireDate = Convert.ToString(dt.Rows[0]["HireDate"]); ;
            string[] HireDate1 = HireDate.Split(' ');
            textBoxHireDate.Text = HireDate1[0];
            string SplitName = Convert.ToString(dt.Rows[0]["FatherName"]); ;
            string[] SplitName1 = SplitName.Split(' ');
            textBoxFatherFName.Text = SplitName1[1];
            textBoxFatherLName.Text = SplitName1[0];
            textBoxFatherMName.Text = SplitName1[2];
            string SplitMotherName = Convert.ToString(dt.Rows[0]["MotherName"]); ;
            string[] SplitMotherName1 = SplitName.Split(' ');
            textBoxMotherFName.Text = SplitName1[1];
            textBoxMotherLName.Text = SplitName1[0];
            textBoxMotherMName.Text = SplitName1[2];
            comboBoxMartialStatus.Text = Convert.ToString(dt.Rows[0][8]);
            comboBoxReligion.Text = Convert.ToString(dt.Rows[0][9]);
            numericUpDownNumofChil.Value = Convert.ToInt16(dt.Rows[0][10]);
            textBoxAddress.Text = Convert.ToString(dt.Rows[0][11]);
            maskedTextBoxContactNum.Text = Convert.ToString(dt.Rows[0][12]);
            maskedTextBoxEmergencyContact.Text = Convert.ToString(dt.Rows[0][13]);
            //For PictureBox
            MemoryStream mem = new MemoryStream((Byte[])(dt.Rows[0]["Picture"]));
            pictureBox1.Image = Image.FromStream(mem);
            textBoxNameOfCompany.Text = Convert.ToString(dt.Rows[0][15]);
            textBoxPosition.Text = Convert.ToString(dt.Rows[0][16]);
            comboBoxYearHire.Text = Convert.ToString(dt.Rows[0][17]);
            textBoxReference.Text = Convert.ToString(dt.Rows[0][18]);
            dateTimePickerMonday.Text = Convert.ToString(dt.Rows[0][19]);
            dateTimePickerTuesday.Text = Convert.ToString(dt.Rows[0][20]);
            dateTimePickerWednesday.Text = Convert.ToString(dt.Rows[0][21]);
            dateTimePickerThursday.Text = Convert.ToString(dt.Rows[0][22]);
            dateTimePickerFriday.Text = Convert.ToString(dt.Rows[0][23]);
            dateTimePickerSaturday.Text = Convert.ToString(dt.Rows[0][24]);
            dateTimePickerSunday.Text = Convert.ToString(dt.Rows[0][25]);
            textBoxMatricName.Text = Convert.ToString(dt.Rows[0][26]);
            comboBoxMatricYearPassed.Text = Convert.ToString(dt.Rows[0][27]);
            numericUpDownMatricGrade.Value = Convert.ToInt16(dt.Rows[0][28]);
            textBoxIntermediateName.Text = Convert.ToString(dt.Rows[0][29]);
            comboBoxIntermediateYearPassed.Text = Convert.ToString(dt.Rows[0][30]);
            numericUpDownIntermediateGrade.Value = Convert.ToInt16(dt.Rows[0][31]);
            textBoxGraduationName.Text = Convert.ToString(dt.Rows[0][32]);
            comboBoxGraduationYearPassed.Text = Convert.ToString(dt.Rows[0][33]);
            numericUpDownGraduationGrade.Value = Convert.ToInt16(dt.Rows[0][34]);
            textBoxMasterName.Text = Convert.ToString(dt.Rows[0][35]);
            comboBoxMasterYearPassed.Text = Convert.ToString(dt.Rows[0][36]);
            numericUpDownMasterGrade.Value = Convert.ToInt16(dt.Rows[0][37]);

            if (comboBoxMartialStatus.SelectedItem.Equals("Single"))
            {
                numericUpDownNumofChil.Enabled = false;
                numericUpDownNumofChil.Value = 0;
            }
            else
            {
                numericUpDownNumofChil.Enabled = true;
            }

        }

        void UpdateWorker()
        {
            int SuccessBioData = 0, SuccessWorkExp = 0, SuccessErrorEduQual = 0, SuccessErrorSchedule = 0;

            if (Class.AddWorkersCollectionError.Equals(0))
            {
                    try
                    {
                        if (SuccessBioData.Equals(0))
                        {
                            //Worker Biodata
                            tublecon.Open();
                            SqlCommand TubleBioData = new SqlCommand("UPDATE tblWorkersBioData SET FName=@FName ,LName=@LName ,MName=@MName ,BirthDate=@BirthDate ,HireDate=@HireDate ,FatherName=@FatherName ,MotherName=@MotherName ,MaritalStatus=@MaritalStatus ,Religion=@Religion ,NumberOfChildren=@NumberOfChildren ,Address=@Address ,ContactNumber=@ContactNumber ,EmergencyContact=@EmergencyContact ,Picture=@Picture WHERE WorkersID = @WorkersID", tublecon);
                            TubleBioData.Parameters.AddWithValue("@WorkersID", textBoxWorkerID.Text);
                            TubleBioData.Parameters.AddWithValue("@FName", textBoxFName.Text);
                            TubleBioData.Parameters.AddWithValue("@LName", textBoxLName.Text);
                            TubleBioData.Parameters.AddWithValue("@MName", textBoxMName.Text);
                            TubleBioData.Parameters.AddWithValue("@BirthDate", dateTimePickerbirthdate.Text);
                            TubleBioData.Parameters.AddWithValue("@HireDate", DateTime.Now.ToShortDateString());
                            TubleBioData.Parameters.AddWithValue("@FatherName", textBoxFatherLName.Text + " " + textBoxFatherFName.Text + " " + textBoxFatherMName.Text);
                            TubleBioData.Parameters.AddWithValue("@MotherName", textBoxMotherLName.Text + " " + textBoxMotherFName.Text + " " + textBoxMotherMName.Text);
                            TubleBioData.Parameters.AddWithValue("@MaritalStatus", Convert.ToString(comboBoxMartialStatus.SelectedItem));
                            TubleBioData.Parameters.AddWithValue("@Religion", Convert.ToString(comboBoxReligion.SelectedItem));
                            TubleBioData.Parameters.AddWithValue("@NumberOfChildren", numericUpDownNumofChil.Value);
                            TubleBioData.Parameters.AddWithValue("@Address", textBoxAddress.Text);
                            TubleBioData.Parameters.AddWithValue("@ContactNumber", Class.contfirstandfirsttuble[0] + Class.contsecondthirdtuble[0] + Class.contsecondthirdtuble[1]);
                            TubleBioData.Parameters.AddWithValue("@EmergencyContact", Class.emerfirstandfirsttuble[0] + Class.emersecondthirdtuble[0] + Class.emersecondthirdtuble[1]);

                            tubleMS = new MemoryStream();
                            pictureBox1.Image.Save(tubleMS, ImageFormat.Jpeg);
                            byte[] photo_array = new byte[tubleMS.Length];
                            tubleMS.Position = 0;
                            tubleMS.Read(photo_array, 0, photo_array.Length);

                            TubleBioData.Parameters.AddWithValue("@Picture", photo_array);
                            TubleBioData.ExecuteNonQuery();

                            //tublecon.Close();

                            panelBioData.Enabled = false;
                            panelImage.Enabled = false;
                            SuccessBioData++;
                            //END Biodata
                        }
                    }
                    catch (Exception)
                    {
                        MessageBox.Show("Error in Worker Biodata");
                    }

                    try
                    {
                        if (SuccessWorkExp.Equals(0))
                        {
                            //Working Experience
                            //tublecon.Open();
                            SqlCommand TubleWorkingExp = new SqlCommand("UPDATE tblWorkingExperience SET NameOfCompany=@NameOfCompany, Position=@Position, YearHire=@YearHire, Reference=@Reference WHERE WorkersID=@WorkersID", tublecon);
                            TubleWorkingExp.Parameters.AddWithValue("@WorkersID", textBoxWorkerID.Text);
                            TubleWorkingExp.Parameters.AddWithValue("@NameOfCompany", textBoxNameOfCompany.Text);
                            TubleWorkingExp.Parameters.AddWithValue("@Position", textBoxPosition.Text);
                            TubleWorkingExp.Parameters.AddWithValue("@YearHire", Convert.ToInt16(comboBoxYearHire.SelectedItem));
                            TubleWorkingExp.Parameters.AddWithValue("@Reference", textBoxReference.Text);
                            TubleWorkingExp.ExecuteNonQuery();
                            //tublecon.Close();

                            panelWorkingExperience.Enabled = false;
                            SuccessWorkExp++;
                            //END WorkingExperience
                        }
                    }
                    catch (Exception)
                    {
                        MessageBox.Show("Error in Working Experience");
                    }

                    try
                    {
                        if (SuccessErrorEduQual.Equals(0))
                        {
                            //Educational Qualification
                            SqlCommand TubleEducationalQual = new SqlCommand("UPDATE tblEducationalQualification SET Matric=@Matric, YearMatric=@YearMatric, GradeMatric=@GradeMatric, Intermediate=@Intermediate, YearIntermediate=@YearIntermediate, GradeIntermediate=@GradeIntermediate, Graduation=@Graduation, YearGraduation=@YearGraduation, GradeGraduation=@GradeGraduation, Masters=@Masters, YearMasters=@YearMasters, GradeMasters=@GradeMasters WHERE WorkersID=@WorkersID", tublecon);
                            TubleEducationalQual.Parameters.AddWithValue("@WorkersID", textBoxWorkerID.Text);
                            TubleEducationalQual.Parameters.AddWithValue("@Matric", textBoxMatricName.Text);
                            TubleEducationalQual.Parameters.AddWithValue("@YearMatric", Convert.ToInt16(comboBoxMatricYearPassed.SelectedItem));
                            TubleEducationalQual.Parameters.AddWithValue("@GradeMatric", numericUpDownMatricGrade.Value.ToString());
                            TubleEducationalQual.Parameters.AddWithValue("@Intermediate", textBoxIntermediateName.Text);
                            TubleEducationalQual.Parameters.AddWithValue("@YearIntermediate", Convert.ToInt16(comboBoxIntermediateYearPassed.SelectedItem));
                            TubleEducationalQual.Parameters.AddWithValue("@GradeIntermediate", numericUpDownIntermediateGrade.Value.ToString());
                            TubleEducationalQual.Parameters.AddWithValue("@Graduation", textBoxGraduationName.Text);
                            TubleEducationalQual.Parameters.AddWithValue("@YearGraduation", Convert.ToInt16(comboBoxGraduationYearPassed.SelectedItem));
                            TubleEducationalQual.Parameters.AddWithValue("@GradeGraduation", numericUpDownGraduationGrade.Value.ToString());
                            TubleEducationalQual.Parameters.AddWithValue("@Masters", textBoxMasterName.Text);
                            TubleEducationalQual.Parameters.AddWithValue("@YearMasters", Convert.ToInt16(comboBoxMasterYearPassed.SelectedItem));
                            TubleEducationalQual.Parameters.AddWithValue("@GradeMasters", numericUpDownMasterGrade.Value.ToString());
                            TubleEducationalQual.ExecuteNonQuery();

                            panelEducationalQualification.Enabled = false;
                            SuccessErrorEduQual++;
                            //END Educational Qualification
                        }
                    }
                    catch (Exception)
                    {
                        MessageBox.Show("Error in Educational Qualification");
                    }

                    try
                    {
                        if (SuccessErrorSchedule.Equals(0))
                        {
                            //Worker Schedule
                            SqlCommand TubleWorkingExp = new SqlCommand("UPDATE tblWorkersSchedule SET Sunday=@Sunday, Monday=@Monday, Tuesday=@Tuesday, Wednesday=@Wednesday, Thursday=@Thursday, Friday=@Friday, Saturday=@Saturday  WHERE WorkersID=@WorkersID", tublecon);
                            TubleWorkingExp.Parameters.AddWithValue("@WorkersID", Class.WorkersID);
                            TubleWorkingExp.Parameters.AddWithValue("@Sunday",    dateTimePickerMonday.Text);
                            TubleWorkingExp.Parameters.AddWithValue("@Monday",    dateTimePickerTuesday.Text);
                            TubleWorkingExp.Parameters.AddWithValue("@Tuesday",   dateTimePickerWednesday.Text);
                            TubleWorkingExp.Parameters.AddWithValue("@Wednesday", dateTimePickerThursday.Text);
                            TubleWorkingExp.Parameters.AddWithValue("@Thursday",  dateTimePickerFriday.Text);
                            TubleWorkingExp.Parameters.AddWithValue("@Friday",    dateTimePickerSaturday.Text);
                            TubleWorkingExp.Parameters.AddWithValue("@Saturday",  dateTimePickerSunday.Text);
                            TubleWorkingExp.ExecuteNonQuery();

                            panelWorkingExperience.Enabled = false;
                            SuccessErrorSchedule++;
                            //END Worker Schedule
                        }
                    }
                    catch (Exception)
                    {
                        MessageBox.Show("Error in Worker Schedule");
                    }

                    if (SuccessBioData != 0 && SuccessWorkExp != 0 && SuccessErrorEduQual != 0)
                    {
                        this.Hide();
                    }
                
            }
            else
            {
                MessageBox.Show(Class.AddWorkerCollectionStatusError);
            }
        }

        void SplitContacts()
        {
            //Contact Number
            Class.contsplitspace = maskedTextBoxContactNum.Text;
            Class.contspittuble = Class.contsplitspace.Split(' ');
            Class.contfirsttuble = Class.contspittuble[0].Split('(');
            Class.contsecondthirdtuble = Class.contspittuble[1].Split('-');
            Class.contfirstandfirsttuble = Class.contfirsttuble[1].Split(')');

            //MessageBox.Show(Class.contfirstandfirsttuble[0] + Class.contsecondthirdtuble[0] + Class.contsecondthirdtuble[1]);

            //Emergency Contact
            Class.emersplitspace = maskedTextBoxEmergencyContact.Text;
            Class.emerspittuble = Class.emersplitspace.Split(' ');
            Class.emerfirsttuble = Class.emerspittuble[0].Split('(');
            Class.emersecondthirdtuble = Class.emerspittuble[1].Split('-');
            Class.emerfirstandfirsttuble = Class.emerfirsttuble[1].Split(')');

            //MessageBox.Show(Class.emerfirstandfirsttuble[0] + Class.emersecondthirdtuble[0] + Class.emersecondthirdtuble[1]);
        }

        private void comboBoxMartialStatus_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBoxMartialStatus.SelectedItem.Equals("Single"))
            {
                numericUpDownNumofChil.Enabled = false;
                numericUpDownNumofChil.Value = 0;
            }
            else
            {
                numericUpDownNumofChil.Enabled = true;
            }
        }

        private void buttonEditWorker_Click(object sender, EventArgs e)
        {
            SplitContacts();
            UpdateWorker();
        }
    }
}
