﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace QRCodeDemo
{
    public partial class FormAttendanceEdit : Form
    {
        SqlConnection tublecon = new SqlConnection(Class.tublecon);

        public FormAttendanceEdit()
        {
            InitializeComponent();
        }

        private void FormAttendanceEdit_Load(object sender, EventArgs e)
        {
            GetData();
        }

        void GetData() 
        {

            SqlCommand cmd = new SqlCommand("SELECT * FROM tblWorkersAttendance INNER JOIN tblWorkersBioData ON tblWorkersAttendance.WorkersID = tblWorkersBioData.WorkersID WHERE tblWorkersBioData.WorkersID = @WorkersID AND tblWorkersAttendance.Date = @Date", tublecon);
            cmd.Parameters.AddWithValue("@WorkersID", Class.WorkersID);
            cmd.Parameters.AddWithValue("@Date", Class.WorkersDate);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            MessageBox.Show(dt.Rows[0][0].ToString());
            textBoxWorkersID.Text = Convert.ToString(dt.Rows[0][0]);
            textBoxFullName.Text = Convert.ToString(dt.Rows[0]["LName"] + ", " + dt.Rows[0]["FName"] + " " + dt.Rows[0]["MName"]);
            dateTimePickerSchedule.Text = Convert.ToString(dt.Rows[0]["Schedule"]);
            dateTimePickerCheckIn.Text = Convert.ToString(dt.Rows[0]["CheckIn"]);
            dateTimePickerCheckOut.Text = Convert.ToString(dt.Rows[0]["CheckOut"]);
            textBoxStatus.Text = Convert.ToString(dt.Rows[0]["Status"]);
            textBoxDay.Text = Convert.ToString(dt.Rows[0]["Day"]);
            dateTimePickerDate.Text = Convert.ToString(dt.Rows[0]["Date"]);

            //For PictureBox
            MemoryStream mem = new MemoryStream((Byte[])(dt.Rows[0]["Picture"]));
            pictureBox1.Image = Image.FromStream(mem);
        }

        private void buttonClose_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void buttonAddAttendance_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("UPDATE tblWorkersAttendance SET CheckOut = @CheckOut WHERE WorkersID = @WorkersID AND Date = @Date", tublecon);
            cmd.Parameters.AddWithValue("@CheckOut", dateTimePickerCheckOut.Text);
            cmd.Parameters.AddWithValue("@WorkersID", textBoxWorkersID.Text);
            cmd.Parameters.AddWithValue("@Date", dateTimePickerDate.Text);
            tublecon.Open();
            cmd.ExecuteNonQuery();
            tublecon.Close();
            this.Hide();
        }
    }
}
