﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace QRCodeDemo
{
    public partial class FormAddWorkers : Form
    {
        SqlConnection con = new SqlConnection(Class.con);

        public FormAddWorkers()
        {
            InitializeComponent();
        }

        private void buttonBack_Click(object sender, EventArgs e)
        {
            FormAttendance FA = new FormAttendance();
            this.Hide();
            FA.ShowDialog();
        }

        private void buttonAddWorkers_Click(object sender, EventArgs e)
        {

        }

        private void FormAddWorkers_Load(object sender, EventArgs e)
        {
            //CreateNewID();
            Date2();
        }

        void Date2() {
            labelDate.Text = DateTime.Now.Day + "/" + DateTime.Now.Month + "/" + DateTime.Now.Year;
        }

        void CreateNewID()
        {
            string Workers = "";
            textBoxUserID.Text = "";
            SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM tblWorkers", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            if (Convert.ToInt16(dt.Rows[0][0]).Equals(0))
            {
                Workers = "1";
            }
            else
            {
                Workers = (Convert.ToInt16(dt.Rows[0][0]) + 1).ToString();
            }
            if (Convert.ToInt16(Workers) < 10)
            {
                Workers = "000" + Workers;
            }
            else if (Convert.ToInt16(Workers) < 100)
            {
                Workers = "00" + Workers;
            }
            else if (Convert.ToInt16(Workers) < 1000)
            {
                Workers = "0" + Workers;
            }
            textBoxUserID.Text = DateTime.Now.Year + "-" + Workers + "-Worker-DJAAS";
        }
    }
}
