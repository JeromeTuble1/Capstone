﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace QRCodeDemo
{
    public partial class FormAttendanceAdd : Form
    {
        SqlConnection tublecon = new SqlConnection(Class.tublecon);

        public FormAttendanceAdd()
        {
            InitializeComponent();
        }

        private void textBoxQRCode_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                Search();
                Search2();
                Search3();
            }
        }

        void Search() 
        {
            SqlCommand cmdTubs = new SqlCommand("SELECT * FROM tblWorkersBioData WHERE WorkersID = @WorkersID", tublecon);
            cmdTubs.Parameters.AddWithValue("@WorkersID", textBoxQRCode.Text);
            SqlDataAdapter daTubs = new SqlDataAdapter(cmdTubs);
            DataTable dtTubs = new DataTable();
            daTubs.Fill(dtTubs);

            labelWorkerID.Text = Convert.ToString(dtTubs.Rows[0][0]);
            labelFullName.Text = Convert.ToString(dtTubs.Rows[0][2] + ", " + dtTubs.Rows[0][1] + " " + dtTubs.Rows[0][3]);
        } //Get Worker ID and Full Name

        void Search2()
        {
            string Date = "", DateDayNight ="";
            SqlCommand cmd = new SqlCommand("SELECT * FROM tblWorkersSchedule WHERE WorkersID = @WorkersID", tublecon);
            cmd.Parameters.AddWithValue("@WorkersID", labelWorkerID.Text);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (Convert.ToString(DateTime.Now.DayOfWeek).Equals("Monday")) { Date = "MonSched"; DateDayNight = "MonDayNight"; }
            else if (Convert.ToString(DateTime.Now.DayOfWeek).Equals("Tuesday")) { Date = "TueSched"; DateDayNight = "TueDayNight"; }
            else if (Convert.ToString(DateTime.Now.DayOfWeek).Equals("Wednesday")) { Date = "WedSched"; DateDayNight = "WedDayNight"; }
            else if (Convert.ToString(DateTime.Now.DayOfWeek).Equals("Thursday")) { Date = "ThuSched"; DateDayNight = "ThuDayNight"; }
            else if (Convert.ToString(DateTime.Now.DayOfWeek).Equals("Friday")) { Date = "FriSched"; DateDayNight = "FriDayNight"; }
            else if (Convert.ToString(DateTime.Now.DayOfWeek).Equals("Saturday")) { Date = "SatSched"; DateDayNight = "SatDayNight"; }
            else if (Convert.ToString(DateTime.Now.DayOfWeek).Equals("Sunday")) { Date = "SunSched"; DateDayNight = "SunDayNight"; }

            //Show Time from DateTimePicker
            labelSchedule.Text = dt.Rows[0][Date].ToString()+" "+ dt.Rows[0][DateDayNight].ToString();
            if (Convert.ToDateTime(labelSchedule.Text) < Convert.ToDateTime(labelCheckIn.Text)) 
            { labelStatus.Text = "OnTime"; }
            else { labelStatus.Text = "Late"; }

            labelDay.Text = Date;
            labelDate.Text = DateTime.Now.ToShortDateString();
        } //SEt Status Late and OnTime

        void Search3() 
        {
            SqlCommand cmd = new SqlCommand("SELECT COUNT(*) AS [COUNT] FROM tblWorkersAttendance WHERE [Date] = @Date AND WorkersID = @WorkersID", tublecon);
            cmd.Parameters.AddWithValue("@WorkersID", labelWorkerID.Text);
            cmd.Parameters.AddWithValue("@Date", labelDate.Text);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            if (Convert.ToInt16(dt.Rows[0][0]).Equals(0))
            {
                tublecon.Open();
                SqlCommand cmd1 = new SqlCommand("INSERT INTO tblWorkersAttendance (WorkersID, Schedule, CheckIn, CheckOut, Status, Day, [Date]) VALUES (@WorkersID, @Schedule, @CheckIn, @CheckOut, @Status, @Day, @Date)", tublecon);
                cmd1.Parameters.AddWithValue("@WorkersID", labelWorkerID.Text);
                cmd1.Parameters.AddWithValue("@Schedule", labelSchedule.Text);
                cmd1.Parameters.AddWithValue("@CheckIn", labelCheckIn.Text);
                cmd1.Parameters.AddWithValue("@CheckOut", "00:00:00");
                cmd1.Parameters.AddWithValue("@Status", labelStatus.Text);
                cmd1.Parameters.AddWithValue("@Day", labelDay.Text);
                cmd1.Parameters.AddWithValue("@Date", labelDate.Text);
                
                cmd1.ExecuteNonQuery();
                
                tublecon.Close();
            }
            else
            {
                MessageBox.Show("Already Printed");
            }
        } //Insert new day Attendance


        private void FormAttendanceAdd_Load(object sender, EventArgs e)
        {
            labelSchedule.Text = DateTime.Now.ToShortTimeString();
            labelCheckIn.Text = DateTime.Now.ToShortTimeString();
        }

        private void buttonClose_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
