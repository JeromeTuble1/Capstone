﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace QRCodeDemo
{
    public partial class FormHolidayAdd : Form
    {
        SqlConnection tublecon = new SqlConnection(Class.tublecon);

        public FormHolidayAdd()
        {
            InitializeComponent();
        }

        private void FormHolidayAdd_Load(object sender, EventArgs e)
        {
            Loaddata();
        }

        void Loaddata()
        {
            string week = "";
            bool accept = false;
            MessageBox.Show(DateTime.Now.DayOfWeek.ToString());
            if (DateTime.Now.DayOfWeek.ToString().Equals("Monday")) { week = "SELECT Monday FROM tblWorkersSchedule WHERE WorkersID = "; accept = true; }
            else if (DateTime.Now.DayOfWeek.Equals("Tuesday")) { week = "SELECT Tuesday FROM tblWorkersSchedule WHERE WorkersID = "; accept = true; }
            else if (DateTime.Now.DayOfWeek.Equals("Wednesday")) { week = "SELECT Wednesday FROM tblWorkersSchedule WHERE WorkersID = "; accept = true; }
            else if (DateTime.Now.DayOfWeek.Equals("Thursday")) { week = "SELECT Thursday FROM tblWorkersSchedule WHERE WorkersID = "; accept = true; }
            else if (DateTime.Now.DayOfWeek.Equals("Friday")) { week = "SELECT Friday FROM tblWorkersSchedule WHERE WorkersID = "; accept = true; }
            else if (DateTime.Now.DayOfWeek.Equals("Saturday")) { week = "SELECT Saturday FROM tblWorkersSchedule WHERE WorkersID = "; accept = true; }
            else if (DateTime.Now.DayOfWeek.Equals("Sunday")) { week = "SELECT Sunday FROM tblWorkersSchedule WHERE WorkersID = "; accept = true; }

            if (accept.Equals(true))
            {
                MessageBox.Show(accept.ToString());
                SqlCommand cmd = new SqlCommand(week+"@WorkersID", tublecon);
                cmd.Parameters.AddWithValue("@WorkersID", Class.WorkersID);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);

                labelWorkersID.Text = Class.WorkersID;
                labelSchedule.Text = dt.Rows[0][0].ToString();
                labelDay.Text = DateTime.Now.DayOfWeek.ToString();
                labelDate.Text = DateTime.Now.ToShortDateString();
                accept = false;
            }
        }

        private void buttonAddHoliday_Click(object sender, EventArgs e)
        {
            AddHoliday();
        }

        void AddHoliday() 
        {
            SqlCommand cmd = new SqlCommand();
        }
    }
}
