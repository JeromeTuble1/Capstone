﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace QRCodeDemo
{
    public partial class FormWorker : Form
    {
        SqlConnection tublecon = new SqlConnection(Class.tublecon);

        public FormWorker()
        {
            InitializeComponent();
        }

        private void FormWorker_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        void LoadData()
        {
            try
            {
                SqlCommand cmd = new SqlCommand("SELECT WBD.WorkersID, WBD.LName, WBD.FName, WBD.MName, WBD.BirthDate, WBD.HireDate, WBD.[Address], WBD.ContactNumber, WBD.EmergencyContact FROM tblWorkersBioData WBD", tublecon);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridViewAttendance.DataSource = dt;
            }
            catch
            {
                MessageBox.Show("No Connection");
            }
        }

        void Search()
        {
            bool accept = false;
            string category = Convert.ToString(comboBoxSelectCategory.SelectedItem);
            if (category.Equals("WorkersID") && textBoxSearch.Text != "") { category = "SELECT WBD.WorkersID, WBD.LName, WBD.FName, WBD.MName, WBD.BirthDate, WBD.HireDate, WBD.[Address], WBD.ContactNumber, WBD.EmergencyContact FROM tblWorkersBioData WBD WHERE WBD.WorkersID ="; accept = true; }
            else if (category.Equals("LName") && textBoxSearch.Text != "") { category = "SELECT WBD.WorkersID, WBD.LName, WBD.FName, WBD.MName, WBD.BirthDate, WBD.HireDate, WBD.[Address], WBD.ContactNumber, WBD.EmergencyContact FROM tblWorkersBioData WBD WHERE WBD.LName ="; accept = true; }
            else if (category.Equals("FName") && textBoxSearch.Text != "") { category = "SELECT WBD.WorkersID, WBD.LName, WBD.FName, WBD.MName, WBD.BirthDate, WBD.HireDate, WBD.[Address], WBD.ContactNumber, WBD.EmergencyContact FROM tblWorkersBioData WBD WHERE WBD.FName ="; accept = true; }
            else if (category.Equals("MName") && textBoxSearch.Text != "") { category = "SELECT WBD.WorkersID, WBD.LName, WBD.FName, WBD.MName, WBD.BirthDate, WBD.HireDate, WBD.[Address], WBD.ContactNumber, WBD.EmergencyContact FROM tblWorkersBioData WBD WHERE WBD.MName ="; accept = true; }
            else if (category.Equals("BirthDate") && textBoxSearch.Text != "") { category = "SELECT WBD.WorkersID, WBD.LName, WBD.FName, WBD.MName, WBD.BirthDate, WBD.HireDate, WBD.[Address], WBD.ContactNumber, WBD.EmergencyContact FROM tblWorkersBioData WBD WHERE WBD.BirthDate ="; accept = true; }
            else if (category.Equals("HireDate") && textBoxSearch.Text != "") { category = "SELECT WBD.WorkersID, WBD.LName, WBD.FName, WBD.MName, WBD.BirthDate, WBD.HireDate, WBD.[Address], WBD.ContactNumber, WBD.EmergencyContact FROM tblWorkersBioData WBD WHERE WBD.HireDate = "; accept = true; }
            else if (category.Equals("Address") && textBoxSearch.Text != "") { category = "SELECT WBD.WorkersID, WBD.LName, WBD.FName, WBD.MName, WBD.BirthDate, WBD.HireDate, WBD.[Address], WBD.ContactNumber, WBD.EmergencyContact FROM tblWorkersBioData WBD WHERE WBD.Address ="; accept = true; }
            else if (category.Equals("ContactNumber") && textBoxSearch.Text != "") { category = "SELECT WBD.WorkersID, WBD.LName, WBD.FName, WBD.MName, WBD.BirthDate, WBD.HireDate, WBD.[Address], WBD.ContactNumber, WBD.EmergencyContact FROM tblWorkersBioData WBD WHERE WBD.ContactNumber ="; accept = true; }
            else if (category.Equals("EmergencyContact") && textBoxSearch.Text != "") { category = "SELECT WBD.WorkersID, WBD.LName, WBD.FName, WBD.MName, WBD.BirthDate, WBD.HireDate, WBD.[Address], WBD.ContactNumber, WBD.EmergencyContact FROM tblWorkersBioData WBD WHERE WBD.EmergencyContact ="; accept = true; }
            else if (category.Equals("")) { accept = false; }

            if (accept.Equals(true))
            {
                SqlCommand cmd = new SqlCommand(category + "@Search", tublecon);
                cmd.Parameters.AddWithValue("@Search", textBoxSearch.Text);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridViewAttendance.DataSource = dt;
                accept = false;
            }
            else if (accept.Equals(false))
            {
                LoadData();
            }
        }

        private void buttonAddWorkers_Click(object sender, EventArgs e)
        {
            FormWorkersAdd WA = new FormWorkersAdd();
            WA.ShowDialog();
            LoadData();
        }

        private void dataGridViewAttendance_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            FormWorkersEdit WE = new FormWorkersEdit();
            Class.WorkersID = dataGridViewAttendance.CurrentRow.Cells[0].Value.ToString();
            WE.ShowDialog();
            LoadData();
        }

        private void textBoxSearch_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                Search();
            }
        }
    }
}
