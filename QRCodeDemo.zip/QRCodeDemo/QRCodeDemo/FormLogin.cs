﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace QRCodeDemo
{
    public partial class FormLogin : Form
    {
        SqlConnection con = new SqlConnection(Class.con);
        public FormLogin()
        {
            InitializeComponent();
        }

        private void buttonLogin_Click(object sender, EventArgs e)
        {
            Login();
        }

        void GetUserData() {
            SqlCommand cmd = new SqlCommand("SELECT UserID FROM tblLogin WHERE UserName = @Username AND Password = @Password", con);
            cmd.Parameters.AddWithValue("@Username", textBoxUserName.Text);
            cmd.Parameters.AddWithValue("@Password", textBoxPassword.Text);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            Class.UserID = dt.Rows[0][0].ToString();
        }

        void Login() {
                SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM tblLogin WHERE UserName = @Username AND Password = @Password", con);
                cmd.Parameters.AddWithValue("@Username", textBoxUserName.Text);
                cmd.Parameters.AddWithValue("@Password", textBoxPassword.Text);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (Convert.ToInt16(dt.Rows[0][0].ToString()) > 0)
                {
                    ///////////////////////////////////////
                    //DataSet ds = new DataSet();
                    //da.Fill(ds);
                    //Class.Picture = (Byte[])(ds.Tables[0].Rows[0]["Picture"]);
                    //Class.IsEmployee = Convert.ToBoolean(dt.Rows[2][0]);
                    ///////////////////////////////////////
                    //Login sucess Welcome to Homepage
                    GetUserData();
                    FormDashboard db = new FormDashboard();
                    db.ShowDialog();
                }
                else
                {
                    MessageBox.Show("Invalid Login please check username and password");
                }
        }

        private void FormLogin_Load(object sender, EventArgs e)
        {

        }

        private void buttonRegister_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormRegister FR = new FormRegister();
            FR.ShowDialog();
        }

        private void checkBoxShowPassword_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxShowPassword.Checked.Equals(true)) {
                textBoxPassword.PasswordChar = '\0';
            }
            else if (checkBoxShowPassword.Checked.Equals(false))
            {
                textBoxPassword.PasswordChar = '*';
            }
        }
    }
}
