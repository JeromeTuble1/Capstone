﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace QRCodeDemo
{
    public partial class FormShifts : Form
    {
        public FormShifts()
        {
            InitializeComponent();
        }

        private void FormShifts_Load(object sender, EventArgs e)
        {

        }
    }
}
