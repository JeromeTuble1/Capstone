﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace QRCodeDemo
{
    public partial class FormShifts : Form
    {
        SqlConnection tublecon = new SqlConnection(Class.tublecon);
        public FormShifts()
        {
            InitializeComponent();
        }

        private void FormShifts_Load(object sender, EventArgs e)
        {
            LoadData();
        }
        void LoadData()
        {
            SqlCommand tublecmd = new SqlCommand("SELECT WorkersID, MonSched, MonDayNight, TueSched, TueDayNight, WedSched, WedDayNight, ThuSched, ThuDayNight, FriSched, FriDayNight, SatSched, SatDayNight, SunSched, SunDayNight FROM tblWorkersSchedule", tublecon);
            SqlDataAdapter da = new SqlDataAdapter(tublecmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            dataGridViewShifts.DataSource = dt;
        }
    }
}
