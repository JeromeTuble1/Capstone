﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace QRCodeDemo
{
    class Class
    {
        // bit TRUE = 1 and FALSE = 0
        public static string con = "Data Source=LAPTOP-0QBJ070A; Database=DBQRCode; Integrated Security=True;", UserID, Gender, Date = "", NewQRCodeGenerate = "";
        public static byte[] Picture;
        public static bool GenerateRegister = false;

        //////////////////////////////////////////////////

        public static string UserSearchPair, PasswordSearchPair, GenerateQRCode;
    }
}
