﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace QRCodeDemo
{
    public partial class FormWorkerLunchBreak : Form
    {
        SqlConnection tublecon = new SqlConnection(Class.tublecon);

        public FormWorkerLunchBreak()
        {
            InitializeComponent();
        }

        private void buttonClose_Click(object sender, EventArgs e)
        {
            this.Close();
            GetData();
            GetSchedule();
        }

        void GetData()
        {

            SqlCommand cmd = new SqlCommand("SELECT * FROM tblWorkersAttendance INNER JOIN tblWorkersBioData ON tblWorkersAttendance.WorkersID = tblWorkersBioData.WorkersID WHERE tblWorkersBioData.WorkersID = @WorkersID AND tblWorkersAttendance.Date = @Date", tublecon);
            cmd.Parameters.AddWithValue("@WorkersID", Class.WorkersID);
            cmd.Parameters.AddWithValue("@Date", Convert.ToDateTime(Class.WorkersDate));
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            textBoxWorkersID.Text = Convert.ToString(dt.Rows[0][0]);
            textBoxFullName.Text = Convert.ToString(dt.Rows[0]["LName"] + ", " + dt.Rows[0]["FName"] + " " + dt.Rows[0]["MName"] + " " + dt.Rows[0]["Suffix"]);
            dateTimePickerSchedule.Text = Convert.ToString(dt.Rows[0]["Schedule"]);
            textBoxDay.Text = Convert.ToString(dt.Rows[0]["Day"]);
            dateTimePickerDate.Text = Convert.ToString(dt.Rows[0]["Date"]);

            //For PictureBox
            MemoryStream mem = new MemoryStream((Byte[])(dt.Rows[0]["Picture"]));
            pictureBox1.Image = Image.FromStream(mem);
        }

        void GetSchedule()
        {
            dateTimePickerCheckIn.Value = Convert.ToDateTime(DateTime.Now.ToShortTimeString());

            string Date = "", ColDate = "", DateDayNight = "", WeekNow;
            SqlCommand cmd = new SqlCommand("SELECT * FROM tblWorkersSchedule WHERE WorkersID = @WorkersID", tublecon);
            cmd.Parameters.AddWithValue("@WorkersID", Class.WorkersID);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            WeekNow = Convert.ToString(DateTime.Now.DayOfWeek);

            if (WeekNow == "Monday") { Date = "Monday"; ColDate = "MonSched"; DateDayNight = "MonDayNight"; }
            else if (WeekNow == "Tuesday") { Date = "Tuesday"; ColDate = "TueSched"; DateDayNight = "TueDayNight"; }
            else if (WeekNow == "Wednesday") { Date = "Wednesday"; ColDate = "WedSched"; DateDayNight = "WedDayNight"; }
            else if (WeekNow == "Thursday") { Date = "Thursday"; ColDate = "ThuSched"; DateDayNight = "ThuDayNight"; }
            else if (WeekNow == "Friday") { Date = "Friday"; ColDate = "FriSched"; DateDayNight = "FriDayNight"; }
            else if (WeekNow == "Saturday") { Date = "Saturday"; ColDate = "SatSched"; DateDayNight = "SatDayNight"; }
            else if (WeekNow == "Sunday") { Date = "Sunday"; ColDate = "SunSched"; DateDayNight = "SunDayNight"; }
            if (Convert.ToInt16(dt.Rows.Count).Equals(1))
            {
                //Show Time from DateTimePicker
                string schedule = Convert.ToString(dt.Rows[0][ColDate]) + " " + Convert.ToString(dt.Rows[0][DateDayNight]);
                dateTimePickerSchedule.Text = dt.Rows[0][ColDate] + " " + dt.Rows[0][DateDayNight];

                textBoxDay.Text = Date;
                dateTimePickerDate.Text = DateTime.Now.ToShortDateString();
            }
        }

        void AddLunch()
        {
            SqlCommand cmd = new SqlCommand("INSERT INTO tblWorkersAttendance (WorkersID,Status,Date,Schedule,Day,CheckIn) VALUES (@WorkersID,@Status,@Date,@Schedule,@Day,@CheckIn)", tublecon);
            cmd.Parameters.AddWithValue("@WorkersID", textBoxWorkersID.Text);
            cmd.Parameters.AddWithValue("@Date", Convert.ToDateTime(dateTimePickerDate.Text));
            cmd.Parameters.AddWithValue("@Status", textBoxStatus.Text);
            cmd.Parameters.AddWithValue("@Schedule", Convert.ToDateTime(dateTimePickerSchedule.Text));
            cmd.Parameters.AddWithValue("@Day", textBoxDay.Text);
            cmd.Parameters.AddWithValue("@CheckIn", Convert.ToDateTime(dateTimePickerCheckIn.Text));
            tublecon.Open();
            cmd.ExecuteNonQuery();
            tublecon.Close();
        }

        private void buttonAddLunchBreak_Click(object sender, EventArgs e)
        {
            AddLunch();
        }
    }
}
