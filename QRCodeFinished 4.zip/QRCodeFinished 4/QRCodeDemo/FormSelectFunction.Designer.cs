﻿namespace QRCodeDemo
{
    partial class FormSelectFunction
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonCheckout = new System.Windows.Forms.Button();
            this.buttonLunchBreak = new System.Windows.Forms.Button();
            this.jbtPanelGIF1 = new QRCodeDemo.JBTControls.JBTPanelGIF();
            this.SuspendLayout();
            // 
            // buttonCheckout
            // 
            this.buttonCheckout.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.buttonCheckout.FlatAppearance.BorderSize = 0;
            this.buttonCheckout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonCheckout.Font = new System.Drawing.Font("Segoe UI Symbol", 12F, System.Drawing.FontStyle.Bold);
            this.buttonCheckout.ForeColor = System.Drawing.Color.White;
            this.buttonCheckout.Location = new System.Drawing.Point(13, 18);
            this.buttonCheckout.Margin = new System.Windows.Forms.Padding(4);
            this.buttonCheckout.Name = "buttonCheckout";
            this.buttonCheckout.Size = new System.Drawing.Size(389, 52);
            this.buttonCheckout.TabIndex = 6;
            this.buttonCheckout.Text = "Worker Checkout";
            this.buttonCheckout.UseVisualStyleBackColor = false;
            this.buttonCheckout.Click += new System.EventHandler(this.buttonCheckout_Click);
            // 
            // buttonLunchBreak
            // 
            this.buttonLunchBreak.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.buttonLunchBreak.FlatAppearance.BorderSize = 0;
            this.buttonLunchBreak.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonLunchBreak.Font = new System.Drawing.Font("Segoe UI Symbol", 12F, System.Drawing.FontStyle.Bold);
            this.buttonLunchBreak.ForeColor = System.Drawing.Color.White;
            this.buttonLunchBreak.Location = new System.Drawing.Point(13, 78);
            this.buttonLunchBreak.Margin = new System.Windows.Forms.Padding(4);
            this.buttonLunchBreak.Name = "buttonLunchBreak";
            this.buttonLunchBreak.Size = new System.Drawing.Size(389, 52);
            this.buttonLunchBreak.TabIndex = 4;
            this.buttonLunchBreak.Text = "Worker Lunch Break";
            this.buttonLunchBreak.UseVisualStyleBackColor = false;
            this.buttonLunchBreak.Click += new System.EventHandler(this.buttonLunchBreak_Click);
            // 
            // jbtPanelGIF1
            // 
            this.jbtPanelGIF1.Angle = 83F;
            this.jbtPanelGIF1.BorderRadius = 1;
            this.jbtPanelGIF1.Color0 = System.Drawing.Color.Blue;
            this.jbtPanelGIF1.Color1 = System.Drawing.Color.Pink;
            this.jbtPanelGIF1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.jbtPanelGIF1.ForeColor = System.Drawing.Color.White;
            this.jbtPanelGIF1.Location = new System.Drawing.Point(0, 0);
            this.jbtPanelGIF1.Name = "jbtPanelGIF1";
            this.jbtPanelGIF1.Size = new System.Drawing.Size(415, 148);
            this.jbtPanelGIF1.TabIndex = 7;
            // 
            // FormSelectFunction
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(415, 148);
            this.Controls.Add(this.buttonCheckout);
            this.Controls.Add(this.buttonLunchBreak);
            this.Controls.Add(this.jbtPanelGIF1);
            this.Name = "FormSelectFunction";
            this.Text = "FormSelectFunction";
            this.Load += new System.EventHandler(this.FormSelectFunction_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button buttonCheckout;
        private System.Windows.Forms.Button buttonLunchBreak;
        private JBTControls.JBTPanelGIF jbtPanelGIF1;
    }
}