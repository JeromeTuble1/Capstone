﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace QRCodeDemo
{
    public partial class FormAttendanceReport : Form
    {
        public string WorkersID { get; set; }

        SqlConnection tublecon = new SqlConnection(Class.tublecon);

        public FormAttendanceReport()
        {
            InitializeComponent();
        }



        private void FormAttendanceReport_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        void LoadData()
        {
            SqlCommand cmd = new SqlCommand("SELECT WorkersID, [LName]+', '+ [FName]+' '+ [MName] AS FullName  FROM tblWorkersBioData", tublecon);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridViewReport.DataSource = dt;
        }

        private void dataGridViewReport_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            Class.WorkersID = dataGridViewReport.CurrentRow.Cells[0].Value.ToString();
            Class.AR = true;
            FormFromTo FT = new FormFromTo();
            FT.ShowDialog();
        }

        void Search()
        {
            SqlCommand cmd = new SqlCommand("SELECT WorkersID, [LName]+', '+ [FName]+' '+ [MName] AS FullName  FROM tblWorkersBioData WHERE WorkersID = @WorkersID", tublecon);
            cmd.Parameters.AddWithValue("@WorkersID",textBoxSearch.Text);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridViewReport.DataSource = dt;
        }

        private void textBoxSearch_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                Search();
            }
        }
    }
}
