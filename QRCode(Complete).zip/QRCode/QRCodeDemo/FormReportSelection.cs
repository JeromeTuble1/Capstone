﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace QRCodeDemo
{
    public partial class FormReportSelection : Form
    {
        public FormReportSelection()
        {
            InitializeComponent();
        }

        private void buttonAttendanceReport_Click(object sender, EventArgs e)
        {
            Class.ReportSelection = "AttendanceReport";
            this.Hide();
        }

        private void buttonLeaveRequestReport_Click(object sender, EventArgs e)
        {
            Class.ReportSelection = "LeaveRequestReport";
            this.Hide();
        }

        private void FormReportSelection_Load(object sender, EventArgs e)
        {

        }

        private void buttonEmployeeAttendanceReport_Click(object sender, EventArgs e)
        {
            Class.ReportSelection = "EmployeeAttendanceReport";
            this.Hide();
        }
    }
}
