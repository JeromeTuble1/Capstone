﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Microsoft.Reporting.WinForms;
using System.Data.SqlClient;

namespace QRCodeDemo
{
    public partial class FormAttendanceReceipt : Form
    {
        public static string PName ="", PID ="", PDate = "";
        SqlConnection tublecon = new SqlConnection(Class.tublecon);

        public FormAttendanceReceipt()
        {
            InitializeComponent();
        }

        private void FormAttendanceReport_Load(object sender, EventArgs e)
        {
            GetDataName();
        }

        void GetDataName() 
        {

            SqlCommand tublecmd = new SqlCommand("SELECT WBD.WorkersID, WBD.[LName]+', '+ WBD.[FName]+' '+ WBD.[MName] AS FullName,WA.Schedule,WA.CheckIn,WA.CheckOut,WA.[Status],WA.[Day],WA.[Date],WA.AbsentCause FROM tblWorkersAttendance WA INNER JOIN tblWorkersBioData WBD ON WA.WorkersID = WBD.WorkersID WHERE WA.WorkersID = @WorkersID", tublecon);
            tublecmd.Parameters.AddWithValue("@WorkersID", Class.WorkersID);
            SqlDataAdapter tubleda = new SqlDataAdapter(tublecmd);
            DataTable tubledt = new DataTable();
            tubleda.Fill(tubledt);
            tblWorkersAttendanceBindingSource.DataSource = tubledt;

            if (tubledt.Rows.Count.Equals(0))
            {
                MessageBox.Show("No Report");
                this.Close();
            }
            else
            {
                string Splitting = tubledt.Rows[0]["Date"].ToString();
                string[] splitcon = Splitting.Split(' ');
                PID = Convert.ToString(tubledt.Rows[0]["WorkersID"]);
                PName = Convert.ToString(tubledt.Rows[0]["FullName"]);
                PDate = Convert.ToString(splitcon[0]);
                ReportParameter[] para = new ReportParameter[] { new ReportParameter("pID", PID), new ReportParameter("pName", PName), new ReportParameter("pDate", PDate) };
                this.reportViewer1.LocalReport.SetParameters(para);
                this.reportViewer1.RefreshReport();
            }
        }
    }
}
