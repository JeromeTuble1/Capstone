﻿namespace QRCodeDemo
{
    partial class FormReportSelection
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonWorkerAttendanceReport = new System.Windows.Forms.Button();
            this.buttonLeaveRequestReport = new System.Windows.Forms.Button();
            this.buttonEmployeeReport = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // buttonWorkerAttendanceReport
            // 
            this.buttonWorkerAttendanceReport.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.buttonWorkerAttendanceReport.FlatAppearance.BorderSize = 0;
            this.buttonWorkerAttendanceReport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonWorkerAttendanceReport.Font = new System.Drawing.Font("Segoe UI Symbol", 12F, System.Drawing.FontStyle.Bold);
            this.buttonWorkerAttendanceReport.ForeColor = System.Drawing.Color.White;
            this.buttonWorkerAttendanceReport.Location = new System.Drawing.Point(25, 27);
            this.buttonWorkerAttendanceReport.Margin = new System.Windows.Forms.Padding(4);
            this.buttonWorkerAttendanceReport.Name = "buttonWorkerAttendanceReport";
            this.buttonWorkerAttendanceReport.Size = new System.Drawing.Size(283, 52);
            this.buttonWorkerAttendanceReport.TabIndex = 0;
            this.buttonWorkerAttendanceReport.Text = "Worker Attendance Report";
            this.buttonWorkerAttendanceReport.UseVisualStyleBackColor = false;
            this.buttonWorkerAttendanceReport.Click += new System.EventHandler(this.buttonAttendanceReport_Click);
            // 
            // buttonLeaveRequestReport
            // 
            this.buttonLeaveRequestReport.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.buttonLeaveRequestReport.FlatAppearance.BorderSize = 0;
            this.buttonLeaveRequestReport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonLeaveRequestReport.Font = new System.Drawing.Font("Segoe UI Symbol", 12F, System.Drawing.FontStyle.Bold);
            this.buttonLeaveRequestReport.ForeColor = System.Drawing.Color.White;
            this.buttonLeaveRequestReport.Location = new System.Drawing.Point(25, 91);
            this.buttonLeaveRequestReport.Margin = new System.Windows.Forms.Padding(4);
            this.buttonLeaveRequestReport.Name = "buttonLeaveRequestReport";
            this.buttonLeaveRequestReport.Size = new System.Drawing.Size(283, 52);
            this.buttonLeaveRequestReport.TabIndex = 1;
            this.buttonLeaveRequestReport.Text = "Leave Request Report";
            this.buttonLeaveRequestReport.UseVisualStyleBackColor = false;
            this.buttonLeaveRequestReport.Click += new System.EventHandler(this.buttonLeaveRequestReport_Click);
            // 
            // buttonEmployeeReport
            // 
            this.buttonEmployeeReport.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.buttonEmployeeReport.FlatAppearance.BorderSize = 0;
            this.buttonEmployeeReport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonEmployeeReport.Font = new System.Drawing.Font("Segoe UI Symbol", 12F, System.Drawing.FontStyle.Bold);
            this.buttonEmployeeReport.ForeColor = System.Drawing.Color.White;
            this.buttonEmployeeReport.Location = new System.Drawing.Point(25, 151);
            this.buttonEmployeeReport.Margin = new System.Windows.Forms.Padding(4);
            this.buttonEmployeeReport.Name = "buttonEmployeeReport";
            this.buttonEmployeeReport.Size = new System.Drawing.Size(283, 52);
            this.buttonEmployeeReport.TabIndex = 2;
            this.buttonEmployeeReport.Text = "Employee Report";
            this.buttonEmployeeReport.UseVisualStyleBackColor = false;
            this.buttonEmployeeReport.Click += new System.EventHandler(this.buttonEmployeeReport_Click);
            // 
            // FormReportSelection
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(334, 233);
            this.Controls.Add(this.buttonEmployeeReport);
            this.Controls.Add(this.buttonLeaveRequestReport);
            this.Controls.Add(this.buttonWorkerAttendanceReport);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormReportSelection";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Select Report";
            this.Load += new System.EventHandler(this.FormReportSelection_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button buttonWorkerAttendanceReport;
        private System.Windows.Forms.Button buttonLeaveRequestReport;
        private System.Windows.Forms.Button buttonEmployeeReport;
    }
}