﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace QRCodeDemo
{
    public partial class FormAttendanceEmployeeReport : Form
    {
        SqlConnection tublecon = new SqlConnection(Class.tublecon);

        public FormAttendanceEmployeeReport()
        {
            InitializeComponent();
        }

        private void dataGridViewAttendance_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            Class.EmployeeID = dataGridViewEmployeeAttendance.CurrentRow.Cells[0].Value.ToString();
            FormAttendanceEmployeeReceipt FAER = new FormAttendanceEmployeeReceipt();
            this.Hide();
            FAER.ShowDialog();
        }

        private void FormAttendanceEmployeeReport_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        void LoadData()
        {
            SqlCommand tublecmd = new SqlCommand("SELECT EmployeeID, UserName, LName +', '+ FName +' '+ MName AS Name FROM tblLogin",tublecon);
            SqlDataAdapter tubleda = new SqlDataAdapter(tublecmd);
            DataTable tubledt = new DataTable();
            tubleda.Fill(tubledt);

            dataGridViewEmployeeAttendance.DataSource = tubledt;
        }

        void Search()
        {
            bool accept = false;
            string category = Convert.ToString(comboBoxSelectCategory.SelectedItem);
            if (category.Equals("WorkersID") && textBoxSearch.Text != "") { category = "SELECT WBD.WorkersID, WBD.LName +', '+ WBD.FName +' '+ WBD.MName +' '+ WBD.Suffix AS Name, WBD.BirthDate, WBD.HireDate, WBD.[Address], WBD.ContactNumber, WBD.EmergencyContact FROM tblWorkersBioData WBD WHERE WBD.WorkersID ="; accept = true; }
            else if (category.Equals("LName") && textBoxSearch.Text != "") { category = "SELECT WBD.WorkersID, WBD.LName +', '+ WBD.FName +' '+ WBD.MName +' '+ WBD.Suffix AS Name, WBD.BirthDate, WBD.HireDate, WBD.[Address], WBD.ContactNumber, WBD.EmergencyContact FROM tblWorkersBioData WBD WHERE WBD.LName ="; accept = true; }
            else if (category.Equals("FName") && textBoxSearch.Text != "") { category = "SELECT WBD.WorkersID, WBD.LName +', '+ WBD.FName +' '+ WBD.MName +' '+ WBD.Suffix AS Name, WBD.BirthDate, WBD.HireDate, WBD.[Address], WBD.ContactNumber, WBD.EmergencyContact FROM tblWorkersBioData WBD WHERE WBD.FName ="; accept = true; }
            else if (category.Equals("MName") && textBoxSearch.Text != "") { category = "SELECT WBD.WorkersID, WBD.LName +', '+ WBD.FName +' '+ WBD.MName +' '+ WBD.Suffix AS Name, WBD.BirthDate, WBD.HireDate, WBD.[Address], WBD.ContactNumber, WBD.EmergencyContact FROM tblWorkersBioData WBD WHERE WBD.MName ="; accept = true; }
            else if (category.Equals("BirthDate") && textBoxSearch.Text != "") { category = "SELECT WBD.WorkersID, WBD.LName +', '+ WBD.FName +' '+ WBD.MName +' '+ WBD.Suffix AS Name, WBD.BirthDate, WBD.HireDate, WBD.[Address], WBD.ContactNumber, WBD.EmergencyContact FROM tblWorkersBioData WBD WBD WHERE WBD.BirthDate ="; accept = true; }
            else if (category.Equals("")) { accept = false; }

            if (accept.Equals(true))
            {
                SqlCommand cmd = new SqlCommand(category + "@Search", tublecon);
                cmd.Parameters.AddWithValue("@Search", textBoxSearch.Text);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridViewEmployeeAttendance.DataSource = dt;
                accept = false;
            }
            else if (accept.Equals(false))
            {
                LoadData();
            }
        }
    }
}
