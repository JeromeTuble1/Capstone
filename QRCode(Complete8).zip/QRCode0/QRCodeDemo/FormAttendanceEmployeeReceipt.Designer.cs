﻿namespace QRCodeDemo
{
    partial class FormAttendanceEmployeeReceipt
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.DBdjaasDataSet1 = new QRCodeDemo.DBdjaasDataSet1();
            this.tblEmplyeeStatusBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tblEmplyeeStatusTableAdapter = new QRCodeDemo.DBdjaasDataSet1TableAdapters.tblEmplyeeStatusTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.DBdjaasDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblEmplyeeStatusBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // reportViewer1
            // 
            this.reportViewer1.Dock = System.Windows.Forms.DockStyle.Fill;
            reportDataSource1.Name = "DataSet1";
            reportDataSource1.Value = this.tblEmplyeeStatusBindingSource;
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource1);
            this.reportViewer1.LocalReport.ReportEmbeddedResource = "QRCodeDemo.EmployeeAttendanceReport.rdlc";
            this.reportViewer1.Location = new System.Drawing.Point(0, 0);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.Size = new System.Drawing.Size(1103, 639);
            this.reportViewer1.TabIndex = 0;
            this.reportViewer1.Load += new System.EventHandler(this.reportViewer1_Load);
            // 
            // DBdjaasDataSet1
            // 
            this.DBdjaasDataSet1.DataSetName = "DBdjaasDataSet1";
            this.DBdjaasDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tblEmplyeeStatusBindingSource
            // 
            this.tblEmplyeeStatusBindingSource.DataMember = "tblEmplyeeStatus";
            this.tblEmplyeeStatusBindingSource.DataSource = this.DBdjaasDataSet1;
            // 
            // tblEmplyeeStatusTableAdapter
            // 
            this.tblEmplyeeStatusTableAdapter.ClearBeforeFill = true;
            // 
            // FormAttendanceEmployeeReceipt
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1103, 639);
            this.Controls.Add(this.reportViewer1);
            this.Name = "FormAttendanceEmployeeReceipt";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Receipt";
            this.Load += new System.EventHandler(this.FormAttendanceEmployeeReceipt_Load);
            ((System.ComponentModel.ISupportInitialize)(this.DBdjaasDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblEmplyeeStatusBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
        private System.Windows.Forms.BindingSource tblEmplyeeStatusBindingSource;
        private DBdjaasDataSet1 DBdjaasDataSet1;
        private DBdjaasDataSet1TableAdapters.tblEmplyeeStatusTableAdapter tblEmplyeeStatusTableAdapter;
    }
}