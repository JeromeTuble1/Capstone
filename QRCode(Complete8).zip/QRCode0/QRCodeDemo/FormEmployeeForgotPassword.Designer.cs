﻿namespace QRCodeDemo
{
    partial class FormEmployeeForgotPassword
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBoxEmployID = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.buttonFindPassword = new System.Windows.Forms.Button();
            this.dateTimePickerbirthdate = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxYourPassword = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.shapeContainer1 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.lineShape1 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape2 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // textBoxEmployID
            // 
            this.textBoxEmployID.BackColor = System.Drawing.SystemColors.Control;
            this.textBoxEmployID.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxEmployID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxEmployID.Location = new System.Drawing.Point(165, 149);
            this.textBoxEmployID.Name = "textBoxEmployID";
            this.textBoxEmployID.Size = new System.Drawing.Size(187, 19);
            this.textBoxEmployID.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(55, 151);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(104, 20);
            this.label1.TabIndex = 2;
            this.label1.Text = "Employee ID:";
            // 
            // buttonFindPassword
            // 
            this.buttonFindPassword.BackColor = System.Drawing.Color.LightBlue;
            this.buttonFindPassword.FlatAppearance.BorderSize = 0;
            this.buttonFindPassword.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonFindPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonFindPassword.Location = new System.Drawing.Point(151, 271);
            this.buttonFindPassword.Name = "buttonFindPassword";
            this.buttonFindPassword.Size = new System.Drawing.Size(105, 39);
            this.buttonFindPassword.TabIndex = 4;
            this.buttonFindPassword.Text = "Submit";
            this.buttonFindPassword.UseVisualStyleBackColor = false;
            this.buttonFindPassword.Click += new System.EventHandler(this.buttonFindPassword_Click);
            // 
            // dateTimePickerbirthdate
            // 
            this.dateTimePickerbirthdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePickerbirthdate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePickerbirthdate.Location = new System.Drawing.Point(165, 180);
            this.dateTimePickerbirthdate.Name = "dateTimePickerbirthdate";
            this.dateTimePickerbirthdate.Size = new System.Drawing.Size(106, 26);
            this.dateTimePickerbirthdate.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(77, 185);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 20);
            this.label2.TabIndex = 6;
            this.label2.Text = "Birth date:";
            // 
            // textBoxYourPassword
            // 
            this.textBoxYourPassword.BackColor = System.Drawing.SystemColors.Control;
            this.textBoxYourPassword.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxYourPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxYourPassword.Location = new System.Drawing.Point(165, 214);
            this.textBoxYourPassword.Name = "textBoxYourPassword";
            this.textBoxYourPassword.ReadOnly = true;
            this.textBoxYourPassword.Size = new System.Drawing.Size(187, 19);
            this.textBoxYourPassword.TabIndex = 7;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(39, 215);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(120, 20);
            this.label3.TabIndex = 8;
            this.label3.Text = "Your Password:";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(153, 23);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 100);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 9;
            this.pictureBox1.TabStop = false;
            // 
            // shapeContainer1
            // 
            this.shapeContainer1.Location = new System.Drawing.Point(0, 0);
            this.shapeContainer1.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            this.shapeContainer1.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.lineShape2,
            this.lineShape1});
            this.shapeContainer1.Size = new System.Drawing.Size(400, 334);
            this.shapeContainer1.TabIndex = 10;
            this.shapeContainer1.TabStop = false;
            // 
            // lineShape1
            // 
            this.lineShape1.Name = "lineShape1";
            this.lineShape1.X1 = 165;
            this.lineShape1.X2 = 351;
            this.lineShape1.Y1 = 171;
            this.lineShape1.Y2 = 171;
            // 
            // lineShape2
            // 
            this.lineShape2.Name = "lineShape2";
            this.lineShape2.X1 = 165;
            this.lineShape2.X2 = 351;
            this.lineShape2.Y1 = 236;
            this.lineShape2.Y2 = 236;
            // 
            // FormEmployeeForgotPassword
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(400, 334);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBoxYourPassword);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dateTimePickerbirthdate);
            this.Controls.Add(this.buttonFindPassword);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBoxEmployID);
            this.Controls.Add(this.shapeContainer1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormEmployeeForgotPassword";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ForgotPassword";
            this.Load += new System.EventHandler(this.FormEmployeeForgotPassword_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxEmployID;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button buttonFindPassword;
        private System.Windows.Forms.DateTimePicker dateTimePickerbirthdate;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxYourPassword;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape2;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape1;
    }
}